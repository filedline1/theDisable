package com.life.square.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.life.square.pojo.Festival;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FestivalMapper extends BaseMapper<Festival> {
}
