package com.life.square.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.life.square.advise.exception.TokenNotFoundException;
import com.life.square.common.JsonResult;
import com.life.square.common.PageJsonResult;
import com.life.square.constants.MqConstants;
import com.life.square.dtos.TopicCommentDTO;
import com.life.square.dtos.TopicDTO;
import com.life.square.dtos.TopicReplyCommentDTO;
import com.life.square.pojo.TopicComment;
import com.life.square.pojo.TopicReplyComment;
import com.life.square.pojo.User;
import com.life.square.service.IUserService;
import com.life.square.service.TopicService;
import com.life.square.utils.GetUserFromRedisUtil;
import com.life.square.vo.TopicReplyCommentVo;
import com.life.square.vo.TopicVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.SneakyThrows;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.UUID;

/**
 * 话题
 *
 * @author Chunming Liu In 2022/08/21
 */
@Api(tags = "话题")
@RestController
@RequestMapping("topic")
public class TopicController {
    final TopicService topicService;
    final RabbitTemplate rabbitTemplate;
    private final GetUserFromRedisUtil userFromRedisUtil;
    private final IUserService userService;
    @Autowired
    HttpServletRequest request;

    public TopicController(TopicService topicService,
                           RabbitTemplate rabbitTemplate,
                           GetUserFromRedisUtil userFromRedisUtil,
                           IUserService userService) {
        this.topicService = topicService;
        this.rabbitTemplate = rabbitTemplate;
        this.userFromRedisUtil = userFromRedisUtil;
        this.userService = userService;
    }

    @ApiOperation("话题查询")
    @RequestMapping("query")
    public PageJsonResult<List<TopicVo>> queryTopicPage(@RequestParam(defaultValue = "") Long userId,
                                                        @RequestParam(defaultValue = "1") Long page,
                                                        @RequestParam(defaultValue = "10") Long size) {
        String token = request.getHeader("Authorization");
        // 从redis中通过token获取用户信息
        User userFromRedis = userFromRedisUtil.getUserFromRedis(token);
        return topicService.queryTopicPage(userFromRedis, userId, page, size);
    }

    /**
     * 创建话题 vip3次 发布
     */
    @ApiOperation("发布话题")
    @PostMapping("publish")
    public JsonResult<Object> createTopic(HttpServletRequest request,
                                          @RequestBody TopicDTO topicDTO) {
        String token = request.getHeader("Authorization");
        // 从redis中通过token获取用户信息
        User userFromRedis = userFromRedisUtil.getUserFromRedis(token);

        topicService.publish(userFromRedis, topicDTO);
        // es
        rabbitTemplate.convertAndSend(MqConstants.TOPIC_EXCAHGNE, MqConstants.TOPIC_INSERT_KEY, topicDTO.getId());
        return JsonResult.success();
    }

    /**
     * 更新话题
     */
    @ApiOperation("更新话题")
    @PostMapping("update")
    public JsonResult<Object> updateTopic(HttpServletRequest request,
                                          @RequestBody TopicDTO topicDTO) {
        topicService.updateTopic(topicDTO);
        // es
        rabbitTemplate.convertAndSend(MqConstants.TOPIC_EXCAHGNE, MqConstants.TOPIC_INSERT_KEY, topicDTO.getId());
        return JsonResult.success();
    }

    /**
     * 评论 （+1） 非VIP<= 3次
     */
    @ApiOperation("评论")
    @PostMapping("comment")
    public JsonResult<Object> commentTopic(HttpServletRequest request,
                                           TopicCommentDTO topicCommentDTO) {
        try {
            //通过令牌来获取
            //从请求头中获取token
            String token = request.getHeader("Authorization");
            //从redis中通过token获取用户信息
            User userFromRedis = userFromRedisUtil.getUserFromRedis(token);

            topicCommentDTO.setCommentId(UUID.randomUUID().toString());

            //添加评论到评论表
            topicService.insertComment(userFromRedis, topicCommentDTO);
            rabbitTemplate.convertAndSend(MqConstants.TOPIC_COMMENT_EXCAHGNE, MqConstants.TOPIC_COMMENT_INSERT_KEY, topicCommentDTO.getId());

            //给对应的动态的评论量+1
            topicService.commentAddOne(topicCommentDTO.getTopicId());
            rabbitTemplate.convertAndSend(MqConstants.TOPIC_EXCAHGNE, MqConstants.TOPIC_INSERT_KEY, topicCommentDTO.getTopicId());

            return JsonResult.success();  //表示审核通过 并 存入成功
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 评论回复 （+1）非VIP <= 3次
     */
    @ApiOperation("评论回复")
    @PostMapping("reply")
    public JsonResult<Object> replyTopic(HttpServletRequest request,
                                         TopicReplyCommentDTO topicReplyCommentDTO) {
        try {
            //通过令牌来获取
            //从请求头中获取token
            String token = request.getHeader("Authorization");
            //从redis中通过token获取用户信息
            User userFromRedis = userFromRedisUtil.getUserFromRedis(token);

            //添加评论的回复到回复表
            topicService.insertReply(userFromRedis, topicReplyCommentDTO);
            rabbitTemplate.convertAndSend(MqConstants.TOPIC_REPLY_EXCAHGNE, MqConstants.TOPIC_REPLY_INSERT_KEY, topicReplyCommentDTO.getId());

            //给对应的动态的评论量 +1
            topicService.replyCommentAddOne(topicReplyCommentDTO.getTopicId());
            rabbitTemplate.convertAndSend(MqConstants.TOPIC_EXCAHGNE, MqConstants.TOPIC_INSERT_KEY, topicReplyCommentDTO.getTopicId());

            //给对应的动态的回复量 +1
            topicService.commentReplyAmountAddOne(topicReplyCommentDTO.getCommentId());
            rabbitTemplate.convertAndSend(MqConstants.TOPIC_COMMENT_EXCAHGNE, MqConstants.TOPIC_COMMENT_INSERT_KEY, topicReplyCommentDTO.getCommentId());

            return JsonResult.success();  //存入成功
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 评论查询
     */
    @ApiOperation("评论查询")
    @GetMapping("comment/query")
    public PageJsonResult<JSONArray> topicCommentQuery(HttpServletRequest request,
                                                       @RequestParam Long topicId,
                                                       @RequestParam(defaultValue = "1") Long page,
                                                       @RequestParam(defaultValue = "10") Long size) {
        //从请求头中获取token
        String token = request.getHeader("Authorization");
        //从redis中通过token获取用户信息
        if (token == null) {
            throw new TokenNotFoundException("No Authorization");
        }
        JSONArray jsonArray = new JSONArray();
        //根据动态id获取动态的所有评论（在索引库中查找）
        String sortName = "createTime";   //进行升序依序的索引库中的字段名
        String sortOrder = "DESC";   //ASC表示升序，DESC表示降序
        List<TopicComment> list = topicService.getAllCommentByTopicId(page, size, sortName, sortOrder, topicId);

        for (TopicComment comment : list) {
            System.out.println("————>" + comment.getCreateTime());

            JSONObject jsonObject = new JSONObject();

            User user = userService.getUserByUser_id(comment.getCommentatorId().toString());
            if (user != null) {
                String head_path = user.getHeadPicPath();
                jsonObject.put("headPicture", head_path);        //头像
                comment.setCommentatorName(user.getNickName());
            }

            jsonObject.put("comment", comment);
            jsonObject.put("Flag", false);
            jsonObject.put("page", 1);
            jsonObject.put("replyAmountTemp", comment.getReplyAmount());
            jsonObject.put("flag", false);

            //根据评论的id 查找其所有的 回复（在索引库中查找）
            String sort = "createTime";   //进行升序依序的索引库中的字段名
            String Order = "ASC";   //ASC表示升序，DESC表示降序
            List<TopicReplyCommentVo> replyCommentVos = topicService.getAllReplyByTopicId(1L, 2L, sort, Order, comment.getCommentId());
            jsonObject.put("children", replyCommentVos);
            jsonArray.add(jsonObject);
        }
        long total = 0;   //存储评论的总数量
        for (long p = 1; ; p++) {
            List<TopicComment> commentList = topicService.getAllCommentByTopicId(p, 10L, sortName, sortOrder, topicId);
            if (commentList == null || commentList.isEmpty())
                break;
            total += commentList.size();
        }
        System.out.println("—————————————————————————————————————获取到的TOPIC评论队列—————————————————————————————————————————————————————");
        System.out.println(list);
        System.out.println("———————————————————————————————————————————————————————————————————————————————————————————————————————");
        return PageJsonResult.success(page, size, total, jsonArray);
    }

    /**
     * 评论回复查询
     */
    @ApiOperation("评论回复查询")
    @GetMapping("reply/query")
    public JsonResult<JSONArray> topicReplyQuery(HttpServletRequest request,
                                                 @RequestParam String commentId,
                                                 @RequestParam(defaultValue = "1") Long page,
                                                 @RequestParam(defaultValue = "10") Long size) {
        //从请求头中获取token
        String token = request.getHeader("Authorization");
        //从redis中通过token获取用户信息
        if (token == null) {
            throw new TokenNotFoundException("No Authorization");
        }

        JSONArray jsonArray = new JSONArray();
        System.out.println("commentId:" + commentId);

        //根据评论的id 查找其所有的 回复（在索引库中查找）
        String sortName = "createTime";   //进行升序依序的索引库中的字段名
        String sortOrder = "DESC";   //ASC表示升序，DESC表示降序
        List<TopicReplyCommentVo> replyCommentVoList = topicService.getAllReplyByTopicId(page, size, sortName, sortOrder, commentId);
        for (TopicReplyCommentVo replyCommentVo : replyCommentVoList) {

            System.out.println("-->" + replyCommentVo.getCreateTime() + "-" + replyCommentVo.getReplyContent());

            JSONObject jsonObject = new JSONObject();
            User user = userService.getUserByUser_id(replyCommentVo.getReplyUserId().toString());
            User replyUser = userService.getUserByUser_id(replyCommentVo.getCommentUserId().toString());
            if (user != null && replyUser != null) {
                String head_path = user.getHeadPicPath();
                jsonObject.put("headPicture", head_path);        //头像
                replyCommentVo.setReplyUserName(user.getNickName());
                replyCommentVo.setCommentUserName(replyUser.getNickName());
            }
            jsonObject.put("comment", replyCommentVo);
            jsonArray.add(jsonObject);
        }
        return JsonResult.success(jsonArray);
    }

    @ApiOperation("删除话题")
    @DeleteMapping("delete")
    public JsonResult<Object> deleteTopic(@RequestParam("topicId") Long topicId) {

        //需要从es中删除，先mq发送求信息
        rabbitTemplate.convertAndSend(MqConstants.TOPIC_EXCAHGNE, MqConstants.TOPIC_DELETE_KEY, topicId);
        topicService.deleteTopic(topicId);   //从数据库中删除动态

        topicService.deleteComments(topicId);   //从数据库中删除动态的所有评论

        topicService.deleteReplies(topicId);  //从数据库中删除动态的所有回复

        return JsonResult.success("成功删除");
    }

    //用户自己删除评论
    @ApiOperation("删除自己的评论")
    @DeleteMapping("deleteComment")
    @Transactional(rollbackFor = Exception.class)    //表示的是该方法无论抛出什么异常都会进行自动回滚
    public JsonResult<Object> deleteComment(@RequestParam("commentId") Long commentId) {
        //从请求头中获取token
        String token = request.getHeader("Authorization");
        //从redis中通过token获取用户信息
        User userFromRedis = userFromRedisUtil.getUserFromRedis(token);

        //删除评论
        TopicComment comment = topicService.getCommentById(commentId);
        if (comment != null) {
            //需要从es中删除，先Mq发从请求信息
            rabbitTemplate.convertAndSend(MqConstants.TOPIC_COMMENT_EXCAHGNE, MqConstants.TOPIC_COMMENT_DELETE_KEY, comment.getCommentId());
            //删除该该评论的所有回复
            List<TopicReplyComment> replyList = topicService.getRepliesByTopicId(comment.getTopicId());
            if (replyList != null && replyList.size() != 0)
                for (TopicReplyComment reply : replyList) {  //需要从es中删除，先Mq发从请求信息
                    rabbitTemplate.convertAndSend(MqConstants.TOPIC_REPLY_EXCAHGNE, MqConstants.TOPIC_REPLY_DELETE_KEY, reply.getId());
                }
            topicService.deleteReplies(comment.getTopicId());   //从数据库中删除评论
            topicService.deleteCommentByCommentId(userFromRedis.getUserId().equals(comment.getCommentatorId()), comment);
        }

        return JsonResult.success();
    }

    @ApiOperation("删除自己评论的回复")
    @DeleteMapping("deleteReplyComment")
    public JsonResult<Object> deleteReply(@RequestParam("replyId") Long replyId) {

        //从请求头中获取token
        String token = request.getHeader("Authorization");
        //从redis中通过token获取用户信息
        User userFromRedis = userFromRedisUtil.getUserFromRedis(token);

        TopicReplyComment reply = topicService.getReplyById(replyId);
        if (reply != null) {
            //需要从es中删除，先Mq发从请求信息
            rabbitTemplate.convertAndSend(MqConstants.TOPIC_REPLY_EXCAHGNE, MqConstants.TOPIC_REPLY_DELETE_KEY, reply.getReplyId());
            //从数据库中删除回复
            topicService.deleteReplyByReplyId(userFromRedis, reply);
        }
        return JsonResult.success();
    }
}