package com.life.square.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.life.square.pojo.ArticleCategoryEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author chunming
 * @date 2022-09-01 12:13:30
 */
@Mapper
public interface ArticleCategoryMapper extends BaseMapper<ArticleCategoryEntity> {
}
