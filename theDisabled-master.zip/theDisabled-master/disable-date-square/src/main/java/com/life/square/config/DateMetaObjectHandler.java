package com.life.square.config;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author Chunming Liu In 2022/08/27
 */
@Primary
@Component
public class DateMetaObjectHandler implements MetaObjectHandler {
    @Override
    public void insertFill(MetaObject metaObject) {
        if (metaObject.hasGetter("createTime") && metaObject.getGetterType("createTime").getTypeName().contains("LocalDateTime")) {
            this.setFieldValByName("createTime", LocalDateTime.now(), metaObject);
        }
        if (metaObject.hasGetter("createTime") && metaObject.getGetterType("createTime").getTypeName().contains(".Date")) {
            this.setFieldValByName("createTime", new Date(), metaObject);
        }

        if (metaObject.hasGetter("updateTime") && metaObject.getGetterType("updateTime").getTypeName().contains("LocalDateTime")) {
            this.setFieldValByName("updateTime", LocalDateTime.now(), metaObject);
        }
        if (metaObject.hasGetter("updateTime") && metaObject.getGetterType("updateTime").getTypeName().contains(".Date")) {
            this.setFieldValByName("updateTime", new Date(), metaObject);
        }
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        if (metaObject.hasGetter("updateTime") && metaObject.getGetterType("updateTime").getTypeName().contains("LocalDateTime")) {
            this.setFieldValByName("updateTime", LocalDateTime.now(), metaObject);
        }
        if (metaObject.hasGetter("updateTime") && metaObject.getGetterType("updateTime").getTypeName().contains(".Date")) {
            this.setFieldValByName("updateTime", new Date(), metaObject);
        }
    }
}
