package com.life.square.dao;

import com.life.square.pojo.Comment;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chunming Liu In 2022/08/27
 */
@Repository
public interface CommentRepository extends ElasticsearchRepository<Comment, Integer> {
}
