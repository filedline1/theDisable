package com.life.square.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.life.square.pojo.ArticleEntity;
import com.life.square.vo.ArticlePageVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

/**
 * @author chunming
 * @date 2022-09-01 12:15:27
 */
@Mapper
public interface ArticleMapper extends BaseMapper<ArticleEntity> {
    Page<ArticlePageVo> selectPageCustom(Page<Object> objectPage, @Param("categoryId") Integer categoryId);

    /**
     * 文章阅读量+1
     *
     * @param id id
     */
    @Update("update tb_disable_data_article set reading_volume=reading_volume+1 where id=#{id}")
    void addReadingVolume(@Param("id") Long id);

    @Update("update tb_disable_data_article set likes=likes+1 where id=#{id}")
    void likeArticle(Long id);
}
