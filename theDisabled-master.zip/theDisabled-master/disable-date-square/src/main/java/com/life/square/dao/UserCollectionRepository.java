package com.life.square.dao;

import com.life.square.pojo.UserCollection;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chunming Liu In 2022/08/27
 */
@Repository
public interface UserCollectionRepository extends ElasticsearchRepository<UserCollection, Integer> {
}
