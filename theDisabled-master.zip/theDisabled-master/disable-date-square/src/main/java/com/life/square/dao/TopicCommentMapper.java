package com.life.square.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.life.square.pojo.TopicComment;
import com.life.square.pojo.TopicReplyComment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @author Chunming Liu In 2022/08/21
 */
@Mapper
public interface TopicCommentMapper extends BaseMapper<TopicComment> {
    @Select("select * from tb_disable_date_topic_comment where id=#{parentCommentId}")
    TopicComment selectByParentCommentId(@Param("parentCommentId") Long parentCommentId);
}
