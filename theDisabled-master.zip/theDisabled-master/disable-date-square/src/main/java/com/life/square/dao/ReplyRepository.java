package com.life.square.dao;

import com.life.square.pojo.Reply;
import com.life.square.pojo.Video;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chunming Liu In 2022/08/27
 */
@Repository
public interface ReplyRepository extends ElasticsearchRepository<Reply, Integer> {
}
