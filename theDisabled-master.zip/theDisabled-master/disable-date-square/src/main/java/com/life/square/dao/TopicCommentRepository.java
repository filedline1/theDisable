package com.life.square.dao;

import com.life.square.pojo.TopicComment;
import com.life.square.pojo.Video;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chunming Liu In 2022/08/27
 */
@Repository
public interface TopicCommentRepository extends ElasticsearchRepository<TopicComment, Long> {
}
