package com.life.square.controller;

import com.life.square.common.JsonResult;
import com.life.square.common.PageJsonResult;
import com.life.square.dtos.ArticleCategoryDTO;
import com.life.square.dtos.ArticleDTO;
import com.life.square.pojo.ArticleEntity;
import com.life.square.service.ArticleService;
import com.life.square.vo.ArticleCategoryVo;
import com.life.square.vo.ArticlePageVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

/**
 * 文章
 *
 * @author chunming
 * @date 2022-09-01 10:05:42
 */
@Api(tags = "文章")
@RequestMapping("article")
@RestController
public class ArticleController {

    final ArticleService articleService;

    public ArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @ApiOperation("文章分类分页")
    @GetMapping("category/queryPage")
    public PageJsonResult<List<ArticleCategoryVo>> queryCategory(@RequestParam(defaultValue = "1") Long page,
                                                                 @RequestParam(defaultValue = "10") Long size) {
        return articleService.queryCategory(page, size);
    }

    @ApiOperation("文章分类添加")
    @PostMapping("category/create")
    public JsonResult<Object> createCategory(@RequestBody ArticleCategoryDTO articleCategoryDTO) {
        articleService.createCategory(articleCategoryDTO);
        return JsonResult.success(Collections.singletonMap("id", articleCategoryDTO.getId()));
    }

    @ApiOperation("文章分类更新")
    @PostMapping("category/update")
    public JsonResult<Object> updateCategory(@RequestBody ArticleCategoryDTO articleCategoryDTO) {
        articleService.updateCategory(articleCategoryDTO);
        return JsonResult.success();
    }

    @ApiOperation("文章分类删除")
    @DeleteMapping("category/delete")
    public JsonResult<Object> deleteCategory(@RequestBody List<Integer> ids) {
        articleService.deleteCategory(ids);
        return JsonResult.success();
    }

    @ApiOperation("文章分页")
    @GetMapping("queryPage")
    public PageJsonResult<List<ArticlePageVo>> queryArticle(@RequestParam(defaultValue = "") Integer categoryId,
                                                            @RequestParam(defaultValue = "1") Long page,
                                                            @RequestParam(defaultValue = "10") Long size) {
        return articleService.queryArticle(categoryId, page, size);
    }

    @ApiOperation("文章发布")
    @PostMapping("create")
    public JsonResult<Object> createArticle(@RequestBody ArticleDTO articleDTO) {
        articleService.save(articleDTO);
        return JsonResult.success(Collections.singletonMap("id", articleDTO.getId()));
    }

    @ApiOperation("文章详情")
    @PostMapping("detail")
    public JsonResult<ArticleEntity> createArticle(@RequestParam Long id) {
        articleService.addReadingVolume(id);
        return JsonResult.success(articleService.getById(id));
    }

    @ApiOperation("文章更新")
    @PostMapping("update")
    public JsonResult<Object> updateArticle(@RequestBody ArticleDTO articleDTO) {
        articleService.updateById(articleDTO);
        return JsonResult.success();
    }

    @ApiOperation("文章删除")
    @DeleteMapping("delete")
    public JsonResult<Object> deleteArticle(@RequestBody List<Long> ids) {
        articleService.removeByIds(ids);
        return JsonResult.success();
    }

    @ApiOperation("文章点赞")
    @PostMapping("like")
    public JsonResult<Object> likeArticle(@RequestParam Long id) {
        articleService.likeArticle(id);
        return JsonResult.success();
    }
}