package com.life.userinfo.manage.db;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author chunming
 * @date 2022-08-06 18:13:05
 */
@Component
public class DataStronger<T> {
    private final Map<String, T> db;

    private final Map<String, String> dbIndex;

    public DataStronger() {
        this.db = new ConcurrentHashMap<>();
        this.dbIndex = new ConcurrentHashMap<>();
    }

    public void save(String index, T data) {
        db.put(index, data);
    }

    public void creteIndex(String index, String value) {
        dbIndex.put(index, value);
    }

    public T query(String index) {
        return db.getOrDefault(index, null);
    }

    public String queryIndex(String index) {
        return dbIndex.getOrDefault(index, null);
    }
}
