package com.life.userinfo.manage.runner;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.listener.PageReadListener;
import com.life.userinfo.manage.entity.UserinfoEntity;
import com.life.userinfo.manage.service.DataManageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author chunming
 * @date 2022-08-06 19:10:43
 */
@Slf4j
@Component
public class ExcelDataLoader implements CommandLineRunner {
    final DataManageService dataManageService;
    final String defaultPrefix = "classpath:";
    @Value("${data.path}")
    String filePath;

    public ExcelDataLoader(DataManageService dataManageService) {this.dataManageService = dataManageService;}

    @Override
    public void run(String... strings) {
        loadData ();
    }

    public void loadData() {
        List<UserinfoEntity> cache = new ArrayList<> ();

        if (filePath.contains ( defaultPrefix )) {
            try {
                Resource resource = new DefaultResourceLoader ().getResource ( filePath );
                filePath = resource.getFile ().getAbsolutePath ();
            } catch (IOException e) {
                log.error ( "该excel加载失败，异常 #{}", e.getMessage () );
                throw new RuntimeException ( "加载excel数据失败，请检查程序excel路径" );
            }
        }
        try {
            EasyExcel.read ( filePath, UserinfoEntity.class, new PageReadListener<UserinfoEntity> ( cache::addAll ) ).sheet ().doRead ();
        } catch (Exception e) {
            log.error ( "该excel加载失败，异常 #{}", e.getMessage () );
        }
        log.info ( "加载信息：{} 条", cache.size () );
        boolean save = dataManageService.save ( cache );
        if (!save) {
            throw new RuntimeException ( "加载excel数据失败，请检查excel路径和手机号都有值" );
        }
    }
}
