package com.life.userinfo.manage.controller;

import com.life.userinfo.manage.common.JsonResult;
import com.life.userinfo.manage.entity.UserinfoEntity;
import com.life.userinfo.manage.service.DataManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author chunming
 * @date 2022-08-06 17:14:03
 */
@RestController
public class ManageController {

    @Autowired
    DataManageService dataManageService;

    @GetMapping("queryUserInfo")
    public JsonResult<UserinfoEntity> queryUserInfo(@RequestParam("tel") String tel) {
        UserinfoEntity userinfoEntity = dataManageService.queryUserInfo(tel);
        return userinfoEntity == null ? JsonResult.error("未查到信息") : JsonResult.success(userinfoEntity);
    }

    @GetMapping("queryUserInfoById")
    public JsonResult<UserinfoEntity> queryUserInfoById(@RequestParam("idCode") String idCode) {
        UserinfoEntity userinfoEntity = dataManageService.queryUserInfoById(idCode);
        return userinfoEntity == null ? JsonResult.error("未查到信息") : JsonResult.success(userinfoEntity);
    }
}
