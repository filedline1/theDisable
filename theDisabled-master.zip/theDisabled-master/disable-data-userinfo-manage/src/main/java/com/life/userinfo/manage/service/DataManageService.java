package com.life.userinfo.manage.service;

import cn.hutool.json.JSONUtil;
import com.life.userinfo.manage.db.DataStronger;
import com.life.userinfo.manage.entity.UserinfoEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author chunming
 * @date 2022-08-06 18:11:58
 */
@Slf4j
@Service
public class DataManageService {
    final DataStronger<UserinfoEntity> db;

    public DataManageService(DataStronger<UserinfoEntity> db) {
        this.db = db;
    }

    public boolean save(List<UserinfoEntity> userinfoEntities) {
        try {
            userinfoEntities.forEach(entity -> {
                db.save(entity.getCellPhone(), entity);
                db.creteIndex(entity.getHeadOfHouseholdIdNumber(), entity.getCellPhone());
            });
        } catch (Exception e) {
            log.error("存储数据失败, 异常为 #{}", ExceptionUtils.getStackTrace(e));
            return false;
        }
        return true;
    }

    public UserinfoEntity queryUserInfo(String tel) {
        UserinfoEntity userinfoEntity = db.query(tel);
        log.info("来源手机号：#{}, 查询到数据：#{}", tel, userinfoEntity == null ? null : JSONUtil.toJsonStr(userinfoEntity));
        return userinfoEntity;
    }

    public UserinfoEntity queryUserInfoById(String idCode) {
        String cellPhoneIndex = db.queryIndex(idCode);
        if (cellPhoneIndex == null) {
            log.warn("来源身份证号：#{}, 无此信息", idCode);
            return null;
        }
        log.info("来源身份证号：#{}, 查询到数据：#{}", idCode, cellPhoneIndex);
        return queryUserInfo(cellPhoneIndex);
    }
}
