package com.life.userinfo.manage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author chunming
 * @date 2022-08-06 16:56:59
 */
@SpringBootApplication
public class App {
    public static void main(String[] args) {
        SpringApplication.run ( App.class, args );
    }
}
