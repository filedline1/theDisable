package com.life.userinfo.manage;

import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.listener.PageReadListener;
import com.life.userinfo.manage.entity.UserinfoEntity;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

/**
 * @author chunming
 * @date 2022-08-06 17:50:51
 */
@Slf4j
public class ExcelDataAppTest {

    @Test
    public void readDataTest() {
        String fileName = "/Users/peotry/Documents/peotry/resultCode/extra/theDisabled/disable-data-userinfo-manage/src/main/resources/data.xlsx";
        // 这里 需要指定读用哪个class去读，然后读取第一个sheet 文件流会自动关闭
        // 这里每次会读取100条数据 然后返回过来 直接调用使用数据就行
        EasyExcel.read ( fileName, UserinfoEntity.class,
                new PageReadListener<UserinfoEntity> ( dataList -> {
                    for (UserinfoEntity demoData : dataList) {
                        log.info ( "读取到一条数据 #{}", JSONUtil.toJsonStr ( demoData ) );
                    }
                } )
        ).sheet ().doRead ();
    }
}
