package com.life.chat.util.exception;

import com.life.chat.service.ChatFriendsService;
import com.life.chat.service.LoginService;
import com.life.chat.util.Result;
import com.life.chat.util.ResultGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Collections;


@Controller
public class TeacherAdminController {
    @Autowired
    ChatFriendsService chatFriendsService;
    @Autowired
    LoginService loginService;

    @GetMapping("/lk/{username}")
    @ResponseBody
    public Result list(@PathVariable("username") String username) {
        String uid = loginService.lkUseridByUsername(username);
        if (uid == null) {
            return ResultGenerator.genErrorResult(500, "未查询到此用户");
        }
        return ResultGenerator.genSuccessResult(Collections.singletonMap("userinfo", chatFriendsService.LkUserinfoByUserid(uid)));
    }
}