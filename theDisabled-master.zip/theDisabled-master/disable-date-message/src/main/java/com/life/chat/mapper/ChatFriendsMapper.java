package com.life.chat.mapper;

import com.life.chat.bean.ChatFriends;
import com.life.chat.bean.Userinfo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ChatFriendsMapper {
    //查询所有的好友
    List<ChatFriends> LookUserAllFriends(String userid);

    //插入好友
    void InsertUserFriend(ChatFriends chatFriends);

    //删除聊天好友
    void DeleteUserFriend(ChatFriends chatFriends);

    /**
     * 更新好友关系
     *
     * @param chatFriends 好友
     */
    void updateUserFriend(ChatFriends chatFriends);

    //判断是否加好友
    Integer JustTwoUserIsFriend(ChatFriends chatFriends);

    //查询用户的信息
    Userinfo LkUserinfoByUserid(String userid);

    ChatFriends selectFriend(ChatFriends chatFriends);
}