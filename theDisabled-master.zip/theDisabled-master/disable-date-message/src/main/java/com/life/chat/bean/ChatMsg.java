package com.life.chat.bean;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Accessors(chain = true)
public class ChatMsg {
    /**
     * 消息ID
     */
    private Integer id;
    /**
     * 当前发送消息的userID
     */
    private String senduserid;
    /**
     * 当前接受方 userID
     */
    private String reciveuserid;
    /**
     * 发起时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date sendtime;
    /**
     * 消息类型，文本（文本+表情、表情）
     */
    private String msgtype;
    /**
     * 消息内容
     */
    private String sendtext;
    /**
     * 消息状态 0-未读，1-已读
     */
    private Integer msgstatus;
}