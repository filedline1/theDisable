package com.life.chat.controller;


import com.life.chat.bean.Login;
import com.life.chat.service.LoginService;
import com.life.chat.util.Md5Util;
import com.life.chat.util.Result;
import com.life.chat.util.ResultGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;

@Controller
public class LoginCtrl {

    @Autowired
    LoginService loginService;

    @GetMapping("/")
    public String tologin() {
        return "/user/login";
    }

    /**
     * 登陆
     */
    @PostMapping("/justlogin")
    @ResponseBody
    public Result login(@RequestBody Login login, HttpSession session) {
        login.setPassword(Md5Util.StringInMd5(login.getPassword()));
        System.out.println(login);
        String userid = loginService.justLogin(login);
        if (userid == null) {
            return ResultGenerator.genErrorResult(500, "账号或者密码错误");
        }
//        session.setAttribute ( "userid", userid );
        return ResultGenerator.genSuccessResult("登录成功");
    }
}
