package com.life.chat.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.life.chat.bean.ChatFriends;
import com.life.chat.bean.ChatMsg;
import com.life.chat.mapper.ChatFriendsMapper;
import com.life.chat.service.ChatFriendsService;
import com.life.chat.service.ChatMsgService;
import com.life.chat.util.EmojiFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpSession;
import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ServerEndpoint 注解是一个类层次的注解，它的功能主要是将目前的类定义成一个websocket服务器端,
 * 注解的值将被用于监听用户连接的终端访问URL地址,客户端可以通过这个URL来连接到WebSocket服务器端
 * ServerEndpoint 可以把当前类变成websocket服务类
 */
@Slf4j
@Controller
@ServerEndpoint(value = "/websocket/{userno}")
public class ChatWebSocket {
    /**
     * concurrent包的线程安全Set，用来存放每个客户端对应的MyWebSocket对象。若要实现服务端与单一客户端通信的话，可以使用Map来存放，其中Key可以为用户标识
     */
    public final static ConcurrentHashMap<String, ChatWebSocket> webSocketSet = new ConcurrentHashMap<>();
    /**
     * 这里使用静态，让 service 属于类
     */
    private static ChatMsgService chatMsgService;
    /**
     * 静态变量，用来记录当前在线连接数。应该把它设计成线程安全的。
     */
    private static int onlineCount = 0;
    /**
     * 与某个客户端的连接会话，需要通过它来给客户端发送数据
     */
    private Session WebSocketsession;

    private static ChatFriendsService chatFriendsService;
    /**
     * 当前发消息的人员编号
     */
    private String userno = "";

    @Autowired
    public void setChatFriendsService(ChatFriendsService chatFriendsService) {
        ChatWebSocket.chatFriendsService = chatFriendsService;
    }

    public static synchronized int getOnlineCount() {
        return onlineCount;
    }

    public static synchronized void addOnlineCount() {
        ChatWebSocket.onlineCount++;
    }

    public static synchronized void subOnlineCount() {
        ChatWebSocket.onlineCount--;
    }

    // 注入的时候，给类的 service 注入
    @Autowired
    public void setChatService(ChatMsgService chatService) {
        ChatWebSocket.chatMsgService = chatService;
    }

    /**
     * 连接建立成功调用的方法
     * <p>
     * session 可选的参数。session为与某个客户端的连接会话，需要通过它来给客户端发送数据
     */
    @OnOpen
    public void onOpen(@PathParam(value = "userno") String param, Session WebSocketsession) {
        //接收到发送消息的人员编号
        userno = param;
        this.WebSocketsession = WebSocketsession;
        //加入map中
        if (webSocketSet.remove(param)==null) {
            subOnlineCount();
        }
        webSocketSet.put(param, this);
        addOnlineCount();     //在线数加1
        log.info("有新连接加入！当前在线人数为" + getOnlineCount());
    }

    /**
     * 判断websocket连接是否关闭
     *
     * @param param
     * @return
     */
    public boolean isClose(@PathParam(value = "userno") String param) {
        return !webSocketSet.containsKey(param);
    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        if (!userno.equals("")) {
            webSocketSet.remove(userno); //从set中删除
            subOnlineCount();     //在线数减1
            //System.out.println("有一连接关闭！当前在线人数为" + getOnlineCount());
        }
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param chatmsg 客户端发送过来的消息
     * @param session 可选的参数
     */
    @SuppressWarnings("unused")
    @OnMessage
    public void onMessage(String chatmsg, Session session) {
        JSONObject jsonObject;
        try {
            jsonObject = JSONObject.parseObject(chatmsg);
        } catch (Exception e) {
            log.error("无效消息，#{}", chatmsg);
            return;
        }
        // 给指定的人发消息
        ChatMsg chatMessage = jsonObject.toJavaObject(ChatMsg.class);
        // 检查对方和发送人关系是否被解除
        checkFriendStatus(chatMessage);

        sendToUser(chatMessage);
        // 服务端推送消息提示给用户
        // ChatMsg chatMessage = jsonObject.toJavaObject(ChatMsg.class);
        // 若用户在后台或者不在线，服务器推送消息
        // if ("0".equals(chatMessage.getMsgtype())) {
        // chatMessage.setSendtext ( "收到" + chatMessage.getSenduserid () + "发来的消息" );
        // 将推送信息默认设置为已读
        // chatMessage.setMsgstate ( 1 );
        // sendToUser(chatMessage);
        // }
        // sendAll(message);
    }

    private void checkFriendStatus(ChatMsg chatMessage) {
        ChatFriends chatFriends = new ChatFriends().setFuserid(chatMessage.getSenduserid()).setUserid(chatMessage.getReciveuserid());
        ChatFriends selectFriend = chatFriendsService.selectFriend(chatFriends);
        if (selectFriend != null && selectFriend.getState() == 0) {
            chatFriendsService.updateUserFriend(selectFriend);
        }
    }

    /**
     * 给指定的人发送消息
     *
     * @param chatMsg 消息对象
     */
    public void sendToUser(ChatMsg chatMsg) {
        String reviceUserid = chatMsg.getReciveuserid();
        String sendMessage = chatMsg.getSendtext();
//        sendMessage = EmojiFilter.filterEmoji(sendMessage);
        ChatMsg msgContext = new ChatMsg().setMsgtype(chatMsg.getMsgtype())
                .setReciveuserid(reviceUserid).setSenduserid(userno).setSendtext(sendMessage).setMsgstatus(0);
        // 过滤输入法输入的表情
        chatMsgService.InsertChatMsg(msgContext);
        try {
            if (webSocketSet.get(reviceUserid) != null) {
                // webSocketSet.get ( reviceUserid ).sendMessage ( userno + "|" + sendMessage );
                log.info("WS-IM #{}-->>#{}, 消息：{}", chatMsg.getSenduserid(), chatMsg.getReciveuserid(), chatMsg.getSendtext());
                webSocketSet.get(reviceUserid).sendMessage(JSON.toJSONString(msgContext));
            }
            // else { webSocketSet.get ( userno ).sendMessage ( "0" + "|" + "当前用户不在线" );}
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 给所有人发消息
     *
     * @param message
     */
    private void sendAll(String message) {
        String sendMessage = message.split("[|]")[1];
        //遍历HashMap
        for (String key : webSocketSet.keySet()) {
            try {
                //判断接收用户是否是当前发消息的用户
                if (!userno.equals(key)) {
                    webSocketSet.get(key).sendMessage(sendMessage);
                    System.out.println("key = " + key);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 发生错误时调用
     *
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {
        error.printStackTrace();
    }

    /**
     * 这个方法与上面几个方法不一样。没有用注解，是根据自己需要添加的方法。
     *
     * @param message
     * @throws IOException
     */
    public void sendMessage(String message) throws IOException {
        this.WebSocketsession.getBasicRemote().sendText(message);
        // this.session.getAsyncRemote().sendText(message);
    }

}

