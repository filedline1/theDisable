package com.life.chat.mapper;

import com.life.chat.bean.Login;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LoginMapper {
    //判断登录
    String justLogin(Login login);

    //根据账号查询用户ID
    String lkUseridByUsername(String username);
}
