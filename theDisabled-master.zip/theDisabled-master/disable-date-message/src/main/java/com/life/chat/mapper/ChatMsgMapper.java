package com.life.chat.mapper;

import com.life.chat.bean.ChatMsg;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ChatMsgMapper {
    //插入聊天记录
    Integer InsertChatMsg(ChatMsg chatMsg);

    //查询聊天记录
    List<ChatMsg> LookTwoUserMsg(@Param("chatMsg") ChatMsg chatMsg);

    //查询聊天记录
    List<ChatMsg> LookPersonUserMsg(@Param("chatMsg") ChatMsg chatMsg);

    //将消息设置为已读
    int alreadyRead(ChatMsg chatMsg);

    //获取指定收信人的未读信息
    List<ChatMsg> unreadMessages(@Param("senduserid") Integer senduserid, @Param("reciveuserid") Integer reciveuserid);

    /**
     * 查询重新建立好友的后面的消息
     *
     * @param chatMsg 消息体
     * @return 消息
     */
    List<ChatMsg> LookTwoUserNowFriendMsg(ChatMsg chatMsg);
}