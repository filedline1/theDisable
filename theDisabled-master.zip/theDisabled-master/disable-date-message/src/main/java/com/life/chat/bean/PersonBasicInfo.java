package com.life.chat.bean;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
@Data
public class PersonBasicInfo {

    private Integer personId;

    private String personName;

    private Integer sex;

    private Integer age;

    private String phone;

    private String workAddr;

    private String householdAddr;

    private String maritalStatus;

    private Integer height;

    private Integer weight;

    private String degree;

    private Integer income;

    private String occupation;

    private String housingStatus;

    private String carStatus;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date expectedMarryTime;

    private String personIntro;

    private String personSign;

    private String longitude;

    private String latitude;

    private String wechat;

    private String wechatCodeImagesPath;

    private String qq;

    private String email;
}

