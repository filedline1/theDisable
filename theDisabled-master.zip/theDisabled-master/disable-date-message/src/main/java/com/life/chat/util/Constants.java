package com.life.chat.util;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
public class Constants {

    public static final String IMAGE_PATH = "D:\\chat\\";

    public static final String AUDIO_PATH = "D:\\audio\\";

}
