package com.life.chat.controller;

import com.alibaba.fastjson.JSONObject;
import com.life.chat.bean.ChatFriends;
import com.life.chat.bean.ChatMsg;
import com.life.chat.bean.Userinfo;
import com.life.chat.common.JsonResult;
import com.life.chat.common.PersonBasicInfoRestClient;
import com.life.chat.service.ChatFriendsService;
import com.life.chat.service.ChatMsgService;
import com.life.chat.service.LoginService;
import com.life.chat.util.*;
import org.apache.commons.io.FilenameUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;

import static com.life.chat.controller.ChatWebSocket.webSocketSet;

@Controller
public class ChatCtrl {
    @Autowired
    ChatFriendsService chatFriendsService;
    @Autowired
    ChatMsgService chatMsgService;
    @Autowired
    LoginService loginService;
    @Autowired
    PersonBasicInfoRestClient client;
    @Autowired
    ChatWebSocket chatWebSocket;

    /**
     * 上传聊天图片
     **/
    @PostMapping(value = "/chat/upimg")
    @ResponseBody
    public JSONObject upImg(@RequestParam(value = "file", required = false) MultipartFile file) throws IOException {
        JSONObject res = new JSONObject();
        JSONObject resUrl = new JSONObject();
        LocalDate today = LocalDate.now();
        Instant timestamp = Instant.now();
        String ext = FilenameUtils.getExtension(file.getOriginalFilename());
        String filenames = today + String.valueOf(timestamp.toEpochMilli()) + "." + ext;
        final File imageFile = new File(Constants.IMAGE_PATH + filenames);
        file.transferTo(imageFile);
        CompressImage.compressImage(imageFile);
        resUrl.put("src", "/pic/" + filenames);
        res.put("msg", "");
        res.put("code", 0);
        res.put("data", resUrl);
        return res;
    }

    /**
     * 查询用户
     */
    @PostMapping("/chat/lkuser/{username}")
    @ResponseBody
    public Result lookUser(@PathVariable("username") String username) {
        username = EmojiFilter.filterEmoji(username);
        String uid = loginService.lkUseridByUsername(username);
        if (uid == null) {
            return ResultGenerator.genErrorResult(500, "未查询到此用户");
        }
        Map<String, Object> map = new HashMap<>();
        return ResultGenerator.genSuccessResult(map);
    }

    /**
     * 添加聊天好友
     */
    @PostMapping("/chat/adduser/{fuserId}/{userId}")
    @ResponseBody
    public Result toFriendUserIdChat(@PathVariable String fuserId, @PathVariable String userId) {
        //        String userid=(String)session.getAttribute("userid");
        if (userId.equals(fuserId)) {
            return ResultGenerator.genErrorResult(500, "不能添加自己为好友");
        }
        ChatFriends chatFriends = new ChatFriends();
        chatFriends.setUserid(userId).setFuserid(fuserId);
        Integer integer = chatFriendsService.JustTwoUserIsFriend(chatFriends);
        if (integer == null) {
            //如果不存在好友关系插入好友关系
            chatFriendsService.InsertUserFriend(chatFriends);
            chatFriendsService.InsertUserFriend(new ChatFriends().setFuserid(userId).setUserid(fuserId));
        }
        return ResultGenerator.genSuccessResult();
    }

    /**
     * 删除好友关系
     *
     * @param fuserId 用户的好友ID
     * @param userId  当前用户ID
     * @return 状态
     */
    @PostMapping("/chat/delete/{fuserId}/{userId}")
    @ResponseBody
    public Result deleteChat(@PathVariable String fuserId, @PathVariable String userId) {
        chatFriendsService.DeleteUserFriend(new ChatFriends().setFuserid(fuserId).setUserid(userId));
        return ResultGenerator.genSuccessResult();
    }

    /**
     * 跳转到聊天
     */
    @GetMapping("/chat/ct")
    public String toChat() {
        return "/chat/chats";
    }

    /***
     * 查询用户的好友
     * */
    @PostMapping("/chat/lkfriends/{userid}")
    @ResponseBody
    public Result lookFriends(@PathVariable String userid) {
        // String userid = (String) session.getAttribute("userid");
        return ResultGenerator.genSuccessResult(chatFriendsService.LookUserAllFriends(userid));
    }


    /***
     * 查询两个用户之间的聊天记录
     * */
    @PostMapping("/chat/lkuschatmsg/{reviceuserid}/{userid}")
    @ResponseBody
    public Result lookFriendsMessage(@PathVariable("reviceuserid") String reviceuserid, @PathVariable String userid) {
        // String userid = (String) session.getAttribute("userid");
        return ResultGenerator.genSuccessResult(chatMsgService.LookTwoUserMsg(new ChatMsg().setSenduserid(userid).setReciveuserid(reviceuserid)));
    }

    /***
     * 查询与某个用户的聊天记录
     * */
    @PostMapping("/chat/lookPersonMessage/{reviceuserid}/{userid}")
    @ResponseBody
    public Result lookPersonMessage(@PathVariable("reviceuserid") String reviceuserid, @PathVariable String userid) {
        // String userid = (String) session.getAttribute("userid");
        return ResultGenerator.genSuccessResult(chatMsgService.LookTwoUserMsg(new ChatMsg().setSenduserid(userid).setReciveuserid(reviceuserid)));
    }


    /***
     * Ajax上传web界面js录制的音频数据
     * */
    @PostMapping("/chat/audio")
    @ResponseBody
    public JSONObject upAudio(@RequestParam(value = "file") MultipartFile file) throws IOException {
        JSONObject res = new JSONObject();
        JSONObject resUrl = new JSONObject();
        LocalDate today = LocalDate.now();
        Instant timestamp = Instant.now();
        String filenames = today + String.valueOf(timestamp.toEpochMilli()) + ".mp3";
        String pathname = "D:\\chat\\" + filenames;
        file.transferTo(new File(pathname));
        resUrl.put("src", "/pic/" + filenames);
        res.put("msg", "");
        res.put("data", resUrl);
        return res;
    }

    @PostMapping("/chat/unreadMessage")
    @ResponseBody
    //获取指定收信人的未读信息
    public Result unreadMessages(@RequestParam("senduserid") Integer senduserid, @RequestParam("reciveuserid") Integer reciveuserid) {
        return ResultGenerator.genSuccessResult(chatMsgService.unreadMessages(senduserid, reciveuserid));
    }

    @PostMapping("/chat/alreadyRead")
    @ResponseBody
    //将消息设置为已读
    public Result alreadyRead(@RequestBody ChatMsg chatMsg) {
        final int i = chatMsgService.alreadyRead(chatMsg);
        if (i > 0) {
            return ResultGenerator.genSuccessResult();
        } else {
            return ResultGenerator.genErrorResult(500,"已读失败");
        }
    }

    @PostMapping("/chat/websocketIsOnline")
    @ResponseBody
    //判断websocket连接是否在线
    public Result websocketIsOnline(@Param("userno") String userno) {
        if (webSocketSet.containsKey(userno)) {
            return ResultGenerator.genSuccessResult((userno + "用户websocket在线"));
        } else {
            return ResultGenerator.genErrorResult(500, userno + "用户websocket不在线");
        }
    }

    //推荐列表
    @PostMapping("/chat/recommendList")
    @ResponseBody
    public Result recommendList(@RequestParam("userId") Integer userId) throws Exception {
        List<Userinfo> recommendBeforeList;
        try {
            recommendBeforeList = client.getRecommendList(userId);
        } catch (Exception e) {
            recommendBeforeList = Collections.emptyList();
        }
        //筛选在线的人数
        List<Userinfo> recommendAfterList = new ArrayList<>();
        for (Userinfo userinfo : recommendBeforeList) {
            String userno = userinfo.getUserid();
            if (!chatWebSocket.isClose(userno)) {
                recommendAfterList.add(userinfo);
            }
        }
        return ResultGenerator.genSuccessResult(recommendAfterList);
    }

}
