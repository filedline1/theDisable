package com.life.chat.service;

import com.life.chat.bean.ChatFriends;
import com.life.chat.bean.ChatMsg;
import com.life.chat.mapper.ChatFriendsMapper;
import com.life.chat.mapper.ChatMsgMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.Date;
import java.util.List;

@Service
public class ChatMsgService {
    @Autowired
    ChatMsgMapper chatMsgMapper;
    @Autowired
    ChatFriendsMapper chatFriendsMapper;

    public void InsertChatMsg(ChatMsg chatMsg) {
        chatMsgMapper.InsertChatMsg(chatMsg);
    }

    public List<ChatMsg> LookTwoUserMsg(ChatMsg chatMsg) {
        String senduserid = chatMsg.getSenduserid();
        String reciveuserid = chatMsg.getReciveuserid();
        ChatFriends chatFriends = chatFriendsMapper.selectFriend(new ChatFriends().setUserid(senduserid).setFuserid(reciveuserid));

        Assert.state(chatFriends != null, "查询失败");
        List<ChatMsg> chatMsgs;
        if (chatFriends.getState() == 1 && chatFriends.getTimes() == 0) {
            // 未被解除过好友，有关系全部消息
            chatMsgs = chatMsgMapper.LookTwoUserMsg(chatMsg);
        } else {
            // 重新建立好友关系，后米娜的消息
            Date lastTime = chatFriends.getLastTime();
            chatMsg.setSendtime(lastTime);
            chatMsgs = chatMsgMapper.LookTwoUserNowFriendMsg(chatMsg);
        }
        return chatMsgs;
    }

    public List<ChatMsg> LookPersonUserMsg(ChatMsg chatMsg) {
        return chatMsgMapper.LookTwoUserMsg(chatMsg);
    }

    //将消息设置为已读
    public int alreadyRead(ChatMsg chatMsg) {
        final int i = chatMsgMapper.alreadyRead(chatMsg);
        return i;
    }

    //获取指定收信人的未读信息
    public List<ChatMsg> unreadMessages(Integer senduserid, Integer reciveuserid) {
        final List<ChatMsg> chatMsgs = chatMsgMapper.unreadMessages(senduserid, reciveuserid);
        return chatMsgs;
    }

}
