package com.life.chat.mq;

import com.life.chat.common.MqConstants;
import com.life.chat.controller.ChatWebSocket;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SystemMessageListener {

    @Autowired
    ChatWebSocket ChatWebSocket;

    @Async
    @RabbitListener(queues = MqConstants.DIARY_NOTICE_QUEUE)
    public void msgPush(String msg){

    }
}