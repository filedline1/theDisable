package com.life.chat.common;

public interface MqConstants {
    String BUSINESS_NOTICE_EXCAHGNE = "notice.topic";
    String DIARY_NOTICE_QUEUE = "diary.notice.queue";
    String NOYICE_CONTENT_KEY = "notice.content";
}
