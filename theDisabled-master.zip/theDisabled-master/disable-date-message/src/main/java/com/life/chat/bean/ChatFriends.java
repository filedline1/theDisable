package com.life.chat.bean;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Accessors(chain = true)
public class ChatFriends {
    private Integer id;

    private String userid;

    private String fuserid;

    private String nickname;

    private String uimg;
    /**
     * 好友状态 0-非好友（被解除），1-是好友（默认值）
     */
    private Integer state;
    /**
     * 关系建立时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
    /**
     * 信息更新
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;
    /**
     * 最后一次删除好友的时间，根据这个时间消息
     */
    private Date lastTime;
    /**
     * 删除好友建立次数
     */
    private Integer times;
}