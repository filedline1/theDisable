package com.life.chat.config;

import com.life.chat.common.MqConstants;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MqConfig {
    //实现交换机的定义
    @Bean
    public TopicExchange businessNoticeExchange(){
        // true:持久化
        return new TopicExchange(MqConstants.BUSINESS_NOTICE_EXCAHGNE, true, false);
    }

    //定义消息队列
    @Bean
    public Queue diaryNoticeQueue(){
        return new Queue(MqConstants.DIARY_NOTICE_QUEUE, true);
    }

    //定义绑定关系
    @Bean
    public Binding likeCollectInsertQueueBinding(){
        return BindingBuilder.bind(diaryNoticeQueue()).to(businessNoticeExchange()).with(MqConstants.NOYICE_CONTENT_KEY);
    }
}
