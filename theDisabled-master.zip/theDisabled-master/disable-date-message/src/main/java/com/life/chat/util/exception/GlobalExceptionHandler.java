package com.life.chat.util.exception;// ...

import com.life.chat.util.Result;
import com.life.chat.util.ResultGenerator;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;

/**
 * 统一异常处理器
 */

@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * -------- 通用异常处理方法 --------
     **/
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Result error(Exception e) {
        e.printStackTrace();
        return ResultGenerator.genErrorResult(500, "系统出错");    // 通用异常结果
    }

    /**
     * -------- 指定异常处理方法 --------
     **/
    @ExceptionHandler(NullPointerException.class)
    @ResponseBody
    public Result error(NullPointerException e) {
        e.printStackTrace();
        return ResultGenerator.genErrorResult(500, "空指针异常");
    }

    @ExceptionHandler(HttpClientErrorException.class)
    @ResponseBody
    public Result error(IndexOutOfBoundsException e) {
        e.printStackTrace();
        return ResultGenerator.genErrorResult(ResultCodeEnum.HTTP_CLIENT_ERROR.getCode(), "");
    }

    /**
     * -------- 自定义定异常处理方法 --------
     **/
    @ExceptionHandler(CMSException.class)
    @ResponseBody
    public Result error(CMSException e) {
        e.printStackTrace();
        return ResultGenerator.genErrorResult(e.getCode(), e.getMessage());
    }
}