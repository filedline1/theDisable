package com.personInfo.bean;

/**
 * 公司
 *
 * @author chunming
 * @date 2022-08-30 17:59:48
 */
public class CompanyEntity {
    private Long id;
}
