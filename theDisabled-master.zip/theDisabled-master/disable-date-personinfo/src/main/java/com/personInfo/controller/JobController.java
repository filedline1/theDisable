package com.personInfo.controller;

import com.personInfo.common.JsonResult;
import com.personInfo.common.PageJsonResult;
import com.personInfo.dto.CompanyPhotoAlbumDTO;
import com.personInfo.dto.JobDTO;
import com.personInfo.dto.JobDeliveryRecordDTO;
import com.personInfo.service.JobDeliveryRecordService;
import com.personInfo.service.JobService;
import com.personInfo.vo.CompanyPhotoAlbumVo;
import com.personInfo.vo.JobDeliveryRecordVo;
import com.personInfo.vo.JobVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.List;

/**
 * 招聘
 *
 * @author Chunming Liu In 2022/08/21
 */
@Api(tags = "招聘")
@RequestMapping("job")
@RestController
public class JobController {
    final JobService jobService;
    final JobDeliveryRecordService jobDeliveryRecordService;
    @Resource
    HttpServletRequest request;

    public JobController(JobService jobService, JobDeliveryRecordService jobDeliveryRecordService) {
        this.jobService = jobService;
        this.jobDeliveryRecordService = jobDeliveryRecordService;
    }

    @ApiOperation("发布招聘")
    @PostMapping("publish")
    public JsonResult<Object> publishJob(@RequestBody JobDTO jobDTO) {
        jobService.add(jobDTO);
        return JsonResult.success(Collections.singletonMap("id", jobDTO.getId()));
    }

    @ApiOperation("更新招聘")
    @PostMapping("update")
    public JsonResult<Object> updateJob(@RequestBody JobDTO jobDTO) {
        jobService.update(jobDTO);
        return JsonResult.success();
    }

    @ApiOperation("查看招聘列表（分页搜索）")
    @GetMapping("queryPage")
    public PageJsonResult<List<JobVo>> queryJobPage(@ApiParam("经验要求：0-不限、1-在校生、2-应届生、3-1年以内、4-1-3年、5-3-5年、6-5-10年、7-10年以上") @RequestParam(defaultValue = "0") Integer experience,
                                                    @ApiParam("福利待遇：1-弹性工作制、2-底薪加提成、3-餐补、4-带薪年假、5-8小时工作制、6-保底工资、7-周末双休、8-五险、9-五险一金、10-房补、11-年终奖") @RequestParam(defaultValue = "0") Integer welfare,
                                                    @ApiParam("学历：0-不限、1-初中及以下、2-中专/中技、3-高中、4-大专、5-本科、6-硕士、7-博士") @RequestParam(defaultValue = "0") Integer education,
                                                    @ApiParam("薪资区间最小") @RequestParam(defaultValue = "0") Integer salaryMin,
                                                    @ApiParam("薪资区间最大") @RequestParam(defaultValue = "0") Integer salaryMax,
                                                    @ApiParam("公司名称") @RequestParam(defaultValue = "") String companyName,
                                                    @ApiParam("公司规模：0-不限、1-0-20人、2-20-90人、3-100-499人、4500-999人、5-1000-9999人、6-10000人以上") @RequestParam(defaultValue = "0") Integer companyWorkerNum,
                                                    @ApiParam() @RequestParam(defaultValue = "1") Integer page,
                                                    @ApiParam() @RequestParam(defaultValue = "10") Integer size) {
        return jobService.queryJobPage(experience, welfare, education, salaryMin, salaryMax, companyName, companyWorkerNum, page, size);
    }

    @ApiOperation("更新公司Logo")
    @PostMapping("updateLogo")
    public JsonResult<Object> updateLogo(@RequestParam Long jobId, @RequestParam String logo) {
        jobService.updateLogo(jobId, logo);
        return JsonResult.success();
    }

    @ApiOperation("上传公司相册")
    @PostMapping("uploadAlbum")
    public JsonResult<Object> uploadAlbum(@RequestBody CompanyPhotoAlbumDTO dto) {
        jobService.uploadAlbum(dto);
        return JsonResult.success(Collections.singletonMap("id", dto.getId()));
    }

    @ApiOperation("查看公司相册")
    @PostMapping("company/album/query")
    public PageJsonResult<List<CompanyPhotoAlbumVo>> queryAlbum(@RequestParam Long jobId,
                                                                @RequestParam(defaultValue = "1") Integer page,
                                                                @RequestParam(defaultValue = "10") Integer size) {
        return jobService.queryCompanyAlbum(jobId, page, size);
    }

    @ApiOperation("删除公司相册")
    @DeleteMapping("deleteAlbum")
    public JsonResult<Object> deleteAlbum(@RequestParam Long id) {
        jobService.deleteAlbum(id);
        return JsonResult.success();
    }

    @ApiOperation("查看招聘详情")
    @GetMapping("detail")
    public JsonResult<JobVo> detailJob(@RequestParam Long jobId, @RequestParam Long userId) {
        JobVo jobVo = jobService.detailJob(jobId, userId);
        return JsonResult.success(jobVo);
    }

    @ApiOperation("删除/隐藏招聘")
    @PostMapping("hide")
    public JsonResult<Object> hideJob(@RequestParam Long jobId) {
        jobService.hideJob(jobId);
        return JsonResult.success();
    }

    @ApiOperation("申请职位")
    @PostMapping("apply")
    public JsonResult<Object> applyJob(@RequestBody JobDeliveryRecordDTO deliveryRecordDTO) {
        jobDeliveryRecordService.applyJob(deliveryRecordDTO);
        return JsonResult.success();
    }

    @ApiOperation("招聘投递情况（分页）")
    @GetMapping("queryApplyJobPage")
    public PageJsonResult<List<JobDeliveryRecordVo>> queryApplyJobPage(@RequestParam Long jobId,
                                                                       @RequestParam(defaultValue = "1") Integer page,
                                                                       @RequestParam(defaultValue = "10") Integer size) {
        return jobDeliveryRecordService.queryApplyJobPage(jobId, page, size);
    }

    @ApiOperation("个人投递情况（分页）")
    @GetMapping("queryUserApplyJobPage")
    public PageJsonResult<List<JobVo>> queryUserApplyJobPage(@RequestParam Long userId,
                                                             @RequestParam(defaultValue = "1") Integer page,
                                                             @RequestParam(defaultValue = "10") Integer size) {
        return jobDeliveryRecordService.queryUserApplyJobPage(userId, page, size);
    }
}
