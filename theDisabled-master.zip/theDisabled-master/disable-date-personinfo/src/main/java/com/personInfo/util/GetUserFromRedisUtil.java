package com.personInfo.util;

import cn.hutool.json.JSONUtil;
import com.personInfo.advise.exception.TokenNotFoundException;
import com.personInfo.bean.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;

@Slf4j
@Configuration
public class GetUserFromRedisUtil {

    @Autowired
    private RedisTemplate redisTemplate;


    public User getUserFromRedis(String token) {
        if (token == null) {
            throw new TokenNotFoundException("No Authorization");
        }
        Object user_str = redisTemplate.opsForValue().get(token);
        if (user_str == null) {
            throw new TokenNotFoundException("No Authorization");
        }
        log.info("用户信息: #{}", user_str);
        return JSONUtil.toBean((String) user_str, User.class);
    }
}
