package com.personInfo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.personInfo.bean.ResumeEntity;
import com.personInfo.vo.ResumeVo;

import java.util.List;

/**
 * @author Chunming Liu In 2022/08/23
 */
public interface ResumeService extends IService<ResumeEntity> {
    List<ResumeVo> queryByUserId(Integer userId);
}
