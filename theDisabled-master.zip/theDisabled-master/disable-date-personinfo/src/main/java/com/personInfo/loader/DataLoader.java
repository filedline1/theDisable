package com.personInfo.loader;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.personInfo.bean.PersonBasicInfo;
import com.personInfo.bean.PersonDetailInfo;
import com.personInfo.common.PersonBasicInfoRestClient;
import com.personInfo.common.PersonDetailInfoRestClient;
import com.personInfo.constants.MqConstants;
import com.personInfo.mapper.PersonBasicInfoMapper;
import com.personInfo.mapper.PersonBasicInfoRepository;
import com.personInfo.mapper.PersonDetailInfoMapper;
import com.personInfo.mapper.RequirementsMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;

import java.io.IOException;
import java.util.List;

/**
 * @author Chunming Liu In 2022/08/19
 */
@Slf4j
@Configuration
public class DataLoader implements CommandLineRunner {

    @Autowired
    PersonBasicInfoMapper personBasicInfoMapper;
    @Autowired
    RequirementsMapper requirementsMapper;
    @Autowired
    PersonDetailInfoMapper personDetailInfoMapper;
    @Autowired
    PersonBasicInfoRestClient basicInfoRestClient;
    @Autowired
    PersonDetailInfoRestClient personDetailInfoRestClient;

    @Autowired
    private PersonBasicInfoRestClient personBasicInfoRestClient;
//    @Autowired
//    RabbitTemplate rabbitTemplate;

    @Override
    public void run(String... args){

        List<PersonBasicInfo> personBasicInfos = personBasicInfoMapper.selectList(new QueryWrapper<>());
        for (PersonBasicInfo personBasicInfo : personBasicInfos) {
            log.info("更新基本信息：{}", personBasicInfo.getPersonId());
            try {
//                rabbitTemplate.convertAndSend(MqConstants.PERSON_BASIC_INFO_EXCHANGE, MqConstants.PERSON_BASIC_INFO_INSERT_KEY, personBasicInfo.getPersonId());
                personBasicInfoRestClient.InsertPersonBasicInfoToIndexByPersonId(personBasicInfo.getPersonId());
            } catch (Exception e) {
                log.error("更新基本信息：{}，异常：{}", personBasicInfo.getPersonId(), ExceptionUtils.getStackTrace(e));
            }
        }
        List<PersonDetailInfo> personDetailInfos = personDetailInfoMapper.selectList(new QueryWrapper<>());
        for (PersonDetailInfo personDetailInfo : personDetailInfos) {
            log.info("更新详情信息：{}", personDetailInfo.getPersonId());
            try {
                personDetailInfoRestClient.InsertPersonDetailInfoToIndexByPersonId(personDetailInfo.getPersonId());
//                rabbitTemplate.convertAndSend(MqConstants.PERSON_DETAIL_INFO_EXCHANGE, MqConstants.PERSON_DETAIL_INFO_INSERT_KEY, personDetailInfo.getPersonId());
            } catch (Exception e) {
                log.error("更新详情信息：{}，异常：{}", personDetailInfo.getPersonId(), ExceptionUtils.getStackTrace(e));
            }
        }
    }
}
