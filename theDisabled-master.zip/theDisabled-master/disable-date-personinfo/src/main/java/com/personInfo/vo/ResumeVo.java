package com.personInfo.vo;

import com.personInfo.bean.ResumeEntity;

/**
 * @author Chunming Liu In 2022/08/23
 */
public class ResumeVo extends ResumeEntity {
}
