package com.personInfo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.personInfo.bean.JobDeliveryRecordEntity;
import com.personInfo.common.PageJsonResult;
import com.personInfo.dto.JobDeliveryRecordDTO;
import com.personInfo.mapper.JobDeliveryRecordMapper;
import com.personInfo.service.JobDeliveryRecordService;
import com.personInfo.vo.JobDeliveryRecordVo;
import com.personInfo.vo.JobVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Chunming Liu In 2022/08/23
 */
@Slf4j
@Service
public class JobDeliveryRecordServiceImpl extends ServiceImpl<JobDeliveryRecordMapper, JobDeliveryRecordEntity> implements JobDeliveryRecordService {
    final JobDeliveryRecordMapper deliveryRecordMapper;

    public JobDeliveryRecordServiceImpl(JobDeliveryRecordMapper deliveryRecordMapper) {
        this.deliveryRecordMapper = deliveryRecordMapper;
    }


    @Override
    public void applyJob(JobDeliveryRecordDTO deliveryRecordDTO) {
        deliveryRecordMapper.insert(deliveryRecordDTO);
    }

    @Override
    public PageJsonResult<List<JobDeliveryRecordVo>> queryApplyJobPage(Long jobId, Integer page, Integer size) {
        LambdaQueryWrapper<JobDeliveryRecordEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JobDeliveryRecordEntity::getJobId, jobId);

        Page<JobDeliveryRecordEntity> jobDeliveryRecordEntityPage = deliveryRecordMapper.selectPage(new Page<>(page, size), queryWrapper);
        List<JobDeliveryRecordVo> jobDeliveryRecordVos = BeanUtil.copyToList(jobDeliveryRecordEntityPage.getRecords(), JobDeliveryRecordVo.class);
        return PageJsonResult.success(page, size, jobDeliveryRecordEntityPage.getTotal(), jobDeliveryRecordVos);
    }

    @Override
    public PageJsonResult<List<JobVo>> queryUserApplyJobPage(Long userId, Integer page, Integer size) {
        Page<JobVo> jobVoPage = deliveryRecordMapper.selectUserApplyJobPage(userId, new Page<>(page, size));
        return PageJsonResult.success(page, size, jobVoPage.getTotal(), jobVoPage.getRecords());
    }
}
