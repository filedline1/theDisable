package com.personInfo.vo;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
@Data
public class PersonBaseDate {
    @JsonSerialize(using = ToStringSerializer.class)
    private Long personId;

    private String nickName;

    private String headPicPath;

    private Long attentionCount;

    private Long fanCount;

    private Integer like;

    private Integer love;

    private Integer sorts;

    private Boolean isSignIn;

    private Byte isModify;

    private Integer isVip;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date expirationTime;

    private String mv;

    private int isLike;
}
