package com.personInfo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.personInfo.bean.JobDeliveryRecordEntity;
import com.personInfo.vo.JobVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @author Chunming Liu In 2022/08/23
 */
@Mapper
public interface JobDeliveryRecordMapper extends BaseMapper<JobDeliveryRecordEntity> {
    @Select("SELECT tddj.* " +
            "FROM job_delivery_record jdr " +
            "JOIN tb_disable_data_job tddj ON jdr.job_id = tddj.id " +
            "WHERE jdr.user_id = #{userId} GROUP BY jdr.job_id")
    Page<JobVo> selectUserApplyJobPage(@Param("userId") Long userId, Page<Object> objectPage);

    @Select("SELECT COUNT(*) FROM job_delivery_record where job_id=#{jobId} and user_id=#{userId}")
    Long selectCountDelivery(@Param("jobId") Long jobId, @Param("userId") Long userId);
}
