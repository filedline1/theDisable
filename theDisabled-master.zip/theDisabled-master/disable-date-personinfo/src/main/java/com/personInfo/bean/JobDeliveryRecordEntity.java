package com.personInfo.bean;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author Chunming Liu In 2022/08/21
 */
@Data
@TableName("job_delivery_record")
public class JobDeliveryRecordEntity {
    @JsonSerialize(using = ToStringSerializer.class)
    @ApiModelProperty("ID")
    private Long id;
    @ApiModelProperty("招聘ID")
    private Long jobId;
    @ApiModelProperty("投递人")
    private Long userId;
    @ApiModelProperty("简历标题")
    private String resumeTitle;
    @ApiModelProperty("简历链接")
    private String resumeSite;
    @ApiModelProperty("备注")
    private String remark;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("创建时间")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
