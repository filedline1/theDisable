package com.personInfo.dto;

import com.personInfo.bean.ResumeEntity;

/**
 * @author Chunming Liu In 2022/08/23
 */
public class ResumeDTO extends ResumeEntity {
}
