package com.personInfo.bean;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author Chunming Liu In 2022/08/21
 */
@ApiModel("招聘")
@Data
@TableName("tb_disable_data_job")
public class JobEntity {
    @JsonSerialize(using = ToStringSerializer.class)
    @ApiModelProperty("ID")
    private Long id;
    @ApiModelProperty("发布人ID")
    private Long userId;
    @ApiModelProperty("招聘职位")
    private String title;
    @ApiModelProperty("公司LOGO")
    private String companyLogo;
    @ApiModelProperty("公司名称")
    private String companyName;
    @ApiModelProperty("公司规模：0-不限、1-0-20人、2-20-90人、3-100-499人、4500-999人、5-1000-9999人、6-10000人以上")
    private Integer companyWorkerNum;
    @ApiModelProperty("公司行业类型")
    private String companyType;
    @ApiModelProperty("经验要求：0-不限、1-在校生、2-应届生、3-1年以内、4-1-3年、5-3-5年、6-5-10年、7-10年以上")
    private Integer experience;
    @ApiModelProperty("学历：0-不限、1-初中及以下、2-中专/中技、3-高中、4-大专、5-本科、6-硕士、7-博士")
    private Integer education;
    @ApiModelProperty("薪资最低")
    private Integer salaryMin;
    @ApiModelProperty("薪资最高")
    private Integer salaryMax;
    @ApiModelProperty("年薪单位：如13薪")
    private Integer unit;
    @ApiModelProperty("薪水单位")
    private Integer salaryMonthNum;
    @ApiModelProperty("福利待遇：1-弹性工作制、2-底薪加提成、3-餐补、4-带薪年假、5-8小时工作制、6-保底工资、7-周末双休、8-五险、9-五险一金、10-房补、11-年终奖")
    private Integer welfare;
    @ApiModelProperty("公司位置：经度")
    private String longitude;
    @ApiModelProperty("公司位置：维度")
    private String latitude;
    @ApiModelProperty("公司位置")
    private String jobAddress;
    @ApiModelProperty("职位描述")
    private String jobDescribe;
    @ApiModelProperty("发布人")
    private String publisher;
    @ApiModelProperty("联系方式")
    private String contactDetails;
    @ApiModelProperty("创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @ApiModelProperty("更新时间")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    @ApiModelProperty("是否隐藏")
    private Integer hide;
    @ApiModelProperty(hidden = true)
    @TableLogic
    private Boolean isDeleted;
}
