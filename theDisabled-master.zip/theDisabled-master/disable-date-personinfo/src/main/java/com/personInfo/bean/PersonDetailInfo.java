package com.personInfo.bean;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
@Data
@Document(indexName = "disable-date-detail-info")
@TableName("tb_disable_date_person_detail_info")
public class PersonDetailInfo {
    @JsonSerialize(using = ToStringSerializer.class)
    @Id
    @Field(type = FieldType.Long)
    private Long personId;

    @Field(type = FieldType.Keyword)
    private String disableType;

    @Field(type = FieldType.Integer)
    private Integer disableLevel;

    @Field(type = FieldType.Integer)
    private Integer isProvide;

    @Field(type = FieldType.Keyword)
    private String auxiliaryTool;

    @Field(type = FieldType.Keyword)
    private String cause;

    @Field(type = FieldType.Integer)
    private Integer isGenetic;

    @Field(type = FieldType.Keyword)
    private String parentStatus;

    @Field(type = FieldType.Integer)
    private Integer brotherNumber;

    @Field(type = FieldType.Integer)
    private Integer livingWill;

    @Field(type = FieldType.Integer)
    private Integer isSmoking;

    @Field(type = FieldType.Integer)
    private Integer marryForm;

    @Field(type = FieldType.Integer)
    private Integer isDrinking;

    @Field(type = FieldType.Keyword)
    private String fertilityStatus;

    @Field(type = FieldType.Keyword)
    private String keepingStatus;

    @Field(type = FieldType.Keyword)
    private String hobby;

    @Field(type = FieldType.Integer)
    private Integer bloodType;

    @Field(type = FieldType.Keyword)
    private String habit;

    @Field(type = FieldType.Integer)
    private Integer companyType;

    @Field(type = FieldType.Keyword)
    private String companyName;

    @Field(type = FieldType.Keyword)
    private String workIndustry;

    @Field(type = FieldType.Keyword)
    private String housingLocation;

    @Field(type = FieldType.Keyword)
    private String personTag;

    @Field(type = FieldType.Boolean)
    @ApiModelProperty("是否系统创建")
    private Boolean isSystem;
}
