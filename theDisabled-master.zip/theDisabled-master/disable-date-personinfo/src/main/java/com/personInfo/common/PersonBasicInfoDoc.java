package com.personInfo.common;

import com.personInfo.bean.PersonBasicInfo;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@Data
@NoArgsConstructor
@Document(indexName = "disable-date-basic-info")
public class PersonBasicInfoDoc {

    @Id
    @Field(type = FieldType.Integer)
    private Long personId;

    @Field(type = FieldType.Keyword)
    private String personName;

    @Field(type = FieldType.Keyword)
    private String nickName;

    @Field(type = FieldType.Integer)
    private Integer sex;

    @Field(type = FieldType.Integer)
    private Integer age;

    @Field(type = FieldType.Keyword)
    private String phone;

    @Field(type = FieldType.Keyword)
    private String workAddr;

    @Field(type = FieldType.Keyword)
    private String householdAddr;

    @Field(type = FieldType.Keyword)
    private String maritalStatus;

    @Field(type = FieldType.Integer)
    private Integer height;

    @Field(type = FieldType.Integer)
    private Integer weight;

    @Field(type = FieldType.Keyword)
    private String degree;

    @Field(type = FieldType.Integer)
    private Integer income;

    @Field(type = FieldType.Keyword)
    private String occupation;

    @Field(type = FieldType.Keyword)
    private String housingStatus;

    @Field(type = FieldType.Keyword)
    private String carStatus;

    @Field(type = FieldType.Keyword)
    private String expectedMarryTime;

    @Field(type = FieldType.Keyword)
    private String personIntro;

    @Field(type = FieldType.Keyword)
    private String personSign;

    @Field(type = FieldType.Keyword)
    private String location;

    @Field(type = FieldType.Keyword)
    private String wechat;

    @Field(type = FieldType.Keyword)
    private String wechatCodeImagesPath;

    @Field(type = FieldType.Keyword)
    private String qq;

    @Field(type = FieldType.Keyword)
    private String email;

    @Field(type = FieldType.Keyword)
    private String mv;

    public PersonBasicInfoDoc(PersonBasicInfo personBasicInfo) {
        this.personId = personBasicInfo.getPersonId();
        this.personName = personBasicInfo.getPersonName();
        this.sex = personBasicInfo.getSex();
        this.age = personBasicInfo.getAge();
        this.phone = personBasicInfo.getPhone();
        this.workAddr = personBasicInfo.getWorkAddr();
        this.householdAddr = personBasicInfo.getHouseholdAddr();
        this.maritalStatus = personBasicInfo.getMaritalStatus();
        this.height = personBasicInfo.getHeight();
        this.weight = personBasicInfo.getWeight();
        this.degree = personBasicInfo.getDegree();
        this.income = personBasicInfo.getIncome();
        this.occupation = personBasicInfo.getOccupation();
        this.housingStatus = personBasicInfo.getHousingStatus();
        this.carStatus = personBasicInfo.getCarStatus();
        this.expectedMarryTime = personBasicInfo.getExpectedMarryTime();
        this.personIntro = personBasicInfo.getPersonIntro();
        this.personSign = personBasicInfo.getPersonSign();
        this.location = personBasicInfo.getLatitude() + ", " + personBasicInfo.getLongitude();
        this.wechat = personBasicInfo.getWechat();
        this.wechatCodeImagesPath = personBasicInfo.getWechatCodeImagesPath();
        this.qq = personBasicInfo.getQq();
        this.email = personBasicInfo.getEmail();
        this.mv = personBasicInfo.getMv();
    }
}
