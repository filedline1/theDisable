package com.personInfo.bean;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
@Data
@Document(indexName = "disable-date-requirements")
@TableName("tb_disable_date_requirements")
public class Requirement {
    @JsonSerialize(using = ToStringSerializer.class)
    @Id
    @Field(type = FieldType.Long)
    private Long personId;
    @Field(type = FieldType.Keyword)
    private String ageRange;
    @Field(type = FieldType.Keyword)
    private String heightRange;
    @Field(type = FieldType.Keyword)
    private String marryStatus;
    @Field(type = FieldType.Keyword)
    private String educationBackground;
    @Field(type = FieldType.Keyword)
    private String income;
    @Field(type = FieldType.Keyword)
    private String housingStatus;
    @Field(type = FieldType.Keyword)
    private String carStatus;
    @Field(type = FieldType.Keyword)
    private String otherRequirements;
}
