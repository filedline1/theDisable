package com.personInfo.dto;

import com.personInfo.bean.CompanyPhotoAlbumEntity;
import lombok.ToString;

/**
 * @author chunming
 * @date 2022-08-30 18:03:42
 */
@ToString
public class CompanyPhotoAlbumDTO extends CompanyPhotoAlbumEntity {
}
