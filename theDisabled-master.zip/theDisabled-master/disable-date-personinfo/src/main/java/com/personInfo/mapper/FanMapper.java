package com.personInfo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.personInfo.bean.Fan;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


@Mapper
public interface FanMapper extends BaseMapper<Fan> {


    public List<Fan> selectFollowerByUserId(@Param("follower") Integer follower, @Param("start") Integer start, @Param("limit") Integer limit);

    public long selectFollowerCountByUserId(Long userId);

    public List<Fan> selectStatusBetweenTwoUser(@Param("firstUserId") Integer firstUserId, @Param("secondUserId") Integer secondUserId);

    public long selectAttentionStatus(@Param("userId") Long userId, @Param("follower") Long follower);

    public int insertAttentionRecord(Fan fan);

    public int addAttention(Fan fan);

    public int cancelAttention(Fan fan);

    public int deleteRecord(Integer userId, Integer follower);

}
