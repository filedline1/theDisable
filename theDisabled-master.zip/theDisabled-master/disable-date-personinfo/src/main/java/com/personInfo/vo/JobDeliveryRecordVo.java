package com.personInfo.vo;

import com.personInfo.bean.JobDeliveryRecordEntity;

/**
 * @author Chunming Liu In 2022/08/23
 */
public class JobDeliveryRecordVo extends JobDeliveryRecordEntity {
}
