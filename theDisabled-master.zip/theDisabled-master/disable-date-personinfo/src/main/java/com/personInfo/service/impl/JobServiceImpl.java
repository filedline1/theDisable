package com.personInfo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.personInfo.bean.CompanyPhotoAlbumEntity;
import com.personInfo.bean.JobDeliveryRecordEntity;
import com.personInfo.bean.JobEntity;
import com.personInfo.common.PageJsonResult;
import com.personInfo.dto.CompanyPhotoAlbumDTO;
import com.personInfo.dto.JobDTO;
import com.personInfo.mapper.CompanyPhotoAlbumMapper;
import com.personInfo.mapper.JobDeliveryRecordMapper;
import com.personInfo.mapper.JobMapper;
import com.personInfo.service.JobService;
import com.personInfo.vo.CompanyPhotoAlbumVo;
import com.personInfo.vo.JobVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Chunming Liu In 2022/08/23
 */
@Slf4j
@Service
public class JobServiceImpl extends ServiceImpl<JobMapper, JobEntity> implements JobService {

    final JobMapper jobMapper;
    final JobDeliveryRecordMapper deliveryRecordMapper;
    final CompanyPhotoAlbumMapper companyPhotoAlbumMapper;

    public JobServiceImpl(JobMapper jobMapper, JobDeliveryRecordMapper deliveryRecordMapper, CompanyPhotoAlbumMapper companyPhotoAlbumMapper) {
        this.jobMapper = jobMapper;
        this.deliveryRecordMapper = deliveryRecordMapper;
        this.companyPhotoAlbumMapper = companyPhotoAlbumMapper;
    }

    @Override
    public void add(JobDTO jobDTO) {
        jobMapper.insert(jobDTO);
    }

    @Override
    public void update(JobDTO jobDTO) {
        jobMapper.updateById(jobDTO);
    }

    private Long countDelivery(Long jobId) {
        LambdaQueryWrapper<JobDeliveryRecordEntity> recordEntityLambdaQueryWrapper = new LambdaQueryWrapper<>();
        recordEntityLambdaQueryWrapper.eq(JobDeliveryRecordEntity::getJobId, jobId);
        return deliveryRecordMapper.selectCount(recordEntityLambdaQueryWrapper);
    }

    @Override
    public JobVo detailJob(Long jobId, Long userId) {
        JobVo jobVo = BeanUtil.copyProperties(jobMapper.selectById(jobId), JobVo.class);
        jobVo.setNumberOfDeliveries(countDelivery(jobVo.getId()));
        jobVo.setHasDelivery(deliveryRecordMapper.selectCountDelivery(jobId, userId) > 0);
        return jobVo;
    }

    @Override
    public void hideJob(Long jobId) {
        jobMapper.deleteById(jobId);
    }

    @Override
    public void updateLogo(Long jobId, String logo) {
        JobEntity jobEntity = jobMapper.selectById(jobId);
        if (jobEntity != null) {
            jobEntity.setCompanyLogo(logo);
            updateById(jobEntity);
        }
    }

    @Override
    public void uploadAlbum(CompanyPhotoAlbumDTO dto) {
        companyPhotoAlbumMapper.insert(dto);
    }

    @Override
    public void deleteAlbum(Long id) {
        companyPhotoAlbumMapper.deleteById(id);
    }

    @Override
    public PageJsonResult<List<CompanyPhotoAlbumVo>> queryCompanyAlbum(Long jobId, Integer page, Integer size) {
        LambdaQueryWrapper<CompanyPhotoAlbumEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CompanyPhotoAlbumEntity::getJobId, jobId);
        queryWrapper.orderByDesc(CompanyPhotoAlbumEntity::getId);

        Page<CompanyPhotoAlbumEntity> albumEntityPage = companyPhotoAlbumMapper.selectPage(new Page<>(page, size), queryWrapper);
        List<CompanyPhotoAlbumVo> companyPhotoAlbumVos = BeanUtil.copyToList(albumEntityPage.getRecords(), CompanyPhotoAlbumVo.class);
        return PageJsonResult.success(page, size, albumEntityPage.getTotal(), companyPhotoAlbumVos);
    }

    @Override
    public PageJsonResult<List<JobVo>> queryJobPage(Integer experience, Integer welfare, Integer education,
                                                    Integer salaryMin, Integer salaryMax, String companyName,
                                                    Integer companyWorkerNum, Integer page, Integer size) {
        LambdaQueryWrapper<JobEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(JobEntity::getHide, 0);
        queryWrapper.eq(experience != 0, JobEntity::getExperience, experience);
        queryWrapper.eq(welfare != 0, JobEntity::getWelfare, welfare);
        queryWrapper.eq(education != 0, JobEntity::getEducation, education);
        queryWrapper.eq(companyWorkerNum != 0, JobEntity::getCompanyWorkerNum, companyWorkerNum);

        queryWrapper.ge(salaryMin != 0, JobEntity::getSalaryMin, salaryMin);
        queryWrapper.le(salaryMax != 0 && salaryMin <= salaryMax, JobEntity::getSalaryMax, salaryMax);

        queryWrapper.like(StringUtils.isNotBlank(companyName), JobEntity::getCompanyName, companyName);


        Page<JobEntity> jobEntityPage = jobMapper.selectPage(new Page<>(page, size), queryWrapper);
        List<JobVo> jobVos = BeanUtil.copyToList(jobEntityPage.getRecords(), JobVo.class);

        // 统计投递数量
        for (JobVo jobVo : jobVos) {
            jobVo.setNumberOfDeliveries(countDelivery(jobVo.getId()));
        }
        return PageJsonResult.success(page, size, jobEntityPage.getTotal(), jobVos);
    }
}
