package com.personInfo.job;

import com.personInfo.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * @author Chunming Liu In 2022/09/13
 */
@Slf4j
@EnableScheduling
@Configuration
public class PersonJobs {

    @Autowired
    UserService userService;

    @Scheduled(cron = "0 0 0 ? * MON")
    public void resetSignCount() {
        log.info("执行“每周访问次数清零”任务");
        userService.signReset();
    }
}
