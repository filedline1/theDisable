package com.personInfo.vo;

import com.personInfo.bean.JobEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Chunming Liu In 2022/08/23
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class JobVo extends JobEntity {
    @ApiModelProperty("投递数量")
    private Long numberOfDeliveries;
    @ApiModelProperty("是否投递")
    private Boolean hasDelivery;
}
