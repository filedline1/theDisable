package com.personInfo.bean;

import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
@Data
@TableName("tb_disable_date_user")
public class User {

    Long userId;
    String nickName;
    String loginName;
    String passwordMd5;
    String idCode;
    Integer sex;
    Integer age;
    Integer isVip;
    Integer love;
    Integer likes;
    Integer sorts;
    String disableNumber;
    String headPicPath;
    String onlineTime;
    @TableLogic
    Integer isDeleted;
    Integer lockedFlag;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonIgnoreProperties(ignoreUnknown = true)
    Date createTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonIgnoreProperties(ignoreUnknown = true)
    Date updateTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonIgnoreProperties(ignoreUnknown = true)
    Date lastTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonIgnoreProperties(ignoreUnknown = true)
    Date expirationTime;

    public User(String nickName, String idCode, String tel){
        this.nickName = nickName;
        this.idCode = idCode;
        this.loginName = tel;
    }
}
