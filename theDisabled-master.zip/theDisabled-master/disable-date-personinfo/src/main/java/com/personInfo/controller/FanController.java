package com.personInfo.controller;

import com.personInfo.vo.FanVO;
import com.personInfo.vo.FollowVO;
import com.personInfo.bean.Fan;
import com.personInfo.bean.Follow;
import com.personInfo.bean.User;
import com.personInfo.common.PersonBasicInfoDoc;
import com.personInfo.common.PersonBasicInfoRestClient;
import com.personInfo.common.ServiceResultEnum;
import com.personInfo.service.FanService;
import com.personInfo.service.FollowService;
import com.personInfo.service.UserService;
import com.personInfo.util.Result;
import com.personInfo.util.ResultGenerator;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@RestController
@CrossOrigin
@RequestMapping("/fan")
public class FanController {

    @Autowired
    FanService fanService;

    @Autowired
    FollowService followService;

    @Autowired
    PersonBasicInfoRestClient basicInfoRestClient;

    @Autowired
    UserService userService;

    /**
     * 分页查询关注对象
     *
     * @param follower
     * @param start
     * @param limit
     * @return
     */
    @RequestMapping(value = "/searchFan", method = RequestMethod.POST)
    @ResponseBody
    public Result selectFollowerByUserId(@RequestParam("follower") Integer follower, @RequestParam(value = "start", defaultValue = "1") Integer start, @RequestParam(value = "limit", defaultValue = "10") Integer limit) throws Exception {
        if (limit == null || start == null) {
            return ResultGenerator.genErrorResult(400, "参数传递格式有误！");
        }
        System.out.println(follower);
        List<Fan> fans = fanService.selectFollowerByUserId(follower, start <= 0 ? 1 : start-1, limit);
        List<Long> usersId = new ArrayList<>();
        for (Fan fan : fans) {
            Long userId = fan.getUserId();
            usersId.add(userId);
        }
        System.out.println("关注的人有:  " + usersId);
        // 无粉丝直接返回
        if (usersId.isEmpty()) {
            return ResultGenerator.genSuccessResult("你可能没有关注的人呢,快去关注试试吧！");
        }

        final List<PersonBasicInfoDoc> personBasicInfoDocs;
        System.out.println(usersId);
        try {
            personBasicInfoDocs = basicInfoRestClient.selectByPersonIds(usersId);
        } catch (IOException e) {
            return ResultGenerator.genFailResult("数据缓存层出现异常！");
        }
        final List<User> users = userService.selectBatch(usersId);
        for (PersonBasicInfoDoc temp : personBasicInfoDocs) {
            System.out.println("personBasicDoc:" + temp);
        }
        List<FanVO> fanVOS;
        try {
            fanVOS = new ArrayList<>();
            for (int i = 0; i < fans.size(); i++) {
                FanVO fanVO = new FanVO();
                Fan fan = fans.get(i);
                fanVO.setUserId(fan.getUserId());
                fanVO.setStatus(fan.getStatus());
                if (i < personBasicInfoDocs.size()) {
                    PersonBasicInfoDoc personBasicInfoDoc = personBasicInfoDocs.get(i);
                    fanVO.setPersonSign(personBasicInfoDoc.getPersonSign());
                }
                if (i < users.size()) {
                    User user = users.get(i);
                    System.out.println(user);
                    fanVO.setNickName(user.getNickName());
                    fanVO.setHeadPicPath(user.getHeadPicPath());
                }
                fanVOS.add(fanVO);
            }
        } catch (Exception e) {
            return ResultGenerator.genSuccessResult("你可能没有关注的人呢,快去关注试试吧！");
        }
        return ResultGenerator.genSuccessResult(fanVOS);
    }

    /**
     * 分页查询关注对象
     *
     * @param follower
     * @param start
     * @param limit
     * @return
     */
    @RequestMapping(value = "/searchFanByNickname", method = RequestMethod.POST)
    @ResponseBody
    public Result selectFollowerByUserId(@RequestParam("follower") Integer follower, @RequestParam("nickname") String nickname, @RequestParam("start") Integer start, @RequestParam("limit") Integer limit) throws Exception {
        if (limit == null || start == null) {
            return ResultGenerator.genErrorResult(400, "参数传递格式有误！");
        }
        System.out.println(follower);
        List<Fan> fans = fanService.selectFollowerByUserId(follower, start <= 0 ? 1 : start-1, limit);
        List<Long> usersId = new ArrayList<>();
        for (Fan fan : fans) {
            Long userId = fan.getUserId();
            usersId.add(userId);
        }
        // 无粉丝直接返回
        if (usersId.isEmpty()) {
            return ResultGenerator.genSuccessResult("你可能没有关注的人呢,快去关注试试吧！");
        }

        final List<PersonBasicInfoDoc> personBasicInfoDocsWithoutFilter;
        System.out.println(usersId);
        try {
            personBasicInfoDocsWithoutFilter = basicInfoRestClient.selectByPersonIds(usersId);
        } catch (IOException e) {
            return ResultGenerator.genFailResult("数据缓存层出现异常！");
        }
        final List<User> usersWaitFilter = userService.selectBatch(usersId);
        List<User> users = new ArrayList<>();
        for (User user : usersWaitFilter) {
            String nicknameTemp = user.getNickName();
            if (nicknameTemp.contains(nickname)) {
                System.out.println("nicknameTemp:" + nicknameTemp);
                System.out.println("nickname:" + nickname);
                users.add(user);
            }
        }
        if (users.size() == 0) {
            return ResultGenerator.genSuccessResult("未找到匹配的关注对象!");
        }
        //数据对齐
        List<PersonBasicInfoDoc> personBasicInfoDocs = new ArrayList<>();
        for (int i = 0; i < personBasicInfoDocsWithoutFilter.size(); i++) {
            PersonBasicInfoDoc temp = personBasicInfoDocsWithoutFilter.get(i);
            System.out.println(temp);
            for (int j = 0; j < users.size(); j++) {
                User user = users.get(j);
                if (temp.getPersonId().equals(user.getUserId())) {
                    personBasicInfoDocs.add(temp);
                }
            }
        }
        List<FanVO> fanVOS;
        try {
            fanVOS = new ArrayList<>();
            for (int i = 0; i < users.size(); i++) {
                FanVO fanVO = new FanVO();
                if (i < personBasicInfoDocs.size()) {
                    PersonBasicInfoDoc personBasicInfoDoc = personBasicInfoDocs.get(i);
                    fanVO.setPersonSign(personBasicInfoDoc.getPersonSign());
                }
                if (i < users.size()) {
                    User user = users.get(i);
                    fanVO.setUserId(user.getUserId());
                    fanVO.setStatus(2);
                    System.out.println(user);
                    fanVO.setNickName(user.getNickName());
                    fanVO.setHeadPicPath(user.getHeadPicPath());
                }
                fanVOS.add(fanVO);
            }
        } catch (Exception e) {
            return ResultGenerator.genSuccessResult("你可能没有关注的人呢,快去关注试试吧！");
        }
        return ResultGenerator.genSuccessResult(fanVOS);
    }


    /**
     * 查询该用户关注列表
     *
     * @param userId
     * @param start
     * @param limit
     * @return
     **/
    @RequestMapping(value = "/searchAttention", method = RequestMethod.POST)
    @ResponseBody
    public Result selectAttentionByUserId(@RequestParam("userId") Integer userId, @RequestParam(value = "start", defaultValue = "1") Integer start, @RequestParam(value = "limit", defaultValue = "10") Integer limit) throws Exception {
        if (limit == null || start == null) {
            return ResultGenerator.genErrorResult(400, "参数传递格式有误！");
        }
        System.out.println(userId);
        List<Follow> follows = followService.selectAttentionByUserId(userId, start <= 0 ? 1 : start-1, limit);
        List<Long> usersId = new ArrayList<>();
        for (Follow follow : follows) {
            Long id = follow.getUserId();
            usersId.add(id);
        }
        System.out.println(usersId);
        final List<User> users;
        final List<PersonBasicInfoDoc> personBasicInfoDocs = basicInfoRestClient.selectByPersonIds(usersId);
        try {
            users = userService.selectBatch(usersId);
        } catch (Exception e) {
            return ResultGenerator.genFailResult("好难过！，你没有粉丝！");
        }
        System.out.println(personBasicInfoDocs);
        List<FollowVO> followVOS = new ArrayList<>();
        for (int i = 0; i < follows.size(); i++) {
            FollowVO followVO = new FollowVO();
            Follow follow = follows.get(i);
            PersonBasicInfoDoc personBasicInfoDoc = personBasicInfoDocs.get(i);
            User user = users.get(i);
            followVO.setUserId(follow.getUserId());
            followVO.setStatus(follow.getStatus());
            followVO.setPersonSign(personBasicInfoDoc.getPersonSign());
            followVO.setNickName(user.getNickName());
            followVO.setHeadPicPath(user.getHeadPicPath());
            followVOS.add(followVO);
        }
        return ResultGenerator.genSuccessResult(followVOS);
    }

    /**
     * 查询该用户关注列表
     *
     * @param userId
     * @param start
     * @param limit
     * @return
     **/
    @RequestMapping(value = "/searchAttentionByNickname", method = RequestMethod.POST)
    @ResponseBody
    public Result selectAttentionByUserId(@Param("userId") Integer userId, @Param("nickname") String nickname, @Param("start") Integer start, @Param("limit") Integer limit) throws Exception {
        if (limit == null || start == null) {
            return ResultGenerator.genErrorResult(400, "参数传递格式有误！");
        }
        System.out.println(userId);
        List<Follow> follows = followService.selectAttentionByUserId(userId, start, limit);
        List<Long> usersId = new ArrayList<>();
        for (Follow follow : follows) {
            Long id = follow.getUserId();
            usersId.add(id);
        }
        System.out.println(usersId);
        final List<User> usersWaitFilter;
        List<User> users = new ArrayList<>();
        final List<PersonBasicInfoDoc> personBasicInfoDocsWithoutFilter = basicInfoRestClient.selectByPersonIds(usersId);
        try {
            usersWaitFilter = userService.selectBatch(usersId);
        } catch (Exception e) {
            return ResultGenerator.genSuccessResult("好难过！，你没有粉丝！");
        }
        for (User user : usersWaitFilter) {
            String nicknameTemp = user.getNickName();
            if (nicknameTemp.contains(nickname)) {
                System.out.println("nicknameTemp:" + nicknameTemp);
                System.out.println("nickname:" + nickname);
                users.add(user);
            }
        }
        if (users.size() == 0) {
            return ResultGenerator.genSuccessResult("未找到匹配的粉丝!");
        }
        List<PersonBasicInfoDoc> personBasicInfoDocs = new ArrayList<>();
        for (int i = 0; i < personBasicInfoDocsWithoutFilter.size(); i++) {
            PersonBasicInfoDoc temp = personBasicInfoDocsWithoutFilter.get(i);
//            System.out.println(temp);
            for (int j = 0; j < users.size(); j++) {
                User user = users.get(j);
                if (temp.getPersonId().equals(user.getUserId())) {
                    personBasicInfoDocs.add(temp);
                    System.out.println(temp);
                }
            }
        }
        List<FollowVO> followVOS = new ArrayList<>();
        for (int i = 0; i < users.size(); i++) {
            FollowVO followVO = new FollowVO();
            PersonBasicInfoDoc personBasicInfoDoc = personBasicInfoDocs.get(i);
            User user = users.get(i);
            followVO.setUserId(user.getUserId());
            followVO.setStatus(2);
            followVO.setPersonSign(personBasicInfoDoc.getPersonSign());
            followVO.setNickName(user.getNickName());
            followVO.setHeadPicPath(user.getHeadPicPath());
            followVOS.add(followVO);
        }
        return ResultGenerator.genSuccessResult(followVOS);
    }

    /**
     * 查找该用户的粉丝数
     *
     * @param userId
     * @return
     */
    @RequestMapping(value = "/searchFanCount", method = RequestMethod.POST)
    @ResponseBody
    public Result selectFollowerCountByUserId(Long userId) {
        long count;
        try {
            count = fanService.selectFollowerCountByUserId(userId);
        } catch (Exception e) {
            return ResultGenerator.genErrorResult(500, "服务器错误请及时联系管理员");
        }
        return ResultGenerator.genSuccessResult(count);
    }

    /**
     * 查询该用户关注数量
     *
     * @param userId
     * @return
     */
    @RequestMapping(value = "/searchAttentionCount", method = RequestMethod.POST)
    @ResponseBody
    public Result selectAttentionCountByUserId(Long userId) {
        long count;
        try {
            count = followService.selectAttentionCountByUserId(userId);
        } catch (Exception e) {
            return ResultGenerator.genErrorResult(500, "服务器错误请及时联系管理员");
        }
        return ResultGenerator.genSuccessResult(count);
    }

    /**
     * 查询两个人之间的关注情况
     *
     * @param firstUserId
     * @param secondUserId
     * @return
     */
    @RequestMapping(value = "/searchStatus", method = RequestMethod.POST)
    @ResponseBody
    public List<Fan> selectStatusBetweenTwoUser(Integer firstUserId, Integer secondUserId) {
        List<Fan> fans = fanService.selectStatusBetweenTwoUser(firstUserId, secondUserId);
        return fans;
    }

    /**
     * 增加关注记录
     *
     * @param fan
     * @return
     */
    @RequestMapping(value = "/addAttention", method = RequestMethod.POST)
    @ResponseBody
    public Result addAttention(Fan fan) {
        if (fan.getUserId() == null || fan.getFollower() == null) {
            return ResultGenerator.genFailResult("参数异常！");
        }
        System.out.println(fan);
        String message = fanService.addAttention(fan);
        if (!message.equals(ServiceResultEnum.SUCCESS.getResult())) {
            return ResultGenerator.genErrorResult(500, "服务器错误，请及时联系管理员！");
        }
        return ResultGenerator.genSuccessResult();
    }

    /**
     * 取消关注记录
     *
     * @param fan
     * @return
     */
    @RequestMapping(value = "/cancelAttention", method = RequestMethod.POST)
    @ResponseBody
    public Result cancelAttention(Fan fan) {
        if (fan.getUserId() == null || fan.getFollower() == null) {
            return ResultGenerator.genFailResult("参数异常！");
        }
        System.out.println(fan);
        String message = fanService.cancelAttention(fan);
        if (!message.equals(ServiceResultEnum.SUCCESS.getResult())) {
            return ResultGenerator.genErrorResult(500, "服务器错误，请及时联系管理员！");
        }
        return ResultGenerator.genSuccessResult();
    }


    /**
     * 删除改用户的所有关注信息（注销账号时使用）
     *
     * @param userId
     * @return
     */
    @RequestMapping(value = "/deleteRecord", method = RequestMethod.DELETE)
    @ResponseBody
    public Result deleteRecord(Integer userId) {
        String message = fanService.deleteRecord(userId);
        System.out.println(message);
        if (message.equals(ServiceResultEnum.SUCCESS.getResult())) {
            return ResultGenerator.genSuccessResult();
        }
        return ResultGenerator.genFailResult("删除失败！");
    }

}
