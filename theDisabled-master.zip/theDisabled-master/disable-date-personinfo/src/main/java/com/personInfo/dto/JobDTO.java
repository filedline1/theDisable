package com.personInfo.dto;

import com.personInfo.bean.JobEntity;

/**
 * @author Chunming Liu In 2022/08/23
 */
public class JobDTO extends JobEntity {
}
