package com.personInfo.bean;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author chunming
 * @date 2022-08-30 17:39:28
 */
@TableName("tb_disable_data_company_photo_album")
@Data
public class CompanyPhotoAlbumEntity {
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
    @ApiModelProperty("职位Id")
    private Long jobId;
    @ApiModelProperty("照片描述")
    private String des;
    @ApiModelProperty("图片地址")
    private String photo;
}
