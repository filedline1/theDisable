package com.personInfo.service;

import com.personInfo.common.PageJsonResult;
import com.personInfo.dto.JobDeliveryRecordDTO;
import com.personInfo.vo.JobDeliveryRecordVo;
import com.personInfo.vo.JobVo;

import java.util.List;

/**
 * @author Chunming Liu In 2022/08/23
 */
public interface JobDeliveryRecordService {
    void applyJob(JobDeliveryRecordDTO deliveryRecordDTO);

    PageJsonResult<List<JobDeliveryRecordVo>> queryApplyJobPage(Long jobId, Integer page, Integer size);

    PageJsonResult<List<JobVo>> queryUserApplyJobPage(Long userId, Integer page, Integer size);
}
