package com.personInfo.mapper;

import com.personInfo.common.PersonBasicInfoDoc;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chunming Liu In 2022/08/27
 */
@Repository
public interface PersonBasicInfoRepository extends ElasticsearchRepository<PersonBasicInfoDoc, Integer> {
}
