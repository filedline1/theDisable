package com.personInfo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.personInfo.bean.ResumeEntity;
import com.personInfo.mapper.ResumeMapper;
import com.personInfo.service.ResumeService;
import com.personInfo.vo.ResumeVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Chunming Liu In 2022/08/23
 */
@Slf4j
@Service
public class ResumeServiceImpl extends ServiceImpl<ResumeMapper, ResumeEntity> implements ResumeService {
    final ResumeMapper resumeMapper;

    public ResumeServiceImpl(ResumeMapper resumeMapper) {
        this.resumeMapper = resumeMapper;
    }

    @Override
    public List<ResumeVo> queryByUserId(Integer userId) {
        LambdaQueryWrapper<ResumeEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ResumeEntity::getUserId, userId);

        List<ResumeEntity> resumeEntities = resumeMapper.selectList(queryWrapper);
        return BeanUtil.copyToList(resumeEntities, ResumeVo.class);
    }
}
