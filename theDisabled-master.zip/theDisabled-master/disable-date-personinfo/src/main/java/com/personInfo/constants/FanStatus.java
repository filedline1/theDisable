package com.personInfo.constants;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
public class FanStatus {

    public static final int UNFOLLOW = 1;

    public static final int ATTENTION = 2;

}
