package com.personInfo.controller;

import com.personInfo.common.JsonResult;
import com.personInfo.dto.ResumeDTO;
import com.personInfo.service.ResumeService;
import com.personInfo.vo.ResumeVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

/**
 * @author Chunming Liu In 2022/08/23
 */
@Api(tags = "简历")
@RestController
@RequestMapping("resume")
public class ResumeController {
    final ResumeService resumeService;
    @Autowired
    HttpServletRequest request;

    public ResumeController(ResumeService resumeService) {
        this.resumeService = resumeService;
    }

    @ApiOperation("上传简历")
    @PostMapping("upload")
    public JsonResult<Object> upload(@RequestBody ResumeDTO resumeDTO) {
        resumeService.save(resumeDTO);
        return JsonResult.success();
    }

    @ApiOperation("获取简历")
    @GetMapping("query")
    public JsonResult<List<ResumeVo>> query(@RequestParam Integer userId) throws IOException {
        return JsonResult.success(resumeService.queryByUserId(userId));
    }

    @ApiOperation("删除简历")
    @DeleteMapping("delete")
    public JsonResult<Object> delete(@RequestParam Long id) throws IOException {
        resumeService.removeById(id);
        return JsonResult.success();
    }
}
