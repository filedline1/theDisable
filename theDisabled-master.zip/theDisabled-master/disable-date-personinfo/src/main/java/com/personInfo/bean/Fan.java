package com.personInfo.bean;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
@Data
@TableName("tb_disable_date_fans")
public class Fan {

    private Integer id;

    private Long userId;

    private Long follower;

    private Integer status;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;


    public Fan() {
    }

    public Fan(Long userId, Long follower, Integer status, LocalDateTime createTime, LocalDateTime updateTime) {
        this.userId = userId;
        this.follower = follower;
        this.status = status;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }
}
