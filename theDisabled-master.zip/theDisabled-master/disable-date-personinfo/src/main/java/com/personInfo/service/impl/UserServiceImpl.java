package com.personInfo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.personInfo.bean.*;
import com.personInfo.common.JsonResult;
import com.personInfo.common.PersonBasicInfoRestClient;
import com.personInfo.common.ServiceResultEnum;
import com.personInfo.constants.MqConstants;
import com.personInfo.mapper.*;
import com.personInfo.service.UserService;
import com.personInfo.util.AgeUtil;
import com.personInfo.util.MD5Util;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/

@Slf4j
@Service
public class UserServiceImpl implements UserService {


    @Autowired
    RestTemplate restTemplate;
    //    @Value("${userinfo.manage-server}")
//    @Autowired
//    String getUserinfoManageServer;
    @Autowired
    UserinfoMetadataMapper userinfoMetadataMapper;
    @Autowired
    PersonBasicInfoMapper personBasicInfoMapper;
    @Autowired
    RequirementsMapper requirementsMapper;
    @Autowired
    PersonDetailInfoMapper personDetailInfoMapper;
    @Value("${userinfo.manage-server}")
    String getUserinfoManageServer;
    @Autowired
    RabbitTemplate rabbitTemplate;
    @Autowired
    private UserMapper userMapper;

    public List<User> selectBatch(List<Long> recordItems){
        return userMapper.selectBatch(recordItems);
    }

    @Override
    public User login(String loginName, String password) throws ParseException{
        User user = userMapper.selectUserByLoginName(loginName);
        System.out.println(user);
        String passwordMD5 = MD5Util.MD5Encode(password, "UTF-8");
        if (user == null) {
            return null;
        } else if (passwordMD5.equals(user.getPasswordMd5())) {
            // 登录后执行业务层操作...
            return user;
        }
        return null;
    }

    @Override
    public String register(User user) throws ParseException{
        /**
         * 判断账号是否重复
         */
        if (userMapper.selectUserByLoginName(user.getLoginName()) != null) {
            return ServiceResultEnum.USER_IS_EXIST.getResult();
        }
        String passwordMD5 = MD5Util.MD5Encode(user.getPasswordMd5(), "UTF-8");
        user.setPasswordMd5(passwordMD5);
        user.setCreateTime(new Date());
        /**
         * ********
         * 残疾人注册认证业务
         * *******
         */
        // 账号初始状态设置为正常和已认证
        user.setLockedFlag(1);
        user.setIsDeleted(1);
        // 校验第三库区域
        if (userMapper.insertUser(user) > 0) {
            return ServiceResultEnum.SUCCESS.getResult();
        }
        return ServiceResultEnum.DB_ERROR.getResult();
    }

    /**
     * 修改密码 判断账号是否存在-》核对旧密码-》修改新密码
     *
     * @param loginName
     * @param oldPassword
     * @param newPassword
     * @return
     */
    @Override
    public int updatePassword(String loginName, String oldPassword, String newPassword){
        User user = userMapper.selectUserByLoginName(loginName);
        if (user == null) {
            return 0;
        }
        // 核对旧密码
        String oldPasswordMD5 = MD5Util.MD5Encode(oldPassword, "UTF-8");
        if (oldPasswordMD5.equals(user.getPasswordMd5())) {
            String newPasswordMD5 = MD5Util.MD5Encode(newPassword, "UTF-8");
            user.setPasswordMd5(newPasswordMD5);
            if (userMapper.updatePassword(loginName, newPasswordMD5) > 0) {
                return 1;
            }
        } else {
            return 0;
        }
        return 0;
    }

    @Autowired
    private PersonBasicInfoRestClient personBasicInfoRestClient;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public String updateNickName(String loginName, String nickName){
        User user = userMapper.selectUserByLoginName(loginName);
        if (user == null) {
            return ServiceResultEnum.USER_NOT_EXIST.getResult();
        }
        if (userMapper.updateNickName(loginName, nickName) > 0) {
            try {
                // 更新es
                personBasicInfoRestClient.InsertPersonBasicInfoToIndexByPersonId(user.getUserId());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return ServiceResultEnum.SUCCESS.getResult();
        }
        return ServiceResultEnum.ERROR.getResult();
    }

    @Override
    public String delete(Integer userId){
        int delete = userMapper.delete(userId);
        if (delete > 0) {
            return ServiceResultEnum.SUCCESS.getResult();
        }
        return ServiceResultEnum.DB_ERROR.getResult();
    }

    @Override
    public String signIn(Integer reward, String loginName){
        User userTemp = userMapper.selectUserByLoginName(loginName);
        if (userTemp == null) {
            return ServiceResultEnum.DB_ERROR.getResult();
        }
        Date lastTime = userTemp.getLastTime();
        if (lastTime == null) {
            if (userMapper.signIn(reward, loginName) > 0) {
                return ServiceResultEnum.SUCCESS_SIGN_IN.getResult();
            } else {
                return ServiceResultEnum.DB_ERROR.getResult();
            }
        }
        System.out.println(userTemp);
        Date date = new Date();
        int insert;
        int currentTimeYear = lastTime.getYear();
        int currentTimeMonth = lastTime.getMonth();
        int currentTimeDay = lastTime.getDate();
        if (currentTimeYear < date.getYear()) {
            insert = userMapper.signIn(reward, loginName);
            System.out.println("lastTimeYear " + currentTimeYear);
            System.out.println("date.getYear() " + date.getYear());
            if (insert > 0) {
                return ServiceResultEnum.SUCCESS_SIGN_IN.getResult();
            } else {
                return ServiceResultEnum.DB_ERROR.getResult();
            }
        } else if (currentTimeMonth < date.getMonth()) {
            insert = userMapper.signIn(reward, loginName);
            System.out.println("lastTimeMonth " + currentTimeMonth);
            System.out.println("date.getMonth() " + date.getMonth());
            if (insert > 0) {
                return ServiceResultEnum.SUCCESS_SIGN_IN.getResult();
            } else {
                return ServiceResultEnum.DB_ERROR.getResult();
            }
        } else if (currentTimeDay < date.getDate()) {
            insert = userMapper.signIn(reward, loginName);
            System.out.println("lastTimeDay " + currentTimeDay);
            System.out.println("date.getDate() " + date.getDate());
            if (insert > 0) {
                return ServiceResultEnum.SUCCESS_SIGN_IN.getResult();
            } else {
                return ServiceResultEnum.DB_ERROR.getResult();
            }
        } else if (currentTimeDay == date.getDate()) {
            return ServiceResultEnum.ALREADY_SIGN_IN.getResult();
        }
        return ServiceResultEnum.ERROR.getResult();
    }

    public int updateHeadPicPath(@Param("loginName") String loginName, @Param("headPicPath") String headPicPath){
        final int i = userMapper.updateHeadPicPath(loginName, headPicPath);
        return i;
    }

    @Override
    public Date openVip(String loginName, Integer month){
        if (userMapper.openVip(loginName, month) > 0) {
            final User user = userMapper.selectUserByLoginName(loginName);
            return user.getExpirationTime();
        }
        return null;
    }

    @Override
    public Date renewalVip(@Param("loginName") String loginName, @Param("month") Integer month){
        if (userMapper.renewalVip(loginName, month) > 0) {
            final User user = userMapper.selectUserByLoginName(loginName);
            return user.getExpirationTime();
        }
        return null;
    }

    public User selectUserByLoginName(String loginName){
        return userMapper.selectUserByLoginName(loginName);
    }

    /**
     * @param userId
     * @return
     */
    public User selectByPrimaryKey(Long userId){
        final User user = userMapper.selectByPrimaryKey(userId);
        return user;
    }

    /**
     * 点赞
     *
     * @param userId
     * @return
     */
    public int addLikesCount(@Param("userId") Integer userId){
        final int i = userMapper.addLoveCount(userId);
        return i;
    }

    /**
     * 喜欢
     *
     * @param userId
     * @return
     */
    public int addLoveCount(@Param("userId") Integer userId){
        final int i = userMapper.addLoveCount(userId);
        return i;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public String register(String nickName, String tel, String idCode, String longitude, String latitude){

        User user = userMapper.selectByIdCode(idCode);

        Assert.state(user == null, "已注册，请登录");

        // 创建新用户
        user = new User(nickName, idCode, tel);

        // 请求第三方用户中间件系统
        ResponseEntity<JsonResult> forUserinfoEntity;
        try {
            forUserinfoEntity = restTemplate.exchange(String.format(getUserinfoManageServer, idCode), HttpMethod.GET, null, JsonResult.class);
        } catch (RestClientException e) {
            e.printStackTrace();
            throw new RestClientException("系统出错，稍后重试");
        }
        Assert.state(HttpStatus.OK.equals(forUserinfoEntity.getStatusCode()), "系统出错，稍后重试");
        JsonResult body = forUserinfoEntity.getBody();
        Assert.state(body != null, "系统出错，稍后重试");

        Object userInfo = body.getData();
        if (userInfo == null) {
            // 保存用户元数据
            UserinfoMetadata userinfoMetadata = BeanUtil.copyProperties(userInfo, UserinfoMetadata.class);
            userinfoMetadataMapper.insert(userinfoMetadata);
            // 创建用户信息
            user = initUserinfo(userinfoMetadata, user, longitude, latitude);
        } else {
            // 创建用户信息
            user = initUserinfo(null, user, longitude, latitude);
        }
        if (user != null) {
            return ServiceResultEnum.SUCCESS.getResult();
        }
        return ServiceResultEnum.DB_ERROR.getResult();
    }

    @Override
    public int isLike(Long userId, Long likePersonId){
        long hadLike = userMapper.hasLikeTheUser(userId, likePersonId);
        return hadLike > 0 ? 1 : 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public User tryJoinByTel(String tel, String longitude, String latitude){
        log.warn("获取手机号信息：{}, 经纬度：#{},#{}", tel, longitude, latitude);
        // 查询本地是否存在
        User user = userMapper.selectUserByPhone(tel);

        Assert.state(user != null, "请注册");

        if (user != null && StringUtils.isNotBlank(latitude) && StringUtils.isNotBlank(longitude)) {
            PersonBasicInfo personBasicInfo = personBasicInfoMapper.findByPersonId(user.getUserId());
            personBasicInfo.setLatitude(latitude);
            personBasicInfo.setLongitude(longitude);
            if (personBasicInfoMapper.update(personBasicInfo) > 0) {
                rabbitTemplate.convertAndSend(MqConstants.PERSON_BASIC_INFO_EXCHANGE, MqConstants.PERSON_BASIC_INFO_INSERT_KEY, personBasicInfo.getPersonId());
            }
        }
        return user;
    }

    @Override
    public void sign(Long userId){
        userMapper.sign(userId);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void signReset(){
        userMapper.signReset();
    }

    private User initUserinfo(UserinfoMetadata userinfoMetadata, User user, String longitude, String latitude){
        user.setAge(AgeUtil.getAgeByIDNumber(user.getIdCode()));
        user.setSex(userinfoMetadata == null || StringUtils.isBlank(userinfoMetadata.getSex()) ?
                null : "男".equals(userinfoMetadata.getSex()) ?
                Integer.valueOf(1) : "女".equals(userinfoMetadata.getSex()) ? 2 : null);
        user.setHeadPicPath(
                user.getSex() == null ?
                        "https://p3-search.byteimg.com/img/labis/526a75069b69013c625517b4b8559fca~tplv-tt-cs0:360:360.webp" :
                        user.getSex() == 1 ? "https://img2.baidu.com/it/u=180286244,263138673&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500"
                                : user.getSex() == 2 ? "https://i02piccdn.sogoucdn.com/534307f700d7ba19"
                                : "https://p3-search.byteimg.com/img/labis/526a75069b69013c625517b4b8559fca~tplv-tt-cs0:360:360.webp"
        );
        String passwordMD5 = MD5Util.MD5Encode(user.getLoginName().substring(5), "UTF-8");
        user.setPasswordMd5(passwordMD5);
        user.setCreateTime(new Date());
        // 账号初始状态设置为正常和已认证
        user.setLockedFlag(1);
        user.setIsDeleted(1);
        // 创建用户数据
        if (userMapper.insertUser(user) > 0) {
            // 创建基础用户信息
            PersonBasicInfo personBasicInfo = new PersonBasicInfo();
            personBasicInfo.setAge(user.getAge());
            personBasicInfo.setPersonId(user.getUserId());
            personBasicInfo.setLongitude(longitude);
            personBasicInfo.setLatitude(latitude);
            personBasicInfo.setPhone(user.getLoginName());
            personBasicInfo.setPersonName(user.getNickName());
            if (personBasicInfoMapper.insert(personBasicInfo) > 0) {
                rabbitTemplate.convertAndSend(MqConstants.PERSON_BASIC_INFO_EXCHANGE, MqConstants.PERSON_BASIC_INFO_INSERT_KEY, personBasicInfo.getPersonId());
            }

            Requirement requirement = new Requirement();
            requirement.setPersonId(user.getUserId());
            requirementsMapper.insert(requirement);

            PersonDetailInfo personDetailInfo = new PersonDetailInfo();
            personDetailInfo.setPersonId(user.getUserId());
            if (personDetailInfoMapper.insert(personDetailInfo) > 0) {
                rabbitTemplate.convertAndSend(MqConstants.PERSON_DETAIL_INFO_EXCHANGE, MqConstants.PERSON_DETAIL_INFO_INSERT_KEY, personDetailInfo.getPersonId());
            }
            return user;
        }
        return null;
    }

}
