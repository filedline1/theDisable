package com.personInfo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.personInfo.bean.JobEntity;
import com.personInfo.bean.ResumeEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Chunming Liu In 2022/08/23
 */
@Mapper
public interface ResumeMapper extends BaseMapper<ResumeEntity> {
}
