package com.personInfo.vo;

import com.personInfo.bean.CompanyPhotoAlbumEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author chunming
 * @date 2022-08-30 18:43:06
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CompanyPhotoAlbumVo extends CompanyPhotoAlbumEntity {
}
