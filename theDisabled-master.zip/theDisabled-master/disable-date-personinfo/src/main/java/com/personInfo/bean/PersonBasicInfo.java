package com.personInfo.bean;


import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.Data;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
@Data
@TableName("tb_disable_date_person_basic_info")
public class PersonBasicInfo {
    @JsonSerialize(using = ToStringSerializer.class)
    private Long personId;

    private String personName;

    private Integer sex;

    private Integer age;

    private String phone;

    private String workAddr;

    private String householdAddr;

    private String maritalStatus;

    private Integer height;

    private Integer weight;

    private String degree;

    private Integer income;

    private String occupation;

    private String housingStatus;

    private String carStatus;

    private String expectedMarryTime;

    private String personIntro;

    private String personSign;

    private String longitude;

    private String latitude;

    private String wechat;

    private String wechatCodeImagesPath;

    private String qq;

    private String email;

    private String mv;
}

