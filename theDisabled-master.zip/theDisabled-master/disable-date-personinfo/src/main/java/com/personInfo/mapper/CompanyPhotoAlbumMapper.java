package com.personInfo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.personInfo.bean.CompanyPhotoAlbumEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author chunming
 * @date 2022-08-30 17:41:56
 */
@Mapper
public interface CompanyPhotoAlbumMapper extends BaseMapper<CompanyPhotoAlbumEntity> {
}
