package com.personInfo.bean;


import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Data
@TableName("tb_disable_date_vip_permissions")
public class VipPermission {

    private Long configId;

    private Long userId;

    private Byte isView;

    private Byte isModify;

    private Integer likes;

    private Integer albumCount;

    private Integer diaryPicCount;

    private Byte isBack;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    private Integer updateAdmin;
}