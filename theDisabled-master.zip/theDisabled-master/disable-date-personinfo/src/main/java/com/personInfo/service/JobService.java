package com.personInfo.service;

import com.personInfo.common.PageJsonResult;
import com.personInfo.dto.CompanyPhotoAlbumDTO;
import com.personInfo.dto.JobDTO;
import com.personInfo.vo.CompanyPhotoAlbumVo;
import com.personInfo.vo.JobVo;

import java.util.List;

/**
 * @author Chunming Liu In 2022/08/23
 */
public interface JobService {
    void add(JobDTO jobDTO);

    void update(JobDTO jobDTO);



    JobVo detailJob(Long jobId, Long userId);

    void hideJob(Long jobId);

    void updateLogo(Long jobId, String logo);

    void uploadAlbum(CompanyPhotoAlbumDTO dto);

    void deleteAlbum(Long id);

    PageJsonResult<List<CompanyPhotoAlbumVo>> queryCompanyAlbum(Long jobId, Integer page, Integer size);

    PageJsonResult<List<JobVo>> queryJobPage(Integer experience, Integer welfare, Integer education, Integer salaryMin, Integer salaryMax, String companyName, Integer companyWorkerNum, Integer page, Integer size);
}
