package com.life.admin.dto;


import com.life.admin.pojo.TopicReplyComment;

/**
 * @author Chunming Liu In 2022/08/21
 */
public class TopicReplyCommentDTO extends TopicReplyComment {
}
