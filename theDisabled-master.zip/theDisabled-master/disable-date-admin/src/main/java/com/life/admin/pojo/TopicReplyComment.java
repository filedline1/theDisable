package com.life.admin.pojo;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.time.LocalDateTime;

/**
 * @author Chunming Liu In 2022/08/21
 */
@ApiModel("话题回复评论")
@Document(indexName = "tb_disable_date_topic_comment_reply")
@Data
@TableName("tb_disable_date_topic_commit_reply")
public class TopicReplyComment {
    @Id
    @ApiModelProperty("ID")
    @Field(type = FieldType.Integer)
    @JsonSerialize(using = ToStringSerializer.class)
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;
    @ApiModelProperty("话题ID")
    @Field(type = FieldType.Integer)
    private Long topicId;
    @ApiModelProperty("被回复的评论ID")
    @Field(type = FieldType.Keyword)
    private Long commentId;
    @ApiModelProperty("父级评论ID")
    @Field(type = FieldType.Keyword)
    private Long parentCommentId;
    @ApiModelProperty("回复评论ID")
    @Field(type = FieldType.Keyword)
    private String replyId;

    @ApiModelProperty("回复评论人ID")
    @Field(type = FieldType.Long)
    private Long replyUserId;
    @ApiModelProperty("回复评论人名称")
    @Field(type = FieldType.Keyword)
    private String replyUserName;
    @ApiModelProperty("回复评论内容")
    @Field(type = FieldType.Keyword)
    private String replyContent;

    @ApiModelProperty("被评论的评论人ID")
    @Field(type = FieldType.Long)
    private Long commentUserId;
    @ApiModelProperty("被评论的评论人名称")
    @Field(type = FieldType.Keyword)
    private String commentUserName;
    @ApiModelProperty("回复状态：是否审核通过 1-未审核 2-审核通过 默认 2")
    @Field(type = FieldType.Integer)
    private Integer replyStatus;
    @ApiModelProperty(value = "点赞量", hidden = true)
    @Field(type = FieldType.Integer)
    private Integer likeAmount; //点赞量

    @ApiModelProperty(hidden = true)
    @Field(type = FieldType.Integer)
    @TableLogic
    private Integer isDeleted;   //'是否删除 1-未删除 2-已删除',
    @ApiModelProperty("创建时间")
    @Field(type = FieldType.Date, format = DateFormat.custom, pattern = "uuuu-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
