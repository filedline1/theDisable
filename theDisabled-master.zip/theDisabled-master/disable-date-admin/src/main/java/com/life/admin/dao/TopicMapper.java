package com.life.admin.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.life.admin.pojo.TopicEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

/**
 * @author Chunming Liu In 2022/08/21
 */
@Mapper
public interface TopicMapper extends BaseMapper<TopicEntity> {
    @Update("update tb_disable_date_user set sorts = sorts + #{i} where user_id=#{userId}")
    void addIntegral(@Param("userId") Long userId, @Param("i") Integer i);

    @Update("update tb_disable_date_user set sorts = sorts - #{i} where user_id=#{userId}")
    void minusIntegral(@Param("userId") Long userId, @Param("i") Integer i);

}
