package com.life.admin.vo;

import com.life.admin.pojo.ResumeEntity;

/**
 * @author Chunming Liu In 2022/08/23
 */
public class ResumeVo extends ResumeEntity {
}
