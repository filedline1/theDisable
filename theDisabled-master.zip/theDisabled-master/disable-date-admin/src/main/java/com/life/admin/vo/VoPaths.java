package com.life.admin.vo;

import lombok.Data;

import java.util.List;

/**
 * 接收两个数组
 */
@Data
public class VoPaths {
    private List<String> picPaths;
    private List<String> videoPaths;
}
