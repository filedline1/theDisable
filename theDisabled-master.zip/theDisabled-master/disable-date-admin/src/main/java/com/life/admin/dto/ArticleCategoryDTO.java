package com.life.admin.dto;


import com.life.admin.pojo.ArticleCategoryEntity;

/**
 * @author chunming
 * @date 2022-09-01 12:14:19
 */
public class ArticleCategoryDTO extends ArticleCategoryEntity {
}
