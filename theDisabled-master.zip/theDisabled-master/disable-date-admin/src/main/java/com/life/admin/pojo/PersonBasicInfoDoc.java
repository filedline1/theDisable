package com.life.admin.pojo;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PersonBasicInfoDoc {

    private Integer personId;

    private String personName;

    private Integer sex;

    private Integer age;

    private String phone;

    private String workAddr;

    private String householdAddr;

    private String maritalStatus;

    private Integer height;

    private Integer weight;

    private String degree;

    private Integer income;

    private String occupation;

    private String housingStatus;

    private String carStatus;

    private String expectedMarryTime;

    private String personIntro;

    private String personSign;

    private String location;

    private String wechat;

    private String wechatCodeImagesPath;

    private String qq;

    private String email;

    private String mv;
}
