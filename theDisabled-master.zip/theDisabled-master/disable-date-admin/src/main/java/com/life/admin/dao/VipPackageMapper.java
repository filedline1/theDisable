package com.life.admin.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.life.admin.pojo.VipPackage;
import com.life.admin.util.PageQueryUtil;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;


@Mapper
public interface VipPackageMapper extends BaseMapper<VipPackage> {
    /**
     * 获取记录的分页列表
     *
     * @param pageUtil
     * @return
     */
    List<VipPackage> findRecordList(PageQueryUtil pageUtil);

    int deleteByPrimaryKey(Integer id);

    int insert(VipPackage record);

    int insertSelective(VipPackage record);

    VipPackage selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(VipPackage record);

    int updateByPrimaryKey(VipPackage record);
}