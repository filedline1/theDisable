package com.life.admin.dto;

import com.life.admin.pojo.TopicComment;

/**
 * @author Chunming Liu In 2022/08/21
 */
public class TopicCommentDTO extends TopicComment {
}
