package com.life.admin.dto;

import com.life.admin.pojo.CompanyPhotoAlbumEntity;
import lombok.ToString;

/**
 * @author chunming
 * @date 2022-08-30 18:03:42
 */
@ToString
public class CompanyPhotoAlbumDTO extends CompanyPhotoAlbumEntity {
}
