package com.life.admin.vo;

import com.life.admin.pojo.TopicEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Chunming Liu In 2022/08/21
 */
@Getter
@Setter
public class TopicVo extends TopicEntity {
    @ApiModelProperty("是否已关注：话题人：0-未关注，1-已关注")
    private Integer alreadyConcern;
}
