package com.life.admin.vo;


import com.life.admin.pojo.ArticleEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author chunming
 * @date 2022-09-01 12:15:18
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ArticleVo extends ArticleEntity {
}
