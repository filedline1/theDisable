package com.life.admin.dao;

import com.life.admin.pojo.TopicEntity;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chunming Liu In 2022/08/27
 */
@Repository
public interface TopicRepository extends ElasticsearchRepository<TopicEntity, Long> {
}
