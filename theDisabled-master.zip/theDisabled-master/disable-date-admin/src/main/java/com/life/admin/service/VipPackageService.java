package com.life.admin.service;



import com.baomidou.mybatisplus.extension.service.IService;
import com.life.admin.pojo.VipPackage;
import com.life.admin.util.PageQueryUtil;

import java.util.List;

public interface VipPackageService extends IService<VipPackage> {

    List<VipPackage> findRecordList(PageQueryUtil pageUtil);

    void deleteByPrimaryKey(Integer id);

    int insert(VipPackage record);

    int insertSelective(VipPackage record);

    VipPackage selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(VipPackage record);

    int updateByPrimaryKey(VipPackage record);

}
