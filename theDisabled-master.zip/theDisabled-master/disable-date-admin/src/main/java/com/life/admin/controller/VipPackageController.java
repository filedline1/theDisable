package com.life.admin.controller;

import com.life.admin.common.JsonResult;
import com.life.admin.common.VipResult;
import com.life.admin.pojo.VipPackage;
import com.life.admin.service.VipPackageService;
import com.life.admin.util.PageQueryUtil;
import com.life.admin.util.ResultGenerator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
@Api(tags = "会员套餐管理")
@RestController
public class VipPackageController {

    @Autowired
    private VipPackageService vipPackageService;

    /**
     * 获取套餐信息的分页列表
     *
     * @param
     * @return
     */
    @ApiOperation("分页列表")
    @RequestMapping(value = "/vipPackage/list", method = RequestMethod.GET)
    public VipResult findRecordList(@Param("start") int start, @Param("limit") int limit) {
        PageQueryUtil params = new PageQueryUtil(start, limit);
        if (StringUtils.isEmpty(params.get("page")) || StringUtils.isEmpty(params.get("limit"))) {
            return ResultGenerator.genErrorResult(400, "参数传递格式有误！");
        }
        final List<VipPackage> recordList = vipPackageService.findRecordList(params);
        return ResultGenerator.genSuccessResult(recordList);
    }

    /**
     * 插入会员套餐信息
     *
     * @param record
     * @return
     */
    @ApiOperation("更新、插入")
    @PostMapping("/vipPackage/insertInfo")
    public VipResult<String> insertSelective(@RequestBody VipPackage record) {
        VipPackage vipPackage = vipPackageService.selectByPrimaryKey(record.getId());
        if (vipPackage == null) {
            if (vipPackageService.save(record)) {
                return ResultGenerator.genSuccessResult("新增套餐成功");
            }
        } else {
            if (vipPackageService.updateById(record)) {
                return ResultGenerator.genSuccessResult("更新套餐成功");
            }
        }
        return ResultGenerator.genFailResult("新增套餐失败");
    }

    @ApiOperation("删除")
    @DeleteMapping("vipPackage/delete")
    public JsonResult<Object> delete(@RequestParam Integer id) {
        vipPackageService.deleteByPrimaryKey(id);
        return JsonResult.success();
    }

    /**
     * 根据userId查找会员权限信息
     *
     * @param userId
     * @return
     */
    @ApiOperation("根据userId查找会员权限信息")
    @RequestMapping(value = "/vipPackage/userId", method = RequestMethod.POST)
    public VipResult<Object> selectByUserId(@RequestParam("userId") Integer userId) {
        VipPackage vipPackage = vipPackageService.selectByPrimaryKey(userId);
        if (vipPackage == null) {
            return ResultGenerator.genFailResult("该用户没有开通套餐记录");
        }
        return ResultGenerator.genSuccessResult(vipPackage);
    }
}
