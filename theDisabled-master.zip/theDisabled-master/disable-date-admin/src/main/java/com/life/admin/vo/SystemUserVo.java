package com.life.admin.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Chunming Liu In 2022/09/11
 */
@ApiModel("系统用户")
@Data
public class SystemUserVo {
    @ApiModelProperty("ID")
    private Long userId;
    @ApiModelProperty("用户名")
    private String nickName;
    @ApiModelProperty("头像")
    private String headPicPath;
}
