package com.life.admin.dto;

import com.life.admin.pojo.ArticleEntity;
import lombok.Data;

/**
 * @author chunming
 * @date 2022-09-01 12:15:05
 */
@Data
public class ArticleDTO extends ArticleEntity {
}
