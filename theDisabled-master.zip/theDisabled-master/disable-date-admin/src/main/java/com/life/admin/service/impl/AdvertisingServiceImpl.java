package com.life.admin.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.dao.AdvertisingMapper;
import com.life.admin.pojo.Advertising;
import com.life.admin.service.IAdvertisingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdvertisingServiceImpl extends ServiceImpl<AdvertisingMapper, Advertising> implements IAdvertisingService {

    @Autowired
    private AdvertisingMapper advertisingMapper;

    // 获取广告的列表
    public Page<Advertising> getAdvertisingList(Integer index, Integer size) {
        return advertisingMapper.selectPage(new Page<>(index, size), null);
    }
}
