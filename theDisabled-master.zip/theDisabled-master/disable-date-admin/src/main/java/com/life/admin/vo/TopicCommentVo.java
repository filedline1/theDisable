package com.life.admin.vo;


import com.life.admin.pojo.TopicComment;

/**
 * @author Chunming Liu In 2022/08/21
 */
public class TopicCommentVo extends TopicComment {
}
