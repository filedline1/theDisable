package com.life.admin.advise.exception;

/**
 * @author Chunming Liu In 2022/08/14
 */
public class NoVipException extends RuntimeException {

    private final Integer errorCode;

    public NoVipException(Integer errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public Integer getErrorCode() {
        return errorCode;
    }
}
