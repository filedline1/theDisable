package com.life.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.life.admin.common.PageJsonResult;
import com.life.admin.dto.JobDTO;
import com.life.admin.dto.CompanyPhotoAlbumDTO;
import com.life.admin.pojo.JobEntity;
import com.life.admin.vo.CompanyPhotoAlbumVo;
import com.life.admin.vo.JobVo;

import java.util.List;

/**
 * @author Chunming Liu In 2022/08/23
 */
public interface JobService extends IService<JobEntity> {
    void add(JobDTO jobDTO);

    void update(JobDTO jobDTO);

    PageJsonResult<List<JobVo>> queryJobPage(Integer experience, Integer welfare, Integer education, Integer salaryMin, Integer salaryMax, String companyName, Integer companyWorkerNum, Integer hide, Integer page, Integer size);

    JobVo detailJob(Long jobId, Long userId);

    void hideJob(Long jobId);

    void updateLogo(Long jobId, String logo);

    void uploadAlbum(CompanyPhotoAlbumDTO dto);

    void deleteAlbum(Long id);

    PageJsonResult<List<CompanyPhotoAlbumVo>> queryCompanyAlbum(Long jobId, Integer page, Integer size);

    void displayJob(Long jobId);
}
