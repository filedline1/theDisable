package com.life.admin.vo;

import com.life.admin.pojo.Report;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Chunming Liu In 2022/09/13
 */
@Data
public class ReportVo extends Report {
    @ApiModelProperty("举报人")
    private String user;
    @ApiModelProperty("被举报人")
    private String reportedUser;
}
