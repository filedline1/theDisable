package com.life.admin.pojo;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.util.Date;

/**
 * CREATE TABLE `tb_disable_diary_videos`  (
 *   `id` VARCHAR(64)
 *   `user_id` BIGINT(0)                '发布者id',
 *   `audio_id` VARCHAR(20)             '用户使用音频的信息',
 *   `video_desc` VARCHAR(128)          '视频描述',
 *   `video_path` VARCHAR(100)          '视频存放的路径',
 *   `video_seconds` FLOAT(6, 2)         '视频秒数',
 *   `video_width` INT(0)                '视频宽度',
 *   `video_height` INT(0)               '视频高度',
 *   `cover_path` VARCHAR(100)          '视频封面图  路径',
 *   `like_counts` BIGINT(0)            '喜欢/赞美的数量',
 *   `status` INT(0)                    '视频状态：1-发布成功 2-未过审，管理员操作',
 *   `create_time` DATETIME(0)           '创建时间',
 */
@Document(indexName = "tb_disable_diary_videos")
@Data
@TableName("tb_disable_diary_videos")
public class Video {
    @Field(type = FieldType.Integer)
    private String id;
    @Field(type = FieldType.Keyword)
    private String videoId;
    @Field(type = FieldType.Keyword)
    private String diaryId;
    @Field(type = FieldType.Keyword)
    private String userId; // 发布者id
    @Field(type = FieldType.Keyword)
    private String videoDesc;
    @Field(type = FieldType.Keyword)
    private String videoPath;
    @Field(type = FieldType.Integer)
    private Integer likeCounts;
    @Field(type = FieldType.Integer)
    private Integer status;// 视频状态：0-审核不通过 1-发布成功 2-待审核
    @Field(type = FieldType.Keyword)
    private String coverPath;
    @Field(type = FieldType.Keyword)
    private float videoSeconds;
    @Field(type = FieldType.Integer)
    private Integer videoWidth;
    @Field(type = FieldType.Integer)
    private Integer videoHeight;
    @Field(type = FieldType.Date, format = DateFormat.date_time)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
}
