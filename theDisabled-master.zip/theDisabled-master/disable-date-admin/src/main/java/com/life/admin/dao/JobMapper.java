package com.life.admin.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.life.admin.pojo.JobEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Chunming Liu In 2022/08/23
 */
@Mapper
public interface JobMapper extends BaseMapper<JobEntity> {
}
