package com.life.admin.pojo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.util.Date;

/**
 * #评论（视频秀、动态）
 * DROP TABLE IF EXISTS `tb_disable_date_diary_comment`;
 * CREATE TABLE `tb_disable_date_diary_comment`  (
 * `id` BIGINT(0) NOT NULL AUTO_INCREMENT COMMENT 'id',
 * `comment_id` VARCHAR(60)                        '评论主键id',
 * `diary_id` BIGINT(0)                           '关联的diary主键',     #视频秀 or 动态 的id
 * `commentator_name` VARCHAR(20)                 '评论者昵称',
 * `comment_body` VARCHAR(200)                    '评论内容',
 * `comment_create_time` DATETIME(0)              '评论提交时间',
 * `commentator_ip` VARCHAR(20)                   '评论时的ip地址',
 * `reply_amount` BIGINT(0)  '本条评论的回复数量',
 * `reply_body` VARCHAR(200)                      '回复内容',
 * `reply_create_time` DATETIME(0)                '回复时间',
 * `comment_status` TINYINT(0)                    '是否审核通过 1-未审核 2-审核通过',
 * `is_deleted` TINYINT(0)                        '是否删除 1-未删除 2-已删除',
 * PRIMARY KEY (`comment_id`) USING BTREE
 */
@Document(indexName = "tb_disable_date_diary_comment")
@Data
@TableName("tb_disable_date_diary_comment")
public class Comment {
    @Id
    @Field(type = FieldType.Integer)
    private Integer id;
    @Field(type = FieldType.Keyword)
    private String commentId;
    @Field(type = FieldType.Keyword)
    private String diaryId;
    @Field(type = FieldType.Keyword)
    private String commentatorName;
    @Field(type = FieldType.Keyword)
    private String commentBody;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Field(type = FieldType.Date,format = DateFormat.date_time)
    private Date commentCreateTime;
    @Field(type = FieldType.Keyword)
    private String commentatorIp;
    @Field(type = FieldType.Integer)
    private Integer replyAmount;
    @Field(type = FieldType.Integer)
    private Integer commentStatus;
    @Field(type = FieldType.Integer)
    private Integer isDeleted;   //'是否删除 1-未删除 2-已删除',
    @Field(type = FieldType.Integer)
    private Integer likeAmount; //点赞量

}
