package com.life.admin.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.common.PageJsonResult;
import com.life.admin.dao.ReportMapper;
import com.life.admin.dao.UserMapper;
import com.life.admin.pojo.Report;
import com.life.admin.pojo.User;
import com.life.admin.service.ReportService;
import com.life.admin.vo.ReportVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ReportServiceImpl extends ServiceImpl<ReportMapper, Report> implements ReportService {

    @Autowired
    UserMapper userMapper;
    @Autowired
    private ReportMapper reportMapper;

    // 分页查询待审核的举报信息
    public PageJsonResult<List<ReportVo>> getReports(Integer index, Integer size) {
        LambdaQueryWrapper<Report> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.orderByDesc(Report::getCreateTime);
        Page<Report> reportPage = reportMapper.selectPage(new Page<>(index, size), queryWrapper);
        List<ReportVo> reportVoList = new ArrayList<>();

        for (Report record : reportPage.getRecords()) {
            ReportVo reportVo = new ReportVo();
            BeanUtil.copyProperties(record, reportVo);
            User user = userMapper.getUserByUser_id(Long.valueOf(reportVo.getUserId()));
            User reportUser = userMapper.getUserByUser_id(Long.valueOf(reportVo.getReportedUserId()));
            reportVo.setUser(user == null ? "" : user.getNickName());
            reportVo.setReportedUser(reportUser == null ? "" : reportUser.getNickName());
            reportVoList.add(reportVo);
        }
        return PageJsonResult.success(index, size, reportPage.getTotal(), reportVoList);
    }

    // 获取举报待审核的总数
    public Integer getReportsAmount() {
        List<Report> reports = reportMapper.getReportsAmount();
        return reports.size();
    }
}
