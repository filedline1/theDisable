package com.life.admin.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author Chunming Liu In 2022/09/06
 */
@Configuration
public class WebMvcInterceptorConfigurer implements WebMvcConfigurer {

    @Autowired
    LogicHandlerInterceptor logicHandlerInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // registry.addInterceptor(logicHandlerInterceptor);
    }
}
