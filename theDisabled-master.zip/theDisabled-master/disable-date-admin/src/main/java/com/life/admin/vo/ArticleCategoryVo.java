package com.life.admin.vo;

import com.life.admin.pojo.ArticleCategoryEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author chunming
 * @date 2022-09-01 12:13:58
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ArticleCategoryVo extends ArticleCategoryEntity {
}
