package com.life.admin.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.dao.FestivalMapper;
import com.life.admin.pojo.Festival;
import com.life.admin.service.IFestivalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FestivalServiceImpl extends ServiceImpl<FestivalMapper, Festival> implements IFestivalService {

    @Autowired
    private FestivalMapper festivalMapper;

    // 获取节日的列表（按照序号进行升序查询）
    public Page<Festival> getFestivalList(Integer index, Integer size) {
        return festivalMapper.selectPage(new Page<>(index, size), null);
    }
}
