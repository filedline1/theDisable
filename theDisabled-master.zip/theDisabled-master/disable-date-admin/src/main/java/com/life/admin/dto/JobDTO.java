package com.life.admin.dto;

import com.life.admin.pojo.JobEntity;
/**
 * @author Chunming Liu In 2022/08/23
 */
public class JobDTO extends JobEntity {
}
