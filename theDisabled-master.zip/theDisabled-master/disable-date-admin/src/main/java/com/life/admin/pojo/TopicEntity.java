package com.life.admin.pojo;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.time.LocalDateTime;

/**
 * @author Chunming Liu In 2022/08/21
 */
@ApiModel("话题")
@Document(indexName = "tb_disable_date_topic")
@TableName("tb_disable_date_topic")
@Data
public class TopicEntity {
    @Id
    @JsonSerialize(using = ToStringSerializer.class)
    @TableId(type = IdType.AUTO)
    @ApiModelProperty("ID")
    @Field(type = FieldType.Long)
    private Long id;
    @ApiModelProperty("发布人ID")
    @Field(type = FieldType.Long)
    private Long userId;
    @ApiModelProperty("话题标题")
    @Field(type = FieldType.Keyword)
    private String title;
    @ApiModelProperty("话题内容")
    @Field(type = FieldType.Keyword)
    private String context;
    @ApiModelProperty("是否置顶：0-不置顶，1-置顶")
    @Field(type = FieldType.Integer)
    private Integer top;
    @ApiModelProperty("更新者")
    @Field(type = FieldType.Keyword)
    private String updater;
    @ApiModelProperty("评论数量")
    @Field(type = FieldType.Long)
    private Long commitCount;
    @ApiModelProperty("回复评论数量")
    @Field(type = FieldType.Long)
    private Long replyCommitCount;
    @ApiModelProperty("总评论数：评论数+回复数")
    @Field(type = FieldType.Long)
    private Long totalCommitCount;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty("创建时间")
    @Field(type = FieldType.Date, format = DateFormat.custom, pattern = "uuuu-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty("更新时间")
    @Field(type = FieldType.Date, format = DateFormat.custom, pattern = "uuuu-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    @TableLogic
    @ApiModelProperty(hidden = true)
    @Field(type = FieldType.Integer)
    private Integer isDeleted;
    @Field(type = FieldType.Boolean)
    @ApiModelProperty("是否系统创建")
    private Boolean isSystem;
}
