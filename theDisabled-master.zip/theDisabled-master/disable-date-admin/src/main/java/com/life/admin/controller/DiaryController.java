package com.life.admin.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.life.admin.common.JsonResult;
import com.life.admin.common.PersonBasicInfoRestClient;
import com.life.admin.constants.MqConstants;
import com.life.admin.pojo.*;
import com.life.admin.service.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

/**
 * 有关动态的接口
 */
@Api(tags = "动态")
@RestController
@RequestMapping("/social")
public class DiaryController {

    final
    PersonBasicInfoRestClient personBasicInfoRestClient;
    private final DiaryService diaryService;
    private final IPictureService pictureService;
    private final ICommentService commentService;
    private final IUserService userService;
    private final IVideoService videoService;
    // 输入发送消息的API
    private final RabbitTemplate rabbitTemplate;

    public DiaryController(PersonBasicInfoRestClient personBasicInfoRestClient,
                           DiaryService diaryService, IPictureService pictureService,
                           ICommentService commentService, IUserService userService,
                           IVideoService videoService,
                           RabbitTemplate rabbitTemplate) {
        this.personBasicInfoRestClient = personBasicInfoRestClient;
        this.diaryService = diaryService;
        this.pictureService = pictureService;
        this.commentService = commentService;
        this.userService = userService;
        this.videoService = videoService;
        this.rabbitTemplate = rabbitTemplate;
    }

    /**
     * 统计附近的动态的总数连
     */
    @GetMapping("/getNearTotal")
    public JsonResult<Integer> getNearPages(HttpServletRequest request) {
        try {

            Integer total = 0;
            for (int page = 1; ; page++) {
                // 根据这个索引库的字段来进行排序
                String name = "createTime";
                String sortOrder = "DESC";
                //获取多条动态
                List<Diary> diaries = diaryService.gertNearActiveList(name, page, 10, sortOrder);
                if (diaries == null || diaries.size() == 0) {
                    break;
                } else {
                    total += diaries.size();
                }
            }
            return JsonResult.success(total);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * 获取附近的动态列表(进行分页查找，优先进行距离上的升序，再进行时间上的降序查找)   //ps:距离条件还没还没加上
     */
    @ApiOperation("查询动态")
    @GetMapping("/active/getNearActiveList")
    public JsonResult<JSONArray> getNearActiveList(@RequestParam(defaultValue = "1") Integer page,
                                                   @RequestParam(defaultValue = "10") Integer size) {
        try {

            JSONArray jsonArray = new JSONArray();   // 存储json的结果集

            String name = "createTime";  // 根据这个索引库的字段来进行排序
            String sortOrder = "DESC";
            // 获取多条动态
            List<Diary> diaries = diaryService.gertNearActiveList(name, page, size, sortOrder);

            JsonResult<JSONArray> jsonResult = new JsonResult<>();
            if (diaries != null) {
                // 遍历动态,获取所有的 diary动态信息、图片、视频、头像添加 进行jsonobject,再添加到jsonArray
                findPicOrVideo(jsonArray, diaries);

                System.out.println("jsonArray的结果集：");
                System.out.println(jsonArray);

                jsonResult.setData(jsonArray);
            } else {

                jsonResult.setData(jsonArray);
                jsonResult.setMessage("没有符合条件的动态数据");
            }
            return jsonResult;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @ApiOperation("查询动态评论")
    @GetMapping("/active/getCommentList")
    public JsonResult<JSONArray> getCommentList(@RequestParam(defaultValue = "1") String page,
                                                @RequestParam(defaultValue = "10") String size,
                                                @RequestParam("diaryId") String diaryId) {
        try {
            JSONArray jsonArray = new JSONArray();
            List<Comment> list;
            // 根据动态id获取动态的所有评论（在索引库中查找）
            String sortName = "commentCreateTime";   // 进行升序依序的索引库中的字段名
            String sortOrder = "DESC";   // ASC表示升序，DESC表示降序
            list = diaryService.getAllCommentByDiaryId(page, size, sortName, sortOrder, diaryId);

            for (Comment comment : list) {
                System.out.println("————>" + comment.getCommentCreateTime());

                JSONObject jsonObject = new JSONObject();

                User user = userService.getUserByUser_id(StringUtils.isBlank(comment.getCommentatorIp()) ? null : Long.valueOf(comment.getCommentatorIp()));
                if (user != null) {
                    String head_path = user.getHeadPicPath();
                    jsonObject.put("headPicture", head_path);        // 头像
                    comment.setCommentatorName(user.getNickName());
                }

                jsonObject.put("comment", comment);
                jsonObject.put("Flag", false);

                jsonObject.put("page", 1);
                jsonObject.put("replyAmountTemp", comment.getReplyAmount());
                jsonObject.put("flag", false);
                int total = 0;   // 存储评论的总数量
                for (int p = 1; ; p++) {
                    List<Comment> commentList = diaryService.getAllCommentByDiaryId(p + "", 10 + "", sortName, sortOrder, diaryId);
                    if (commentList == null || commentList.isEmpty()) break;
                    total += commentList.size();
                }
                jsonObject.put("total", total);

                List<Reply> replys;
                // 根据评论的id 查找其所有的 回复（在索引库中查找）
                String sort = "createTime";   // 进行升序依序的索引库中的字段名
                String Order = "ASC";   // ASC表示升序，DESC表示降序
                replys = commentService.getAllReplyByDiaryId("1", "2", sort, Order, comment.getCommentId());
                jsonObject.put("children", replys);
                jsonArray.add(jsonObject);
            }
            System.out.println("—————————————————————————————————————获取到的评论队列—————————————————————————————————————————————————————");
            System.out.println(list);
            System.out.println("———————————————————————————————————————————————————————————————————————————————————————————————————————");
            JsonResult<JSONArray> jsonResult = new JsonResult<>();

            if (jsonArray.isEmpty()) jsonResult.setData(null);
            else jsonResult.setData(jsonArray);

            return jsonResult;
        } catch (IOException e) {
            throw new RuntimeException();
        }
    }

    @ApiOperation("查询动态评论回复")
    @GetMapping("/active/getReplyList")
    public JsonResult<JSONArray> getAllReplyByDiaryId(@RequestParam("page") String page,
                                                      @RequestParam("size") String size,
                                                      @RequestParam("commentId") String commentId) {

        try {
            JsonResult<JSONArray> jsonResult = new JsonResult<>();
            JSONArray jsonArray = new JSONArray();
            System.out.println("commentId:" + commentId);

            // 根据评论的id 查找其所有的 回复（在索引库中查找）
            String sortName = "createTime";   // 进行升序依序的索引库中的字段名
            String sortOrder = "DESC";   // ASC表示升序，DESC表示降序
            List<Reply> list = commentService.getAllReplyByDiaryId(page, size, sortName, sortOrder, commentId);
            for (Reply reply : list) {
                System.out.println("-->" + reply.getCreateTime() + "-" + reply.getReplyContent());
                JSONObject jsonObject = new JSONObject();
                User user = userService.getUserByUser_id(StringUtils.isBlank(reply.getReplyUserId()) ? null : Long.valueOf(reply.getReplyUserId()));
                User replyUser = userService.getUserByUser_id(StringUtils.isBlank(reply.getCommentUserId()) ? null : Long.valueOf(reply.getCommentUserId()));
                if (user != null && replyUser != null) {
                    String head_path = user.getHeadPicPath();
                    jsonObject.put("headPicture", head_path);        // 头像
                    reply.setReplyUserName(user.getNickName());
                    reply.setCommentUserName(replyUser.getNickName());
                }
                jsonObject.put("comment", reply);
                jsonArray.add(jsonObject);

                if (jsonArray.isEmpty())
                    jsonResult.setData(null);
                else jsonResult.setData(jsonArray);
            }
            return jsonResult;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * 用户自己删除动态
     * 1.删除数据库中的动态信息
     * 同步索引库删除动态信息
     * 2.删除数据库中的动态的所有评论
     * 同步索引库删除评论
     * 3.删除数据库中的所有回复
     * 同步删除索引库中的回复
     * 4.删除数据库中的配图
     * 同步索引库删除配图
     * 5.删除数据库中的视频
     * 同步索引库删除视频
     * 6.删除数据库中的点赞
     */
    @ApiOperation("用户动态")
    @DeleteMapping("/active/deleteDiary")
    public JsonResult<Object> deleteDiary(@RequestParam("diaryId") String diaryId) {
        Diary diary = diaryService.getDiaryByDiaryId(diaryId);
        String Did = diary.getId() + "";
        // 需要从es中删除，先mq发送求信息
        rabbitTemplate.convertAndSend(MqConstants.DIARY_EXCAHGNE, MqConstants.DIARY_DELETE_KEY, Did);
        diaryService.deleteDiary(diaryId);   // 从数据库中删除动态

        List<Comment> commentList = commentService.getCommentByDiaryId(diaryId);
        if (commentList != null && commentList.size() != 0)
            for (Comment comment : commentList) {  // 需要从es中删除，先mq发送求信息
                rabbitTemplate.convertAndSend(MqConstants.COMMENT_EXCAHGNE, MqConstants.COMMENT_DELETE_KEY, comment.getId() + "");
                diaryService.deleteAllLikeRecord(comment.getCommentId());  // 删除用户对其的点赞记录
            }
        commentService.deleteComments(diaryId);   // 从数据库中删除动态的所有评论

        List<Reply> replyList = commentService.getRepliesByDiaryId(diaryId);
        if (replyList != null && replyList.size() != 0) {
            for (Reply reply : replyList) {  // 需要从es中删除，先Mq发从请求信息
                rabbitTemplate.convertAndSend(MqConstants.REPLY_EXCAHGNE, MqConstants.REPLY_DELETE_KEY, reply.getId() + "");
                diaryService.deleteAllLikeRecord(reply.getReplyId());     // 删除用户对其的点赞记录
            }
        }
        commentService.deleteReplies(diaryId);  // 从数据库中删除动态的所有回复

        if (diary.getDiaryKind() == 1) {   // 图文动态
            List<Picture> pictureList = pictureService.getPicturesByDiaryId(diaryId);
            if (pictureList != null && pictureList.size() != 0)
                for (Picture picture : pictureList) {  // 需要从es中删除，先Mq发从请求信息
                    rabbitTemplate.convertAndSend(MqConstants.PICTURE_EXCAHGNE, MqConstants.PICTURE_DELETE_KEY, picture.getId() + "");
                }
            pictureService.deletePictures(diaryId);  // 从数据库中删除动态的所有配图
        } else if (diary.getDiaryKind() == 2) {  // 视频动态
            // 索引库中中找到动态的视频
            Video video = videoService.getDiaryVideos(diary.getDiaryId());
            if (video != null) {
                System.out.println("------->" + video);
                System.out.println("112-2-21-421-4   //从数据库中删除动态视频  4-24-21-4-124-");
                System.out.println("--->" + video.getVideoId());
                String massage = video.getVideoId();
                // 索引库同步删除 mq有问题
                rabbitTemplate.convertAndSend(MqConstants.DIARYVIDEO_EXCAHGNE, MqConstants.DIARYVIDEO_DELETE_KEY, massage);
                videoService.deleteDiaryVideo(diary.getDiaryId());   // 从数据库中删除动态视频
                // 从索引库中删除视频
                System.out.println("--- 从索引库中删除视频 ---");
            }
        }

        // 从数据库中删除对这个的点赞的记录
        diaryService.deleteAllLikeRecord(diary.getDiaryId());

        // 删除用户收藏的记录
        userService.deleteCollectByLikeId(diary.getDiaryId());

        return JsonResult.success("成功删除");
    }


    @ApiOperation("删除评论")
    @DeleteMapping("/active/deleteComment")
    @Transactional(rollbackFor = Exception.class)    // 表示的是该方法无论抛出什么异常都会进行自动回滚
    public JsonResult<Object> deleteComment(@RequestParam("commentId") String commentId) {
        try {
            // 删除评论
            Comment comment = commentService.getCommentById(commentId);
            // 需要从es中删除，先Mq发从请求信息
            if (comment != null) {
                rabbitTemplate.convertAndSend(MqConstants.COMMENT_EXCAHGNE, MqConstants.COMMENT_DELETE_KEY, comment.getId() + "");

                // 删除该该评论的所有回复
                List<Reply> replyList = commentService.getRepliesByDiaryId(comment.getDiaryId());
                if (replyList != null && replyList.size() != 0)
                    for (Reply reply : replyList) {  // 需要从es中删除，先Mq发从请求信息
                        rabbitTemplate.convertAndSend(MqConstants.REPLY_EXCAHGNE, MqConstants.REPLY_DELETE_KEY, reply.getId() + "");
                    }
                commentService.deleteReplies(comment.getDiaryId());   // 从数据库中删除评论

                // 从数据库中删除所有有关该评论的点赞记录
                diaryService.deleteUserLike(commentId);
            }
            commentService.deleteCommentByCommentId(commentId);

            return JsonResult.success();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @ApiOperation("删除评论的回复")
    @DeleteMapping("/active/deleteReply")
    public JsonResult<Object> deleteReply(@RequestParam("replyId") String replyId) {
        Reply reply = commentService.getReplyById(replyId);
        if (reply != null)  // 需要从es中删除，先Mq发从请求信息
            rabbitTemplate.convertAndSend(MqConstants.REPLY_EXCAHGNE, MqConstants.REPLY_DELETE_KEY, reply.getId() + "");
        commentService.deleteReplyByReplyId(replyId);   // 从数据库中删除回复
        // 从数据库中删除所有有关该回复的点赞记录
        diaryService.deleteUserLike(replyId);
        return JsonResult.success();
    }

    // 根据动态的id 识别动态类型，并找出 路径 --> 合并和整合 得到一个 JSONArray类型的结果
    private void findPicOrVideo(JSONArray jsonArray, List<Diary> diaries) {
        try {
            for (Diary diary : diaries) {
                JSONObject jsonObject = new JSONObject();
                BasicInfo basicInfo = userService.getBasicInfoByUserId(diary.getDiaryUserId());
                String location = "";
                if (basicInfo != null)
                    location = basicInfo.getLatitude() + ", " + basicInfo.getLongitude();  // 纬度，经度
                jsonObject.put("location", location);

                jsonObject.put("flag", 1);
                jsonObject.put("diary", diary);                  // 添加动态信息

                User user = userService.getUserByUser_id(StringUtils.isBlank(diary.getDiaryUserId()) ? null : Long.valueOf(diary.getDiaryUserId()));
                if (user != null) {
                    String head_path = user.getHeadPicPath();
                    jsonObject.put("headPicture", head_path);        // 头像
                    // 名称
                    diary.setDiaryUserName(user.getNickName());
                }

                if (diary.getDiaryKind() == 1) {   // 1-代表图文动态
                    List<String> pictures = pictureService.getPathById("diaryId", diary.getDiaryId());
                    jsonObject.put("picture", pictures);          // 添加 配图的路径
                } else if (diary.getDiaryKind() == 2) {  // 2-视屏类动态
                    List<String> videoPaths = videoService.getPathById("diaryId", diary.getDiaryId());
                    if (videoPaths.size() > 0) {
                        jsonObject.put("video", videoPaths.get(0));          // 添加 视频的路径
                    }
                }
                jsonArray.add(jsonObject);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
