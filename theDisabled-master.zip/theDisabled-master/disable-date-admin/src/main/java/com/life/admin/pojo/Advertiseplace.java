package com.life.admin.pojo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * CREATE TABLE `tb_disable_date_admin_advertising_place_manage` (
 *   `id` int NOT NULL AUTO_INCREMENT COMMENT '广告位id',
 *   `name` varchar(50) DEFAULT NULL COMMENT '广告位名称',
 *   `description` varchar(30) DEFAULT NULL COMMENT '广告位描述',
 *   `use_status` int DEFAULT NULL COMMENT '广告使用状态 0-未使用 1-使用',
 *   `type` int DEFAULT NULL COMMENT '栏目类型',
 *   `advertising_name` varchar(50) DEFAULT NULL COMMENT '已插入的广告名称',
 *   `advertising_id` int DEFAULT NULL COMMENT '已插入的广告id 0-没有 非0-有',
 *   `advertising_status` int DEFAULT NULL COMMENT '广告的状态 0—待使用 1-使用',
 *   `number` int DEFAULT NULL COMMENT '序号',
 *   `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
 *   `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
 *   PRIMARY KEY (`id`)
 * ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
 */
@Data
@TableName("tb_disable_date_admin_advertising_place_manage")
public class Advertiseplace {
    @ApiModelProperty("广告位id")
    private Integer id;
    @ApiModelProperty("广告位名称")
    private String name;
    @ApiModelProperty("广告位描述广告位描述")
    private String description;
    @ApiModelProperty("广告使用状态 0-未使用 1-使用")
    private Integer use_status;   //广告使用状态 0-未使用 1-使用
    @ApiModelProperty("栏目类型")
    private Integer type;
    @ApiModelProperty("已插入的广告名称")
    private String advertisingName;      //已插入的广告名称
    @ApiModelProperty("已插入的广告id 0-没有 非0-有")
    private Integer advertisingId;       //已插入的广告id 0-没有 非0-有
    @ApiModelProperty("广告的状态 0—待使用 1-使用")
    private Integer advertisingStatus;   //广告的状态 0—待使用 1-使用
    @ApiModelProperty("序号")
    private Integer number;              //序号
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty("创建时间")
    private Date createTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty("更新时间")
    private Date updateTime;
}
