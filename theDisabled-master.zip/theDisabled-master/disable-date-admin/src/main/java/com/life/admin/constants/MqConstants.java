package com.life.admin.constants;



//定义交换机的 常量
public class MqConstants {

//————————————————————————————————————————————————————diary————————————————————————————————————————————————————————————————
    /**
     * 交换机
     */
    public final static String DIARY_EXCAHGNE = "diary.topic";
    public final static String TOPIC_EXCAHGNE = "topic.topic";

    /**
     * 监听新增和修改的队列
     */
    public final static String DIARY_INSERT_QUEUE = "diary.insert.queue";
    public final static String TOPIC_INSERT_QUEUE = "topic.insert.queue";

    /**
     * 监听删除的队列
     */
    public final static String DIARY_DELETE_QUEUE = "diary.delete.queue";
    public final static String TOPIC_DELETE_QUEUE = "topic.delete.queue";

    /**
     * 新增或修改的RoutingKey
     */
    public final static String DIARY_INSERT_KEY = "diary.insert";
    public final static String TOPIC_INSERT_KEY = "topic.insert";

    /**
     * 删除的RoutingKey
     */
    public final static String DIARY_DELETE_KEY = "diary.delete";
    public final static String TOPIC_DELETE_KEY = "topic.delete";
//————————————————————————————————————————————————————diary end————————————————————————————————————————————————————————————————

//————————————————————————————————————————————————————picture————————————————————————————————————————————————————————————————
    /**
     * 交换机
     */
    public final static String PICTURE_EXCAHGNE = "picture.topic";

    /**
     * 监听新增和修改的队列
     */
    public final static String PICTURE_INSERT_QUEUE = "picture.insert.queue";

    /**
     * 监听删除的队列
     */
    public final static String PICTURE_DELETE_QUEUE = "picture.delete.queue";

    /**
     * 新增或修改的RoutingKey
     */
    public final static String PICTURE_INSERT_KEY = "picture.insert";

    /**
     * 删除的RoutingKey
     */
    public final static String PICTURE_DELETE_KEY = "picture.delete";

//————————————————————————————————————————————————————picture end———————————————————————————————————————————————————————————

//————————————————————————————————————————————————————comment————————————————————————————————————————————————————————————————
    /**
     * 交换机
     */
    public final static String COMMENT_EXCAHGNE = "comment.topic";
    public final static String TOPIC_COMMENT_EXCAHGNE = "topic.comment.topic";

    /**
     * 监听新增和修改的队列
     */
    public final static String COMMENT_INSERT_QUEUE = "comment.insert.queue";
    public final static String TOPIC_COMMENT_INSERT_QUEUE = "topic.comment.insert.queue";

    /**
     * 监听删除的队列
     */
    public final static String COMMENT_DELETE_QUEUE = "comment.delete.queue";
    public final static String TOPIC_COMMENT_DELETE_QUEUE = "topic.comment.delete.queue";

    /**
     * 新增或修改的RoutingKey
     */
    public final static String COMMENT_INSERT_KEY = "comment.insert";
    public final static String TOPIC_COMMENT_INSERT_KEY = "topic.comment.insert";

    /**
     * 删除的RoutingKey
     */
    public final static String COMMENT_DELETE_KEY = "comment.delete";
    public final static String TOPIC_COMMENT_DELETE_KEY = "topic.comment.delete";

//————————————————————————————————————————————————————comment end———————————————————————————————————————————————————————————

//————————————————————————————————————————————————————评论的回复 reply————————————————————————————————————————————————————————————————
    /**
     * 交换机
     */
    public final static String REPLY_EXCAHGNE = "reply.topic";
    public final static String TOPIC_REPLY_EXCAHGNE = "topic.reply.topic";

    /**
     * 监听新增和修改的队列
     */
    public final static String REPLY_INSERT_QUEUE = "reply.insert.queue";
    public final static String TOPIC_REPLY_INSERT_QUEUE = "topic.reply.insert.queue";

    /**
     * 监听删除的队列
     */
    public final static String REPLY_DELETE_QUEUE = "reply.delete.queue";
    public final static String TOPIC_REPLY_DELETE_QUEUE = "topic.reply.delete.queue";

    /**
     * 新增或修改的RoutingKey
     */
    public final static String REPLY_INSERT_KEY = "reply.insert";
    public final static String TOPIC_REPLY_INSERT_KEY = "topic.reply.insert";

    /**
     * 删除的RoutingKey
     */
    public final static String REPLY_DELETE_KEY = "reply.delete";
    public final static String TOPIC_REPLY_DELETE_KEY = "topic.reply.delete";

//————————————————————————————————————————————————————评论的回复 reply end———————————————————————————————————————————————————————————

//    LIKEVIDEO_EXCAHGNE


//————————————————————————————————————————————————————tb_disable_diary_videos ————————————————————————————————————————————————————————————————
    /**
     * 交换机
     */
    public final static String DIARYVIDEO_EXCAHGNE = "diaryVideos.topic";
    /**
     * 监听新增和修改的队列
     */
    public final static String DIARYVIDEO_INSERT_QUEUE = "diaryVideos.insert.queue";

    /**
     * 监听删除的队列
     */
    public final static String DIARYVIDEO_DELETE_QUEUE = "diaryVideos.delete.queue";

    /**
     * 新增或修改的RoutingKey
     */
    public final static String DIARYVIDEO_INSERT_KEY = "diaryVideos.insert";

    /**
     * 删除的RoutingKey
     */
    public final static String DIARYVIDEO_DELETE_KEY = "diaryVideos.delete";

//————————————————————————————————————————————————————tb_disable_diary_videos  end———————————————————————————————————————————————————————————

    //————————————————————————————————————————————————————tb_disable_date_user_collect ————————————————————————————————————————————————————————————————
    /**
     * 交换机
     */
    public final static String COLLECT_EXCAHGNE = "collect.topic";
    /**
     * 监听新增和修改的队列
     */
    public final static String COLLECT_INSERT_QUEUE = "collect.insert.queue";

    /**
     * 监听删除的队列
     */
    public final static String COLLECT_DELETE_QUEUE = "collect.delete.queue";

    /**
     * 新增或修改的RoutingKey
     */
    public final static String COLLECT_INSERT_KEY = "collect.insert";

    /**
     * 删除的RoutingKey
     */
    public final static String COLLECT_DELETE_KEY = "collect.delete";

//————————————————————————————————————————————————————tb_disable_date_user_collect  end———————————————————————————————————————————————————————————


    /**
     * 交换机
     */
    public final static String REQUIREMENT_EXCHANGE = "requirement.topic";

    /**
     * 监听新增和修改的队列
     */
    public final static String REQUIREMENT_INSERT_QUEUE = "requirement.insert.queue";

    /**
     * 监听删除的队列
     */
    public final static String REQUIREMENT_DELETE_QUEUE = "requirement.delete.queue";

    /**
     * 新增或修改的RoutingKey
     */
    public final static String REQUIREMENT_INSERT_KEY = "requirement.insert";

    /**
     * 删除的RoutingKey
     */
    public final static String REQUIREMENT_DELETE_KEY = "requirement.delete";


    /**
     * 交换机
     */
    public final static String PERSON_BASIC_INFO_EXCHANGE = "personbasicinfo.topic";

    /**
     * 监听新增和修改的队列
     */
    public final static String PERSON_BASIC_INFO_INSERT_QUEUE = "personbasicinfo.insert.queue";

    /**
     * 监听删除的队列
     */
    public final static String PERSON_BASIC_INFO_DELETE_QUEUE = "personbasicinfo.delete.queue";

    /**
     * 新增或修改的RoutingKey
     */
    public final static String PERSON_BASIC_INFO_INSERT_KEY = "personbasicinfo.insert";

    /**
     * 删除的RoutingKey
     */
    public final static String PERSON_BASIC_INFO_DELETE_KEY = "personbasicinfo.delete";

    /**
     * 交换机
     */
    public final static String PERSON_DETAIL_INFO_EXCHANGE = "persondetailinfo.topic";

    /**
     * 监听新增和修改的队列
     */
    public final static String PERSON_DETAIL_INFO_INSERT_QUEUE = "persondetailinfo.insert.queue";

    /**
     * 监听删除的队列
     */
    public final static String PERSON_DETAIL_INFO_DELETE_QUEUE = "persondetailinfo.delete.queue";

    /**
     * 新增或修改的RoutingKey
     */
    public final static String PERSON_DETAIL_INFO_INSERT_KEY = "persondetailinfo.insert";

    /**
     * 删除的RoutingKey
     */
    public final static String PERSON_DETAIL_INFO_DELETE_KEY = "persondetailinfo.delete";

}
