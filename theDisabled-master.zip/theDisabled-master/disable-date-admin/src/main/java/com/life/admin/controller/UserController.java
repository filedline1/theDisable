package com.life.admin.controller;

import cn.hutool.core.date.DateUtil;
import com.life.admin.common.JsonResult;
import com.life.admin.common.PageJsonResult;
import com.life.admin.pojo.PersonBasicInfo;
import com.life.admin.pojo.PersonDetailInfo;
import com.life.admin.pojo.Requirement;
import com.life.admin.pojo.User;
import com.life.admin.service.IUserService;
import com.life.admin.vo.SystemUserVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户管理
 * 用户信息
 */
@Api(tags = "用户管理")
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private IUserService userService;

    // TODO: 2022/9/11 创建系统用户
    @PostMapping("systemCreate")
    public JsonResult<Object> createSystemUser(@RequestParam(defaultValue = "") Long id,
                                               @RequestParam Long manageId,
                                               @RequestParam String nickleName,
                                               @RequestParam String headerImg) {
        Long systemUserId = userService.createSystemUser(id, manageId, nickleName, headerImg);
        return JsonResult.success(Collections.singletonMap("id", systemUserId));
    }

    // TODO: 2022/9/11 获取这个用户的列表
    @GetMapping("getSystemUser")
    public JsonResult<List<SystemUserVo>> getSystemUser(@RequestParam(defaultValue = "") Long manageUserId) {
        List<SystemUserVo> systemUser = userService.getSystemUser(manageUserId);
        return JsonResult.success(systemUser);
    }

    @GetMapping("/getPages")
    public Integer getPages(@RequestParam("size") Integer size) {
        return (userService.list().size() + size - 1) / size;
    }

    @PostMapping("/getAllData")
    public JsonResult<Object> getAllData(@RequestParam("personId") Long personId) {
        final User user = userService.getUserByUser_id(personId);
        final PersonBasicInfo personBasicInfo = userService.selectPersonBasicInfoByPrimaryKey(personId);
        final PersonDetailInfo personDetailInfo = userService.selectPersonDetailInfoByPrimaryKey(personId);
        final Requirement requirement = userService.selectRequirementByPrimaryKey(personId);
        Map<String, Object> resMap = new HashMap<>(4);
        resMap.put("createTime", DateUtil.formatDateTime(user.getCreateTime()));
        resMap.put("requirement", requirement);
        resMap.put("personBasicInfo", personBasicInfo);
        resMap.put("personDetailInfo", personDetailInfo);
        return JsonResult.success(200, "查询成功！", resMap);
    }

    /**
     * //获取用户信息列表
     *
     * @param page
     * @param size
     * @return
     */
    @ApiOperation("获取用户（分页）")
    @GetMapping("/getUserList")
    public PageJsonResult<List<User>> getUserList(@RequestParam(defaultValue = "") String tel,
                                                  @RequestParam(defaultValue = "1") Integer page,
                                                  @RequestParam(defaultValue = "10") Integer size) {

        return userService.getUserList(tel, page, size);
    }

    /**
     * （批量）删除用户
     *
     * @param
     * @return
     */
    @ApiOperation("删除用户")
    @DeleteMapping("/deleteUser")
    public JsonResult<Object> deleteUserById(@RequestBody List<Integer> ids) {
        userService.removeBatchByIds(ids);
        return JsonResult.success();
    }


}
