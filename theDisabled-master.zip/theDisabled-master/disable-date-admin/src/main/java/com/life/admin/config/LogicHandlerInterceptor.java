package com.life.admin.config;

import com.life.admin.util.GetUserFromRedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author chunming
 * @date 2022-09-05 17:53:17
 */
@Component
public class LogicHandlerInterceptor extends HandlerInterceptorAdapter {

    @Autowired
    GetUserFromRedisUtil userFromRedisUtil;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        if (request.getRequestURI().contains("login")) {
            return true;
        }
        // 检查是否过期
        userFromRedisUtil.checkByToken(request.getHeader("Authorization"));

        return super.preHandle(request, response, handler);
    }
}
