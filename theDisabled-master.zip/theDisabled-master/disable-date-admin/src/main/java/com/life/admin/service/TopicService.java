package com.life.admin.service;

import com.life.admin.common.PageJsonResult;
import com.life.admin.dto.TopicDTO;
import com.life.admin.pojo.Administrator;
import com.life.admin.pojo.TopicComment;
import com.life.admin.pojo.TopicReplyComment;
import com.life.admin.vo.TopicReplyCommentVo;
import com.life.admin.vo.TopicVo;

import java.util.List;

/**
 * @author Chunming Liu In 2022/08/21
 */
public interface TopicService {

    void updateTopic(TopicDTO topicDTO);

    List<TopicComment> getAllCommentByTopicId(Long page, Long size, String sortName, String sortOrder, Long topicId);

    List<TopicReplyCommentVo> getAllReplyByTopicId(Long page, Long size, String sort, String order, String commentId);

    PageJsonResult<List<TopicVo>> queryTopicPage(Long userId, Long page, Long size);

    void deleteTopic(Long topicId);

    void deleteComments(Long topicId);

    void deleteReplies(Long topicId);

    void publish(Administrator adminUser, TopicDTO topicDTO);

    TopicComment getCommentById(Long commentId);

    List<TopicReplyComment> getRepliesByTopicId(Long topicId);

    void deleteCommentByCommentId(TopicComment comment);

    TopicReplyComment getReplyById(Long replyId);

    void deleteReplyByReplyId(TopicReplyComment reply);
}
