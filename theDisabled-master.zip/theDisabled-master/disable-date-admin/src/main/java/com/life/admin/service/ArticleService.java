package com.life.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.life.admin.common.PageJsonResult;
import com.life.admin.dto.ArticleCategoryDTO;
import com.life.admin.pojo.ArticleEntity;
import com.life.admin.vo.ArticleCategoryVo;
import com.life.admin.vo.ArticlePageVo;
import com.life.admin.vo.ArticleVo;


import java.util.List;

/**
 * @author chunming
 * @date 2022-09-01 12:17:46
 */
public interface ArticleService extends IService<ArticleEntity> {

    PageJsonResult<List<ArticleCategoryVo>> queryCategory(Long page, Long size);

    PageJsonResult<List<ArticlePageVo>> queryArticle(Integer categoryId, Long page, Long size);

    void createCategory(ArticleCategoryDTO articleCategoryDTO);

    void updateCategory(ArticleCategoryDTO articleCategoryDTO);

    void deleteCategory(List<Integer> ids);
}
