package com.life.admin.pojo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author chunming
 * @date 2022-09-01 10:50:53
 */
@Data
@TableName("tb_disable_data_article_category")
public class ArticleCategoryEntity {
    @ApiModelProperty("ID")
    private Integer id;
    @ApiModelProperty("类别")
    private String category;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("创建时间")
    private LocalDateTime createTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("更新时间")
    private LocalDateTime updateTime;
    @JsonIgnore
    @ApiModelProperty(value = "是否删除", hidden = true)
    private Boolean isDelete;
}
