package com.life.admin.common;

import com.alibaba.fastjson.JSON;
import com.life.admin.pojo.PersonBasicInfoDoc;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/
@Service
public class PersonBasicInfoRestClient {

    @Autowired
    RabbitTemplate rabbitTemplate;
    @Autowired
    private RestHighLevelClient client;

    /**
     * 根据personId搜索指定用户的择偶要求
     *
     * @param personId
     *
     * @return
     *
     * @throws IOException
     */
    public PersonBasicInfoDoc MatchByPersonId(Integer personId) throws IOException {
        // 1.准备request
        SearchRequest request = new SearchRequest("disable-date-basic-info");
        // 2.准备请求参数
        request.source().query(QueryBuilders.termQuery("personId", personId.toString()));
        // 3.发送请求，得到响应
        SearchResponse response = client.search(request, RequestOptions.DEFAULT);
        // 4.结果解析
        return handleOneObject(response);
    }

    public String getPersonName(Integer personId) {
        try {
            PersonBasicInfoDoc personBasicInfoDoc = MatchByPersonId(personId);
            if (personBasicInfoDoc != null) {
                return personBasicInfoDoc.getPersonName();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    private PersonBasicInfoDoc handleOneObject(SearchResponse response) {
        SearchHits searchHits = response.getHits();
        // 4.1.获取文档数组
        SearchHit[] hits = searchHits.getHits();
        try {
            // 4.2 获取json结果
            String json = hits[0].getSourceAsString();
            // 4.3 将json结果转换成指定对象返回
            return JSON.parseObject(json, PersonBasicInfoDoc.class);
        } catch (Exception e) {
            return null;
        }

    }

}
