package com.life.admin.service;

import com.life.admin.common.PageJsonResult;
import com.life.admin.dto.JobDeliveryRecordDTO;
import com.life.admin.vo.JobDeliveryRecordVo;
import com.life.admin.vo.JobVo;

import java.util.List;

/**
 * @author Chunming Liu In 2022/08/23
 */
public interface JobDeliveryRecordService {
    void applyJob(JobDeliveryRecordDTO deliveryRecordDTO);

    PageJsonResult<List<JobDeliveryRecordVo>> queryApplyJobPage(Long jobId, Integer page, Integer size);

    PageJsonResult<List<JobVo>> queryUserApplyJobPage(Long userId, Integer page, Integer size);
}
