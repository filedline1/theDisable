//package VO;
//
//import lombok.Data;
//import pojo.User;
//
///**
// * @author Mr.Jiang
// * @version 1.0
// **/
//
//@Data
//public class UserVO {
//
//    private Integer userId;
//
//    private String nickName;
//
//    private String loginName;
//
//    private Integer page;
//
//    private Integer size;
//
//    public void VOTransformTOUser(User user) {
//
//    }
//}
