package com.life.admin.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.time.LocalDateTime;

/**
 * @author Chunming Liu In 2022/08/21
 */

@ApiModel("话题评论")
@Document(indexName = "tb_disable_date_topic_comment")
@Data
@TableName("tb_disable_date_topic_comment")
public class TopicComment {
    @Id
    @JsonSerialize(using = ToStringSerializer.class)
    @TableId(type = IdType.AUTO)
    @ApiModelProperty("ID")
    @Field(type = FieldType.Long)
    private Long id;
    @ApiModelProperty("评论ID")
    @Field(type = FieldType.Keyword)
    private String commentId;
    @ApiModelProperty("话题ID")
    @Field(type = FieldType.Long)
    private Long topicId;

    @ApiModelProperty("评论人ID")
    @Field(type = FieldType.Long)
    private Long commentatorId;
    @ApiModelProperty("评论人名称")
    @Field(type = FieldType.Keyword)
    private String commentatorName;
    @ApiModelProperty("评论人IP")
    @Field(type = FieldType.Keyword)
    private String commentatorIp;
    @ApiModelProperty("评论内容")
    @Field(type = FieldType.Keyword)
    private String commentBody;

    @ApiModelProperty("回复数量")
    @Field(type = FieldType.Integer)
    private Integer replyAmount;
    @ApiModelProperty("评论状态：是否审核通过 1-未审核 2-审核通过 默认 2")
    @Field(type = FieldType.Integer)
    private Integer commentStatus;
    @ApiModelProperty(value = "点赞量", hidden = true)
    @Field(type = FieldType.Long)
    private Long likeAmount; //点赞量
    @ApiModelProperty(hidden = true)
    @Field(type = FieldType.Integer)
    @TableLogic
    private Integer isDeleted;   //'是否删除 1-未删除 2-已删除',
    @ApiModelProperty("创建时间")
    @Field(type = FieldType.Date, format = DateFormat.custom, pattern = "uuuu-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createTime;
}
