package com.life.admin.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.dao.VipPackageMapper;
import com.life.admin.pojo.VipPackage;
import com.life.admin.service.VipPackageService;
import com.life.admin.util.PageQueryUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Mr.Jiang
 * @version 1.0
 **/

@Service
public class VipPackageServiceImpl extends ServiceImpl<VipPackageMapper, VipPackage> implements VipPackageService {


    @Autowired
    VipPackageMapper vipPackageMapper;

    public List<VipPackage> findRecordList(PageQueryUtil pageUtil) {
        return vipPackageMapper.findRecordList(pageUtil);
    }

    @Override
    public void deleteByPrimaryKey(Integer id) {
        vipPackageMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(VipPackage record) {
        return vipPackageMapper.insert(record);
    }

    @Override
    public int insertSelective(VipPackage record) {
        return vipPackageMapper.insertSelective(record);
    }

    @Override
    public VipPackage selectByPrimaryKey(Integer id) {
        return vipPackageMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKeySelective(VipPackage record) {
        return vipPackageMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(VipPackage record) {
        return vipPackageMapper.updateByPrimaryKey(record);
    }
}
