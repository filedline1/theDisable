package com.life.admin.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.life.admin.pojo.Comment;
import com.life.admin.pojo.Diary;

import java.io.IOException;
import java.util.List;

public interface DiaryService extends IService<Diary> {

    //通过diaryId查询动态
    Diary getDiaryByDiaryId(String diaryId);

    //根据动态diaryId查询所有的评论
    List<Comment> getAllCommentByDiaryId(String page, String size, String sortName, String sortOrder, String diaryId) throws IOException;


    //查询多条动态信息
    List<Diary> gertNearActiveList(String name,int page,int size,String sortOrder) throws IOException;

    //从数据库中删除动态
    void deleteDiary(String diaryId);


    //根据收藏的对象id从数据库中删除所有有关的记录
    void deleteUserLike(String likedId);

    //从数据库中删除对这个的点赞的记录
    void deleteAllLikeRecord(String diaryId);
}
