package com.life.admin.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.common.RestClient;
import com.life.admin.dao.CommentMapper;
import com.life.admin.dao.DiaryMapper;
import com.life.admin.dao.PictureMapper;
import com.life.admin.pojo.*;
import com.life.admin.service.DiaryService;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.search.SearchHit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
public class DiaryServiceImpl extends ServiceImpl<DiaryMapper, Diary> implements DiaryService {

    @Autowired
    private DiaryMapper diaryMapper;

    @Autowired
    private PictureMapper pictureMapper;

    @Autowired
    private CommentMapper commentMapper;

    @Autowired
    private RestClient restClient = new RestClient();

    @Autowired
    private RestHighLevelClient client;

    @Override
    public Diary getDiaryByDiaryId(String diaryId) {
        try {
            return diaryMapper.getDiaryById(diaryId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 根据动态diaryId查询所有的评论
     *
     * @param page
     * @param size
     * @param sortName  排序依据的索引库中的字段名
     * @param sortOrder 排序的规则，升序 or 降序
     * @param diaryId   动态的id
     *
     * @return
     *
     * @throws IOException
     */
    @Override
    public List<Comment> getAllCommentByDiaryId(String page, String size, String sortName, String sortOrder, String diaryId) throws IOException {
        String index = "tb_disable_date_diary_comment";  //索引库名（==表名）
        String esName = "diaryId";       //查询的字段名
        Map<String, String> es = new HashMap<>();
        // es.put("commentStatus", "1");
        SearchHit[] hits = restClient.getAllByISSPG(index, sortName, page, size, sortOrder, esName, diaryId, es);
        List<Comment> list = new ArrayList<>();
        int n = 0;
        for (SearchHit hit : hits) {
            n++;
            //获取文档source
            String json = hit.getSourceAsString();
            //反序列化
            Comment comment = JSON.parseObject(json, Comment.class);
            list.add(comment);
            System.out.println("------------------------------------------------------------------------");
            System.out.println("获取到第 " + n + " 个结果 --> " + comment);
            System.out.println("------------------------------------------------------------------------");
        }
        return list;
    }

    //查询多条动态信息
    @Override
    public List<Diary> gertNearActiveList(String name, int page, int size, String sortOrder) {
        try {
            String index = "tb_disable_date_diary";  //索引库名（==表名）
            Map<String, String> es = new HashMap<>();
            // es.put("diaryStatus", "1");
            // es.put("enableLook", "1");
            // es.put("isDeleted", "0");
            // es.put("isReport", "0");     //0-举报失败或未被举报 1-举报成功
            SearchHit[] hits = restClient.getAllByISSPG(index, name, page + "", size + "", sortOrder, null, null, es);

            List<Diary> list = new ArrayList<>();
            //反序列
            for (SearchHit hit : hits) {
                //获取文档source
                String json = hit.getSourceAsString();
                //反序列化
                Diary diary = JSON.parseObject(json, Diary.class);
                list.add(diary);
            }
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //从数据库中删除动态
    public void deleteDiary(String diaryId) {
        diaryMapper.deleteDiary(diaryId);
    }

    //根据收藏的对象id从数据库中删除所有有关的记录
    public void deleteUserLike(String likedId) {
        diaryMapper.deleteUserLike(likedId);
    }

    //从数据库中删除对这个的点赞的记录
    public void deleteAllLikeRecord(String diaryId) {
        diaryMapper.deleteAllLikeRecord(diaryId);
    }
}
