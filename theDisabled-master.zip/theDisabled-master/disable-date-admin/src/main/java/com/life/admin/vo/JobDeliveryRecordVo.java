package com.life.admin.vo;


import com.life.admin.pojo.JobDeliveryRecordEntity;

/**
 * @author Chunming Liu In 2022/08/23
 */
public class JobDeliveryRecordVo extends JobDeliveryRecordEntity {
}
