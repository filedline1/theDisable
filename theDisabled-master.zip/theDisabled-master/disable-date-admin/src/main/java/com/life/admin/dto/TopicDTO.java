package com.life.admin.dto;


import com.life.admin.pojo.TopicEntity;

/**
 * @author Chunming Liu In 2022/08/21
 */
public class TopicDTO extends TopicEntity {
}
