package com.life.admin.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.life.admin.common.PageJsonResult;
import com.life.admin.common.RestClient;
import com.life.admin.constants.MqConstants;
import com.life.admin.dao.TopicCommentMapper;
import com.life.admin.dao.TopicMapper;
import com.life.admin.dao.TopicReplyCommentMapper;
import com.life.admin.dao.UserMapper;
import com.life.admin.dto.TopicDTO;
import com.life.admin.pojo.*;
import com.life.admin.service.TopicService;
import com.life.admin.vo.TopicReplyCommentVo;
import com.life.admin.vo.TopicVo;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.search.SearchHit;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @author Chunming Liu In 2022/08/21
 */
@Service
public class TopicServiceImpl extends ServiceImpl<TopicMapper, TopicEntity> implements TopicService {
    final TopicMapper topicMapper;
    final TopicReplyCommentMapper topicReplyCommentMapper;
    final TopicCommentMapper topicCommentMapper;
    final RestClient restClient;
    final ObjectMapper objectMapper;
    final RabbitTemplate rabbitTemplate;
    @Autowired
    private UserMapper userMapper;

    public TopicServiceImpl(TopicMapper topicMapper,
                            TopicReplyCommentMapper topicReplyCommentMapper,
                            TopicCommentMapper topicCommentMapper, RestClient restClient, ObjectMapper objectMapper, RabbitTemplate rabbitTemplate) {
        this.topicMapper = topicMapper;
        this.topicReplyCommentMapper = topicReplyCommentMapper;
        this.topicCommentMapper = topicCommentMapper;
        this.restClient = restClient;
        this.objectMapper = objectMapper;
        this.rabbitTemplate = rabbitTemplate;
    }

    @Override
    public void updateTopic(TopicDTO topicDTO) {
        TopicEntity topicEntity = topicMapper.selectById(topicDTO.getId());

        Assert.state(topicEntity != null, "未找到此话题，更新失败");

        topicEntity.setId(topicDTO.getId());
        topicEntity.setUserId(topicDTO.getUserId());

        topicEntity.setTop(topicDTO.getTop() == null ? topicEntity.getTop() : topicDTO.getTop());
        topicEntity.setTitle(StringUtils.isBlank(topicDTO.getTitle()) ? topicEntity.getTitle() : topicDTO.getTitle());
        topicEntity.setContext(StringUtils.isBlank(topicDTO.getContext()) ? topicEntity.getContext() : topicDTO.getContext());
        topicEntity.setUpdater(StringUtils.isBlank(topicDTO.getUpdater()) ? topicEntity.getUpdater() : topicDTO.getUpdater());

        topicMapper.updateById(topicEntity);
    }

    @Override
    public List<TopicComment> getAllCommentByTopicId(Long page, Long size, String sortName, String sortOrder, Long topicId) {
        String index = "tb_disable_date_topic_comment";  // 索引库名（==表名）
        String esName = "topicId";       // 查询的字段名

        Map<String, String> es = Collections.emptyMap();
        // es.put("commentStatus", "2");

        SearchHit[] hits = restClient.getAllByISSPG(index, sortName, page.toString(), size.toString(), sortOrder, esName, topicId.toString(), es);
        List<TopicComment> topicCommentVos = new ArrayList<>();
        for (SearchHit hit : hits) {
            // 获取文档source
            String json = hit.getSourceAsString();
            // 反序列化
            TopicComment comment = JSON.parseObject(json, TopicComment.class);
            topicCommentVos.add(comment);
        }
        System.out.println("------------------------------------------------------------------------");
        System.out.println("获取到第 " + topicCommentVos.size() + " 个结果 --> " + topicCommentVos);
        System.out.println("------------------------------------------------------------------------");
        return topicCommentVos;
    }

    @Override
    public List<TopicReplyCommentVo> getAllReplyByTopicId(Long page, Long size, String sort, String order, String commentId) {
        String index = "tb_disable_date_topic_comment_reply";  // 索引库名（==表名）
        String esName = "commentId";       // 查询的字段名
        // Map<String, String> es = Collections.singletonMap ( "replyStatus", "1" );
        Map<String, String> es = Collections.emptyMap();

        SearchHit[] hits = restClient.getAllByISSPG(index, sort, page.toString(), size.toString(), order, esName, commentId, es);
        List<TopicReplyCommentVo> replyCommentVos = new ArrayList<>();

        for (SearchHit hit : hits) {
            // 获取文档source
            String json = hit.getSourceAsString();
            // 反序列化
            TopicReplyCommentVo reply = JSON.parseObject(json, TopicReplyCommentVo.class);
            replyCommentVos.add(reply);
        }
        System.out.println("------------------------------------------------------------------------");
        System.out.println("获取到第 " + replyCommentVos.size() + " 个结果 --> " + replyCommentVos);
        System.out.println("------------------------------------------------------------------------");
        return replyCommentVos;
    }

    @Override
    public PageJsonResult<List<TopicVo>> queryTopicPage(Long userId, Long page, Long size) {
        QueryWrapper<TopicEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(userId != null, "user_id", userId);
        queryWrapper.orderByDesc("top", "total_commit_count");

        Page<TopicEntity> topicEntityPage = topicMapper.selectPage(new Page<>(page, size), queryWrapper);
        List<TopicEntity> topicEntityPageRecords = topicEntityPage.getRecords();
        List<TopicVo> topicVos = BeanUtil.copyToList(topicEntityPageRecords, TopicVo.class);

        return PageJsonResult.success(page, size, topicEntityPage.getTotal(), topicVos);
    }

    @Override
    public void deleteTopic(Long topicId) {
        topicMapper.deleteById(topicId);
    }

    @Override
    public void deleteComments(Long topicId) {
        QueryWrapper<TopicComment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("topicId", topicId);
        // es
        for (TopicComment comment : topicCommentMapper.selectList(queryWrapper)) {
            rabbitTemplate.convertAndSend(MqConstants.TOPIC_COMMENT_EXCAHGNE, MqConstants.TOPIC_COMMENT_DELETE_KEY, comment.getId());
        }
        topicCommentMapper.delete(queryWrapper);
    }

    @Override
    public void deleteReplies(Long topicId) {
        QueryWrapper<TopicReplyComment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("topicId", topicId);
        // es
        for (TopicReplyComment replyComment : topicReplyCommentMapper.selectList(queryWrapper)) {
            rabbitTemplate.convertAndSend(MqConstants.TOPIC_REPLY_EXCAHGNE, MqConstants.TOPIC_REPLY_DELETE_KEY, replyComment.getId());
        }
        topicReplyCommentMapper.delete(queryWrapper);
    }

    @Override
    public void publish(Administrator adminUser, TopicDTO topicDTO) {
        // topicDTO.setUserId(adminUser.getId());
        // topicDTO.setUpdater(adminUser.getUserName());
        topicDTO.setIsSystem(true);
        User systemUser = userMapper.getUserByUser_id(topicDTO.getUserId());
        if (systemUser != null) {
            topicDTO.setUpdater(systemUser.getNickName());
        }
        topicMapper.insert(topicDTO);
    }

    @Override
    public TopicComment getCommentById(Long commentId) {
        return topicCommentMapper.selectById(commentId);
    }

    @Override
    public List<TopicReplyComment> getRepliesByTopicId(Long topicId) {
        QueryWrapper<TopicReplyComment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("topicId", topicId);
        return topicReplyCommentMapper.selectList(queryWrapper);
    }

    @Override
    public void deleteCommentByCommentId(TopicComment comment) {
        topicCommentMapper.deleteById(comment.getId());
    }

    @Override
    public TopicReplyComment getReplyById(Long replyId) {
        return topicReplyCommentMapper.selectById(replyId);
    }

    @Override
    public void deleteReplyByReplyId(TopicReplyComment reply) {
        topicReplyCommentMapper.deleteById(reply.getId());
    }
}
