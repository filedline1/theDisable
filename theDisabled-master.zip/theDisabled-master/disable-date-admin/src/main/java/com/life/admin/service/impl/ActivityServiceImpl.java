package com.life.admin.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.dao.ActivityMapper;
import com.life.admin.pojo.Activity;
import com.life.admin.service.IActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ActivityServiceImpl extends ServiceImpl<ActivityMapper, Activity> implements IActivityService {

    @Autowired
    private ActivityMapper activityMapper;

    // 获取活动的列表（按照序号进行升序查询）
    public Page<Activity> getActivityList(Integer index, Integer size) {
        return activityMapper.selectPage(new Page<>(index, size), null);
    }
}
