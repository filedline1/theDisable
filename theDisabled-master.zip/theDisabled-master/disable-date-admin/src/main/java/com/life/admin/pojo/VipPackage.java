package com.life.admin.pojo;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * create table tb_disable_date_admin_vip_package
 * (
 *     id             int auto_increment comment '用户id'
 *         primary key,
 *     name           varchar(20)                        null comment '套餐名',
 *     time           int                                null comment '时长',
 *     price          double                             null comment '单月价格',
 *     total_price    double                             null comment '总价格',
 *     package_status int                                null comment '套餐状态 0-未开启 1-开启',
 *     advice_first   int                                null comment '是否首推 0-否 1-首推',
 *     create_time    datetime default CURRENT_TIMESTAMP null comment '套餐创建时间',
 *     update_time    datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '套餐更新时间'
 * );
 */
@Data
@TableName("tb_disable_date_admin_vip_package")
public class VipPackage {

    @ApiModelProperty("用户id")
    private Integer id;
    @ApiModelProperty("套餐名")
    private String name;
    @ApiModelProperty("时长")
    private Integer time;
    @ApiModelProperty("单月价格")
    private Double price;
    @ApiModelProperty("总价格")
    private Double totalPrice;
    @ApiModelProperty("套餐状态 0-未开启 1-开启")
    private Integer packageStatus;
    @ApiModelProperty("是否首推 0-否 1-首推")
    private Integer adviceFirst;
    @ApiModelProperty("套餐创建时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @ApiModelProperty("套餐更新时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}