package com.life.admin.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.common.PageJsonResult;
import com.life.admin.constants.MqConstants;
import com.life.admin.dao.PersonBasicInfoMapper;
import com.life.admin.dao.PersonDetailInfoMapper;
import com.life.admin.dao.RequirementsMapper;
import com.life.admin.dao.UserMapper;
import com.life.admin.pojo.*;
import com.life.admin.service.IUserService;
import com.life.admin.vo.SystemUserVo;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

    @Autowired
    RabbitTemplate rabbitTemplate;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private PersonDetailInfoMapper personDetailInfoMapper;
    @Autowired
    private PersonBasicInfoMapper personBasicMapper;
    @Autowired
    private RequirementsMapper requirementMapperMapper;

    // 获取用户信息列表
    @Override
    public PageJsonResult<List<User>> getUserList(String tel, Integer index, Integer size) {

        Page<User> userPage = userMapper.selectPageCustom(new Page<>(index, size), tel);
        return PageJsonResult.success(index, size, userPage.getTotal(), userPage.getRecords());

    }

    // 查询用户登录信息
    @Override
    public List<LoginILogs> getLoginLogs(Integer index, Integer size) {
        List<LoginILogs> list = userMapper.getLoginLogs(index, size);
        return list;
    }

    // 获取登录日志的总页数
    @Override
    public Integer getPages() {
        Integer all = userMapper.getPages();
        return all;
    }

    @Override
    public void deleteUserByUserId(Integer id) {
        userMapper.deleteUserByUserId(id);
    }

    @Override
    public BasicInfo getBasicInfoByUserId(String user_id) {
        return userMapper.getBasicInfoByUserId(user_id);
    }

    @Override
    public User getUserByUser_id(Long diaryUserId) {
        return userMapper.getUserByUser_id(diaryUserId);
    }

    @Override
    public void deleteCollectByLikeId(String diaryId) {
        userMapper.deleteCollectByLikeId(diaryId);
    }

    @Override
    public PersonDetailInfo selectPersonDetailInfoByPrimaryKey(Long personId) {
        return personDetailInfoMapper.selectByPrimaryKey(personId);
    }

    @Override
    public PersonBasicInfo selectPersonBasicInfoByPrimaryKey(Long personId) {
        return personBasicMapper.selectByPrimaryKey(personId);
    }

    @Override
    public Requirement selectRequirementByPrimaryKey(Long personId) {
        return requirementMapperMapper.selectByPrimaryKey(personId);
    }

    @Override
    public List<SystemUserVo> getSystemUser(Long manageUserId) {
        return userMapper.selectSystemList(manageUserId);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Long createSystemUser(Long id, Long manageId, String nickleName, String headerImg) {
        User user = new User();
        user.setUserId(id);
        user.setManageId(manageId);
        user.setNickName(nickleName);
        user.setHeadPicPath(headerImg);

        if (id == null) {
            userMapper.insert(user);
        } else {
            updateById(user);
        }

        PersonBasicInfo personBasicInfo = new PersonBasicInfo();
        personBasicInfo.setAge(user.getAge());
        personBasicInfo.setPersonId(user.getUserId());
        // personBasicInfo.setLongitude(longitude);
        // personBasicInfo.setLatitude(latitude);
        // personBasicInfo.setPhone(userinfoMetadata.getCellPhone());
        personBasicInfo.setPersonName(user.getNickName());
        if (id == null) {
            if (personBasicMapper.insert(personBasicInfo) > 0) {
                rabbitTemplate.convertAndSend(MqConstants.PERSON_BASIC_INFO_EXCHANGE, MqConstants.PERSON_BASIC_INFO_INSERT_KEY, personBasicInfo.getPersonId());
            }
        } else {
            if (personBasicMapper.update(personBasicInfo) > 0) {
                rabbitTemplate.convertAndSend(MqConstants.PERSON_BASIC_INFO_EXCHANGE, MqConstants.PERSON_BASIC_INFO_INSERT_KEY, personBasicInfo.getPersonId());
            }
        }


        Requirement requirement = new Requirement();
        requirement.setPersonId(user.getUserId());
        if (id == null) {
            requirementMapperMapper.insert(requirement);
        } else {
            requirementMapperMapper.update(requirement);
        }


        PersonDetailInfo personDetailInfo = new PersonDetailInfo();
        personDetailInfo.setPersonId(user.getUserId());
        personDetailInfo.setIsSystem(true);
        if (id == null) {
            if (personDetailInfoMapper.insert(personDetailInfo) > 0) {
                rabbitTemplate.convertAndSend(MqConstants.PERSON_DETAIL_INFO_EXCHANGE, MqConstants.PERSON_DETAIL_INFO_INSERT_KEY, personDetailInfo.getPersonId());
            }
        } else {
            if (personDetailInfoMapper.update(personDetailInfo) > 0) {
                rabbitTemplate.convertAndSend(MqConstants.PERSON_DETAIL_INFO_EXCHANGE, MqConstants.PERSON_DETAIL_INFO_INSERT_KEY, personDetailInfo.getPersonId());
            }
        }
        return user.getUserId();
    }
}
