package com.life.admin.vo;


import com.life.admin.pojo.TopicReplyComment;

/**
 * @author Chunming Liu In 2022/08/21
 */
public class TopicReplyCommentVo extends TopicReplyComment {
}
