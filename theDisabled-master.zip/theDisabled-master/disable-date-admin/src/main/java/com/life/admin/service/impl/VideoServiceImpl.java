package com.life.admin.service.impl;


import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.common.RestClient;
import com.life.admin.dao.VideoMapper;
import com.life.admin.pojo.Video;
import com.life.admin.service.IVideoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.elasticsearch.search.SearchHit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class VideoServiceImpl extends ServiceImpl<VideoMapper, Video> implements IVideoService {

    @Autowired
    RestClient restClient;
    @Autowired
    private VideoMapper videoMapper;

    //找到视频动态的视频链接
    public Video getVideosBydiaryId(String diaryId) {
        return videoMapper.getVideosBydiaryId(diaryId);
    }

    @Override
    public List<String> getPathById(String name, String diaryId) {
        String index = "tb_disable_diary_videos";
        SearchHit[] hits;
        try {
            hits = restClient.boolQuery_termQuery_getAllByOneText(index, name, diaryId);
        } catch (IOException e) {
            log.error("查询动态视频地址异常，#{}", ExceptionUtils.getStackTrace(e));
            throw new RuntimeException(e);
        }
        List<String> path = new ArrayList<>();
        //反序列
        for (SearchHit hit : hits) {
            //获取文档source
            String json = hit.getSourceAsString();
            //反序列化
            Video video = JSON.parseObject(json, Video.class);
            path.add(video.getVideoPath());
        }
        System.out.println(path);
        return path;
    }

    @Override
    public Video getDiaryVideos(String diaryId) {
        try {
            String index = "tb_disable_diary_videos";
            String name = "diaryId";
            SearchHit[] hits = restClient.boolQuery_termQuery_getAllByOneText(index, name, diaryId);
            List<Video> list = new ArrayList<>();
            //反序列
            for (SearchHit hit : hits) {
                //获取文档source
                String json = hit.getSourceAsString();
                //反序列化
                Video video = JSON.parseObject(json, Video.class);
                list.add(video);
            }
            if (list.size() > 0)
                return list.get(0);
            return null;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deleteDiaryVideo(String diaryId) {
        videoMapper.deleteDiaryVideo(diaryId);
    }
}