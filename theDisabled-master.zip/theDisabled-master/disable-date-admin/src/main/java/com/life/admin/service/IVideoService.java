package com.life.admin.service;


import com.life.admin.pojo.Video;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface IVideoService extends IService<Video> {

    //找到视频动态的视频链接
    Video getVideosBydiaryId(String diaryId);

    List<String> getPathById(String name, String diaryId);

    Video getDiaryVideos(String diaryId);

    void deleteDiaryVideo(String diaryId);
}
