package com.life.admin.pojo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;


/**
 * @author chunming
 * @date 2022-09-01 11:10:09
 */
@ApiModel("文章")
@Data
@TableName("tb_disable_data_article")
public class ArticleEntity {
    @ApiModelProperty("ID")
    private Long id;
    @ApiModelProperty("分类ID")
    private Integer categoryId;
    @ApiModelProperty("分类")
    private String category;
    @ApiModelProperty("标题")
    private String title;
    @ApiModelProperty("作者ID")
    private Long authorId;
    @ApiModelProperty("作者头像")
    private String authorLogo;
    @ApiModelProperty("作者")
    private String author;
    @ApiModelProperty("文章头图")
    private String headerImg;
    @ApiModelProperty("文章内容")
    private String content;
    @ApiModelProperty("文章状态：0-草稿，1-发布（默认）")
    private Integer status;
    @JsonIgnore
    @ApiModelProperty(value = "是否删除", hidden = true)
    private Boolean isDelete;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("创建时间")
    private LocalDateTime createTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("更新时间")
    private LocalDateTime updateTime;
    @ApiModelProperty(value = "点赞数", hidden = true)
    private Long likes;
    @ApiModelProperty("阅读量")
    private Long readingVolume;
}
