package com.life.admin.util;

import cn.hutool.json.JSONUtil;
import com.life.admin.advise.exception.TokenNotFoundException;
import com.life.admin.pojo.Administrator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;

@Slf4j
@Configuration
public class GetUserFromRedisUtil {

    private final RedisTemplate redisTemplate;

    public GetUserFromRedisUtil(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public Administrator getUserFromRedis(String token) {
        if (token == null) {
            throw new TokenNotFoundException("No Authorization");
        }
        Object manager = redisTemplate.opsForValue().get(token);
        if (manager == null) {
            throw new TokenNotFoundException("No Authorization");
        }
        log.info("管理员信息: #{}", manager);
        return JSONUtil.toBean((String) manager, Administrator.class);
    }

    /**
     * 检查token
     *
     * @param token token
     */
    public void checkByToken(String token) {
        if (token == null) {
            throw new TokenNotFoundException("No Authorization");
        }
        Object manager = redisTemplate.opsForValue().get(token);
        if (manager == null) {
            throw new TokenNotFoundException("No Authorization");
        }
        log.info("管理员信息: #{}", manager);
    }
}
