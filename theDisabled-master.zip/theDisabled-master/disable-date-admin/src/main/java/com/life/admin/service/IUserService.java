package com.life.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.life.admin.common.PageJsonResult;
import com.life.admin.pojo.*;
import com.life.admin.vo.SystemUserVo;

import java.util.List;

public interface IUserService extends IService<User> {


    //获取用户信息列表
    PageJsonResult<List<User>> getUserList(String tel, Integer index, Integer size);

    //查询用户登录信息
    List<LoginILogs> getLoginLogs(Integer index, Integer size);

    //获取登录日志的总页数
    Integer getPages();

    void deleteUserByUserId(Integer id);

    BasicInfo getBasicInfoByUserId(String diaryUserId);

    User getUserByUser_id(Long diaryUserId);

    void deleteCollectByLikeId(String diaryId);

    PersonDetailInfo selectPersonDetailInfoByPrimaryKey(Long personId);

    PersonBasicInfo selectPersonBasicInfoByPrimaryKey(Long personId);

    Requirement selectRequirementByPrimaryKey(Long personId);

    List<SystemUserVo> getSystemUser(Long manageUserId);

    Long createSystemUser(Long id, Long manageId, String nickleName, String headerImg);
}
