package com.life.admin.controller;

import com.life.admin.common.JsonResult;
import com.life.admin.common.PageJsonResult;
import com.life.admin.dto.ArticleCategoryDTO;
import com.life.admin.dto.ArticleDTO;
import com.life.admin.pojo.ArticleEntity;
import com.life.admin.service.ArticleService;
import com.life.admin.vo.ArticleCategoryVo;
import com.life.admin.vo.ArticlePageVo;
import com.life.admin.vo.ArticleVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

/**
 * 文章
 *
 * @author chunming
 * @date 2022-09-01 10:05:42
 */
@Api(tags = "文章")
@RequestMapping("article")
@RestController
public class ArticleManageController {

    final ArticleService articleService;

    public ArticleManageController(ArticleService articleService) {this.articleService = articleService;}

    @ApiOperation("文章分类分页")
    @GetMapping("category/queryPage")
    public PageJsonResult<List<ArticleCategoryVo>> queryCategory(@RequestParam(defaultValue = "1") Long page,
                                                                 @RequestParam(defaultValue = "10") Long size) {
        return articleService.queryCategory(page, size);
    }

    @ApiOperation("文章分类添加")
    @PostMapping("category/create")
    public JsonResult<Object> createCategory(@RequestBody ArticleCategoryDTO articleCategoryDTO) {
        articleService.createCategory(articleCategoryDTO);
        return JsonResult.success(Collections.singletonMap("id", articleCategoryDTO.getId()));
    }

    @ApiOperation("文章分类更新")
    @PostMapping("category/update")
    public JsonResult<Object> updateCategory(@RequestBody ArticleCategoryDTO articleCategoryDTO) {
        articleService.updateCategory(articleCategoryDTO);
        return JsonResult.success();
    }

    @ApiOperation("文章分类删除")
    @DeleteMapping("category/delete")
    public JsonResult<Object> deleteCategory(@RequestBody List<Integer> ids) {
        articleService.deleteCategory(ids);
        return JsonResult.success();
    }

    @ApiOperation("文章分页")
    @GetMapping("queryPage")
    public PageJsonResult<List<ArticlePageVo>> queryArticle(@RequestParam(defaultValue = "") Integer categoryId,
                                                            @RequestParam(defaultValue = "1") Long page,
                                                            @RequestParam(defaultValue = "10") Long size) {
        return articleService.queryArticle ( categoryId, page, size );
    }

    @ApiOperation("文章详情")
    @PostMapping("detail")
    public JsonResult<ArticleEntity> createArticle(@RequestParam Long id) {
        return JsonResult.success ( articleService.getById ( id ) );
    }

    @ApiOperation("文章发布")
    @PostMapping("create")
    public JsonResult<Object> createArticle(@RequestBody ArticleDTO articleDTO) {
        articleService.save(articleDTO);
        return JsonResult.success(Collections.singletonMap("id", articleDTO.getId()));
    }

    @ApiOperation("文章更新")
    @PostMapping("update")
    public JsonResult<Object> updateArticle(@RequestBody ArticleDTO articleDTO) {
        articleService.updateById(articleDTO);
        return JsonResult.success();
    }

    @ApiOperation("文章删除")
    @DeleteMapping("delete")
    public JsonResult<Object> deleteArticle(@RequestBody List<Long> ids) {
        articleService.removeByIds(ids);
        return JsonResult.success();
    }
}
