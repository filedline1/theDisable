package com.life.admin.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.common.PageJsonResult;
import com.life.admin.dao.ArticleCategoryMapper;
import com.life.admin.dao.ArticleMapper;
import com.life.admin.pojo.ArticleCategoryEntity;
import com.life.admin.pojo.ArticleEntity;
import com.life.admin.service.ArticleService;
import com.life.admin.vo.ArticleCategoryVo;
import com.life.admin.vo.ArticlePageVo;
import com.life.admin.dto.ArticleCategoryDTO;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author chunming
 * @date 2022-09-01 12:19:48
 */
@Service
public class ArticleServiceImpl extends ServiceImpl<ArticleMapper, ArticleEntity> implements ArticleService {

    final ArticleMapper articleMapper;
    final ArticleCategoryMapper articleCategoryMapper;

    public ArticleServiceImpl(ArticleMapper articleMapper,
                              ArticleCategoryMapper articleCategoryMapper) {
        this.articleMapper = articleMapper;
        this.articleCategoryMapper = articleCategoryMapper;
    }

    @Override
    public PageJsonResult<List<ArticleCategoryVo>> queryCategory(Long page, Long size) {
        Page<ArticleCategoryEntity> articleCategoryEntityPage = articleCategoryMapper.selectPage(new Page<>(page, size), null);
        return PageJsonResult.success(page, size, articleCategoryEntityPage.getTotal(), BeanUtil.copyToList(articleCategoryEntityPage.getRecords(), ArticleCategoryVo.class));
    }

    @Override
    public PageJsonResult<List<ArticlePageVo>> queryArticle(Integer categoryId, Long page, Long size) {
        Page<ArticlePageVo> articleEntityPage = articleMapper.selectPageCustom (new Page<>(page, size), categoryId);
        return PageJsonResult.success(page, size, articleEntityPage.getTotal(), articleEntityPage.getRecords());
    }

    @Override
    public void createCategory(ArticleCategoryDTO articleCategoryDTO) {
        articleCategoryMapper.insert(articleCategoryDTO);
    }

    @Override
    public void updateCategory(ArticleCategoryDTO articleCategoryDTO) {
        articleCategoryMapper.updateById(articleCategoryDTO);
    }

    @Override
    public void deleteCategory(List<Integer> ids) {
        articleCategoryMapper.deleteBatchIds(ids);
    }
}
