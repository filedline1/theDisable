package com.life.admin.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.life.admin.dao.AdvertiseplaceMapper;
import com.life.admin.pojo.Advertiseplace;
import com.life.admin.service.IAdvertiseplaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdvertiseplaceImpl extends ServiceImpl<AdvertiseplaceMapper, Advertiseplace> implements IAdvertiseplaceService {

    @Autowired
    private AdvertiseplaceMapper advertiseplaceMapper;

    // 获取广告位的列表
    public Page<Advertiseplace> getAdvertiseplaceList(Integer index, Integer size) {
        return advertiseplaceMapper.selectPage(new Page<>(index, size), null);
    }
}
