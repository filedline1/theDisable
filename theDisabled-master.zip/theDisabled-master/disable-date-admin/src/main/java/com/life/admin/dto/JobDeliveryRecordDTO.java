package com.life.admin.dto;

import com.life.admin.pojo.JobDeliveryRecordEntity;
import io.swagger.annotations.ApiModel;
import lombok.ToString;

/**
 * @author Chunming Liu In 2022/08/23
 */
@ApiModel("投递简历")
@ToString
public class JobDeliveryRecordDTO extends JobDeliveryRecordEntity {
}
