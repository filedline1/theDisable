package com.life.admin.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.life.admin.pojo.ArticleEntity;
import com.life.admin.vo.ArticlePageVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author chunming
 * @date 2022-09-01 12:15:27
 */
@Mapper
public interface ArticleMapper extends BaseMapper<ArticleEntity> {
    Page<ArticlePageVo> selectPageCustom(Page<Object> objectPage, @Param("categoryId") Integer categoryId);
}
